package com.deenlife.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue

sealed interface Route {
    data class EventEdit(val id: Long, val day: Long, val category: String? = null) : Route
    data object Stats : Route
    data object Planner : Route
    data object Search : Route
    data object Sleep : Route
    data object Sport : Route
    data object Habits : Route
    data object Quran : Route
    data object Zikr : Route
    data object Fasting : Route
    data object HijriCal : Route
    data object Goals : Route
    data object PrayerSettings : Route
    data object Categories : Route
}

class Nav {
    val stack = mutableStateListOf<Route>()
    var tab by mutableIntStateOf(0)
    var studyPage by mutableIntStateOf(0)
    var calendarDay by mutableIntStateOf(0) // не используется напрямую; день хранится в самом календаре

    fun push(r: Route) { stack.add(r) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
    fun editEvent(id: Long, day: Long, cat: String? = null) = push(Route.EventEdit(id, day, cat))
}
