package com.deenlife.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.deenlife.domain.*
import com.deenlife.ui.*
import com.deenlife.ui.common.*
import com.deenlife.util.*
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel, sn: Snapshot, nav: Nav) {
    val clock by vm.clock.collectAsState()
    val s = sn.settings
    val today = clock.toLocalDate().toEpochDay()
    val nowMin = clock.hour * 60 + clock.minute
    val iso = isoDay(today)
    val items = remember(sn, today) { Timeline.build(today, sn) }
    val tasks = Timeline.tasks(items)
    val doneCount = tasks.count { it.done }
    val progress = if (tasks.isEmpty()) 0f else doneCount.toFloat() / tasks.size

    val next = items.filter {
        (it.kind == Kind.EVENT || it.kind == Kind.COURSE || it.kind == Kind.WORKOUT || it.kind == Kind.HOMEWORK) &&
            !it.done && !it.moved && !it.carry && it.category != "WAKE" && it.category != "SLEEP" && maxOf(it.e, it.s) >= nowMin
    }.minByOrNull { if (it.s <= nowMin) it.s - 10000 else it.s }
    val (prayerIdx, prayerMin) = remember(s, today, nowMin) { PrayerService.next(s, today, nowMin) }
    val suggestions = remember(sn, today, nowMin) { Planner.analyze(sn, today, nowMin) }

    val bed = s.bed[iso - 1].let { if (it < 360) it + 1440 else it }
    val wake = s.wake[iso - 1]
    val sleepText = when {
        nowMin < wake -> "до подъёма ${fmtDur(wake - nowMin)}"
        nowMin >= bed -> "пора спать!"
        else -> "до сна ${fmtDur(bed - nowMin)}"
    }

    var quick by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            val g = when (clock.hour) { in 0..4 -> "Доброй ночи"; in 5..11 -> "Доброе утро"; in 12..17 -> "Добрый день"; else -> "Добрый вечер" }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (s.userName.isBlank()) g else "$g, ${s.userName}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("%02d:%02d".format(clock.hour, clock.minute), fontSize = 52.sp, fontWeight = FontWeight.Bold)
                    Text(dayLabel(today), style = MaterialTheme.typography.titleSmall)
                    Text(Hijri.of(LocalDate.ofEpochDay(today), s.hijriAdjust).toString(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
                if (s.weatherCode >= 0) {
                    AppCard(Modifier.width(112.dp)) {
                        Text("${Math.round(s.weatherTemp)}°", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(Weather.describe(s.weatherCode), style = MaterialTheme.typography.bodySmall)
                        Text(s.cityName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.height(IntrinsicSize.Max)) {
                AppCard(Modifier.weight(1f).fillMaxHeight()) {
                    Text("Прогресс дня", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ProgressRing(progress, 64, 8, label = "${(progress * 100).toInt()}%")
                        Spacer(Modifier.width(10.dp))
                        Text(if (tasks.isEmpty()) "Нет задач" else "$doneCount из ${tasks.size}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                AppCard(Modifier.weight(1f).fillMaxHeight(), onClick = { nav.tab = 3 }) {
                    Text("Следующий намаз", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    Text(PRAYER_NAMES[prayerIdx], style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(fmtTime(prayerMin), style = MaterialTheme.typography.titleMedium)
                    Text("через ${fmtDur(prayerMin - nowMin)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.height(IntrinsicSize.Max)) {
                AppCard(Modifier.weight(1f).fillMaxHeight(), onClick = { next?.let { openItem(nav, it) } }) {
                    Text("Ближайшая задача", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    if (next == null) Text("На сегодня всё 🎉", style = MaterialTheme.typography.titleSmall)
                    else {
                        Text(next.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2)
                        Text(fmtTime(next.s), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            if (next.s <= nowMin) "идёт сейчас" else "через ${fmtDur(next.s - nowMin)}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                AppCard(Modifier.weight(1f).fillMaxHeight(), onClick = { nav.push(Route.Sleep) }) {
                    Text("Режим сна", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    Text(sleepText, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("отбой ${fmtTime(bed)} · подъём ${fmtTime(wake)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            ChipsRow {
                AssistChip(onClick = { nav.push(Route.Planner) }, label = { Text("Помощник") }, leadingIcon = { Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { nav.push(Route.Sport) }, label = { Text("Спорт") }, leadingIcon = { Icon(Icons.Rounded.FitnessCenter, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { nav.push(Route.Sleep) }, label = { Text("Сон") }, leadingIcon = { Icon(Icons.Rounded.Bedtime, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { nav.push(Route.Habits) }, label = { Text("Привычки") }, leadingIcon = { Icon(Icons.Rounded.Checklist, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { nav.push(Route.Stats) }, label = { Text("Статистика") }, leadingIcon = { Icon(Icons.Rounded.BarChart, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { nav.push(Route.Search) }, label = { Text("Поиск") }, leadingIcon = { Icon(Icons.Rounded.Search, null, Modifier.size(18.dp)) })
            }
        }
        if (suggestions.isNotEmpty()) {
            item {
                SectionTitle("Подсказки помощника") {
                    TextButton(onClick = { nav.push(Route.Planner) }) { Text("Все") }
                }
            }
            items(suggestions.take(2), key = { it.id }) { SuggestionCard(vm, it) }
        }
        item {
            SectionTitle("Мой день") {
                FilledTonalButton(onClick = { quick = true }, contentPadding = PaddingValues(horizontal = 14.dp)) {
                    Icon(Icons.Rounded.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Добавить")
                }
            }
        }
        if (items.isEmpty()) item { EmptyHint("Пока пусто. Нажмите «Добавить» или попросите помощника составить план.") }
        items(items, key = { it.id }) { it ->
            TimelineRow(it, nowMin, onToggle = { vm.toggle(it) }, onOpen = { openItem(nav, it) })
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    if (quick) QuickAddSheet(vm, sn, today, onDismiss = { quick = false }, onDetailed = { nav.push(it) })
}

fun openItem(nav: Nav, it: TItem) {
    when (it.kind) {
        Kind.EVENT -> nav.editEvent(it.refId, it.day)
        Kind.COURSE -> { nav.studyPage = 0; nav.tab = 2 }
        Kind.HOMEWORK -> { nav.studyPage = 1; nav.tab = 2 }
        Kind.WORKOUT -> nav.push(Route.Sport)
        Kind.PRAYER -> nav.tab = 3
        Kind.SLEEP -> nav.push(Route.Sleep)
    }
}

@Composable
fun SuggestionCard(vm: AppViewModel, sg: Suggestion) {
    val tint = if (sg.warn) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
    AppCard {
        Row(verticalAlignment = Alignment.Top) {
            Icon(if (sg.warn) Icons.Rounded.WarningAmber else Icons.Rounded.Lightbulb, null, tint = tint)
            Spacer(Modifier.width(10.dp))
            Text(sg.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        }
        when (val a = sg.action) {
            is SuggestionAction.AddEvents -> TextButton(onClick = { vm.applyEvents(a.events) }) { Text(a.label) }
            is SuggestionAction.Move -> TextButton(onClick = { vm.moveToNextSlot(a.item) }) { Text("Перенести") }
            null -> {}
        }
    }
}

@Composable
fun TimelineRow(it: TItem, nowMin: Int, onToggle: () -> Unit, onOpen: () -> Unit) {
    val color = Color(it.color)
    val active = !it.done && it.e > it.s && nowMin in it.s until it.e
    val interactive = it.kind != Kind.SLEEP
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        Column(Modifier.width(48.dp).padding(top = 14.dp), horizontalAlignment = Alignment.End) {
            Text(fmtTime(it.s), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            if (it.e > it.s) Text(fmtTime(it.e), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Column(Modifier.width(24.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(18.dp))
            Box(Modifier.size(10.dp).clip(CircleShape).background(color))
            Box(Modifier.width(2.dp).weight(1f).background(MaterialTheme.colorScheme.outlineVariant))
        }
        AppCard(
            Modifier.weight(1f).padding(bottom = 10.dp).alpha(if (it.done || it.moved) 0.55f else 1f),
            onClick = onOpen,
            container = if (active) color.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surface
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(iconFor(it.category), color, 36)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        it.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                        textDecoration = if (it.done || it.moved) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                    )
                    val sub = listOf(it.sub, if (it.moved) "перенесено" else "", if (it.carry) "продолжение" else "").filter { x -> x.isNotBlank() }.joinToString(" · ")
                    if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (interactive && !it.moved) CheckCircle(it.done, onToggle)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickAddSheet(vm: AppViewModel, sn: Snapshot, day: Long, onDismiss: () -> Unit, onDetailed: (Route) -> Unit) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var text by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("PERSONAL") }
    var date by remember { mutableLongStateOf(day) }
    var start by remember { mutableIntStateOf(((nowMinute() + 29) / 30 * 30).coerceAtMost(23 * 60)) }
    var dur by remember { mutableIntStateOf(60) }
    var warn by remember { mutableStateOf<String?>(null) }

    fun build(): EventEntityDraft {
        val m = Regex("(\\d{1,2})[:.](\\d{2})").find(text)
        val st = m?.let { parseHm(it.value) } ?: start
        var title = if (m != null) text.replace(m.value, "") else text
        title = title.replace(Regex("\\s+"), " ").trim().trimEnd('-', '–', ',', ' ')
        val low = text.lowercase()
        val c = when {
            listOf("тренир", "спортзал", "зал ").any { low.contains(it) } -> "WORKOUT"
            listOf("обед", "ужин", "завтрак", "перекус").any { low.contains(it) } -> "MEAL"
            low.contains("встреч") -> "MEETING"
            listOf("домашк", "дз", "задани").any { low.contains(it) } -> "HOMEWORK"
            listOf("лекци", "пара", "семинар", "урок").any { low.contains(it) } -> "COURSE"
            listOf("намаз", "коран", "зикр", "дуа", "тахаджуд").any { low.contains(it) } -> "RELIGION"
            listOf("отдых", "прогулк").any { low.contains(it) } -> "REST"
            else -> cat
        }
        return EventEntityDraft(title, c, st)
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Быстрое добавление", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                text, { text = it; warn = null }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Что запланировать?") }, placeholder = { Text("Например: Тренировка 18:00") }
            )
            ChipsRow {
                sn.categories.forEach { c ->
                    FilterChip(selected = cat == c.id, onClick = { cat = c.id }, label = { Text(c.name) },
                        leadingIcon = { ColorDot(c.color, 10) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("Дата", date, { date = it }, Modifier.weight(1f))
                TimeField("Начало", start, { start = it }, Modifier.weight(1f))
            }
            ChoiceChips(listOf(15, 30, 45, 60, 90, 120).map { it to fmtDur(it) }, dur) { dur = it }
            warn?.let { Text("⚠ $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val d = build()
                    onDismiss(); onDetailed(Route.EventEdit(0, date, d.category))
                }, Modifier.weight(1f)) { Text("Подробнее") }
                Button(onClick = {
                    val d = build()
                    if (d.title.isBlank()) { warn = "Введите название"; return@Button }
                    val ev = com.deenlife.data.EventEntity(
                        title = d.title, category = d.category, color = sn.catColor(d.category), startDay = date,
                        startMin = d.start, endMin = d.start + dur, reminderMin = 10
                    )
                    val c = conflictFor(sn, ev, 0)
                    if (c != null && warn == null) { warn = "$c. Нажмите «Добавить» ещё раз, чтобы сохранить всё равно."; return@Button }
                    vm.saveEvent(ev); onDismiss()
                }, Modifier.weight(1f)) { Text("Добавить") }
            }
        }
    }
}

private data class EventEntityDraft(val title: String, val category: String, val start: Int)
