package com.deenlife.ui.study

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.deenlife.data.CourseEntity
import com.deenlife.data.HomeworkEntity
import com.deenlife.domain.*
import com.deenlife.ui.*
import com.deenlife.ui.common.*
import com.deenlife.util.*
import kotlinx.coroutines.delay

@Composable
fun StudyScreen(vm: AppViewModel, sn: Snapshot, nav: Nav) {
    val titles = listOf("Занятия", "Задания", "Учёт времени", "Статистика")
    Column(Modifier.fillMaxSize()) {
        Text("Учёба", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp))
        ScrollableTabRow(selectedTabIndex = nav.studyPage, edgePadding = 8.dp, containerColor = MaterialTheme.colorScheme.background) {
            titles.forEachIndexed { i, t -> Tab(selected = nav.studyPage == i, onClick = { nav.studyPage = i }, text = { Text(t) }) }
        }
        when (nav.studyPage) {
            0 -> CoursesPage(vm, sn)
            1 -> HomeworkPage(vm, sn)
            2 -> TimePage(vm, sn)
            else -> StudyStatsPage(sn)
        }
    }
}

// ---------------------------------------------------------------- Занятия

@Composable
private fun CoursesPage(vm: AppViewModel, sn: Snapshot) {
    var edit by remember { mutableStateOf<CourseEntity?>(null) }
    var delete by remember { mutableStateOf<CourseEntity?>(null) }
    var help by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> uri?.let { vm.importCourses(it) } }
    val today = isoDay(todayEpoch())

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    edit = CourseEntity(name = "", dayOfWeek = today, startMin = 9 * 60, endMin = 10 * 60 + 30, color = PALETTE[0])
                }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("Занятие") }
                OutlinedButton(onClick = { help = true }) { Icon(Icons.Rounded.FileUpload, null); Spacer(Modifier.width(4.dp)); Text("Импорт") }
            }
        }
        if (sn.courses.isEmpty()) item { EmptyHint("Добавьте занятия вручную или импортируйте расписание из файла CSV.") }
        (1..7).forEach { d ->
            val list = sn.courses.filter { it.dayOfWeek == d }.sortedBy { it.startMin }
            if (list.isNotEmpty()) {
                item(key = "h$d") { SectionTitle(RU_DAYS_FULL[d - 1] + if (d in sn.settings.weekend) " (выходной)" else "") }
                items(list, key = { it.id }) { c ->
                    AppCard(Modifier.fillMaxWidth(), onClick = { edit = c }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ColorDot(c.color, 14)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(
                                    listOf("${fmtTime(c.startMin)}–${fmtTime(c.endMin)}", c.teacher, if (c.room.isNotBlank()) "ауд. ${c.room}" else "").filter { it.isNotBlank() }.joinToString(" · "),
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { delete = c }) { Icon(Icons.Rounded.Delete, "Удалить", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
            }
        }
    }
    edit?.let { CourseDialog(it, onDismiss = { edit = null }) { c -> vm.saveCourse(c); edit = null } }
    delete?.let { c -> ConfirmDialog("Удалить занятие?", "«${c.name}» будет удалено из расписания.", onDismiss = { delete = null }) { vm.deleteCourse(c.id) } }
    if (help) AlertDialog(
        onDismissRequest = { help = false }, title = { Text("Импорт расписания") }, text = { Text(Backup.CSV_HELP) },
        confirmButton = { TextButton(onClick = { help = false; picker.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel", "*/*")) }) { Text("Выбрать файл") } },
        dismissButton = { TextButton(onClick = { help = false }) { Text("Отмена") } }
    )
}

@Composable
private fun CourseDialog(initial: CourseEntity, onDismiss: () -> Unit, onSave: (CourseEntity) -> Unit) {
    var c by remember { mutableStateOf(initial) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.id == 0L) "Новое занятие" else "Занятие") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScrollCompat()) {
                OutlinedTextField(c.name, { c = c.copy(name = it) }, label = { Text("Предмет") }, singleLine = true)
                OutlinedTextField(c.teacher, { c = c.copy(teacher = it) }, label = { Text("Преподаватель") }, singleLine = true)
                OutlinedTextField(c.room, { c = c.copy(room = it) }, label = { Text("Аудитория") }, singleLine = true)
                ChipsRow { RU_DAYS_SHORT.forEachIndexed { i, n -> FilterChip(selected = c.dayOfWeek == i + 1, onClick = { c = c.copy(dayOfWeek = i + 1) }, label = { Text(n) }) } }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TimeField("С", c.startMin, { c = c.copy(startMin = it, endMin = if (c.endMin <= it) minOf(it + 90, 1439) else c.endMin) }, Modifier.weight(1f))
                    TimeField("До", c.endMin, { c = c.copy(endMin = it) }, Modifier.weight(1f))
                }
                Text("Напоминание", style = MaterialTheme.typography.labelMedium)
                ChoiceChips(listOf(-1 to "Нет", 5 to "5 мин", 15 to "15 мин", 30 to "30 мин", 60 to "1 час"), c.reminderMin) { c = c.copy(reminderMin = it) }
                ColorPickerRow(c.color) { c = c.copy(color = it) }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    c.name.isBlank() -> err = "Введите название предмета"
                    c.endMin <= c.startMin -> err = "Конец должен быть позже начала"
                    else -> onSave(c.copy(name = c.name.trim()))
                }
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun Modifier.verticalScrollCompat(): Modifier = this.verticalScroll(rememberScrollState())

// ---------------------------------------------------------------- Задания

@Composable
private fun HomeworkPage(vm: AppViewModel, sn: Snapshot) {
    var edit by remember { mutableStateOf<HomeworkEntity?>(null) }
    var showDone by remember { mutableStateOf(false) }
    val today = todayEpoch()
    val open = sn.homework.filter { !it.done }.sortedBy { it.deadlineDay * 1440 + it.deadlineMin }
    val done = sn.homework.filter { it.done }.sortedByDescending { it.deadlineDay }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Button(onClick = { edit = HomeworkEntity(title = "", deadlineDay = today + 1) }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("Домашнее задание") } }
        if (open.isEmpty()) item { EmptyHint("Нет активных заданий. Добавьте задание с дедлайном — придёт напоминание.") }
        items(open, key = { it.id }) { h -> HwCard(vm, h, today) { edit = h } }
        if (done.isNotEmpty()) {
            item { TextButton(onClick = { showDone = !showDone }) { Text(if (showDone) "Скрыть выполненные" else "Выполненные (${done.size})") } }
            if (showDone) items(done, key = { "d${it.id}" }) { h -> HwCard(vm, h, today) { edit = h } }
        }
    }
    edit?.let { h ->
        var v by remember(h) { mutableStateOf(h) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { edit = null },
            title = { Text(if (h.id == 0L) "Новое задание" else "Задание") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScrollCompat()) {
                    OutlinedTextField(v.title, { v = v.copy(title = it) }, label = { Text("Что нужно сделать") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(v.course, { v = v.copy(course = it) }, label = { Text("Предмет") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    ChipsRow { sn.courses.map { it.name }.distinct().forEach { n -> AssistChip(onClick = { v = v.copy(course = n) }, label = { Text(n) }) } }
                    DateField("Срок", v.deadlineDay, { v = v.copy(deadlineDay = it) }, Modifier.fillMaxWidth())
                    TimeField("Время", v.deadlineMin, { v = v.copy(deadlineMin = it) }, Modifier.fillMaxWidth())
                    NumberField("Оценка времени", v.estMin, { v = v.copy(estMin = it) }, Modifier.fillMaxWidth(), "мин")
                    OutlinedTextField(v.notes, { v = v.copy(notes = it) }, label = { Text("Заметки") }, modifier = Modifier.fillMaxWidth())
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = { TextButton(onClick = { if (v.title.isBlank()) err = "Введите описание" else { vm.saveHomework(v.copy(title = v.title.trim(), estMin = if (v.estMin <= 0) 60 else v.estMin)); edit = null } }) { Text("Сохранить") } },
            dismissButton = {
                Row {
                    if (h.id != 0L) TextButton(onClick = { vm.deleteHomework(h.id); edit = null }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                    TextButton(onClick = { edit = null }) { Text("Отмена") }
                }
            }
        )
    }
}

@Composable
private fun HwCard(vm: AppViewModel, h: HomeworkEntity, today: Long, onEdit: () -> Unit) {
    val overdue = !h.done && (h.deadlineDay < today || (h.deadlineDay == today && h.deadlineMin < nowMinute()))
    AppCard(Modifier.fillMaxWidth(), onClick = onEdit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CheckCircle(h.done, { vm.toggleHomework(h) })
            Column(Modifier.weight(1f)) {
                Text(h.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, textDecoration = if (h.done) TextDecoration.LineThrough else null)
                val left = (h.deadlineDay - today).toInt()
                val whenTxt = when { left == 0 -> "сегодня"; left == 1 -> "завтра"; left < 0 -> "просрочено на ${-left} дн."; else -> "через $left дн." }
                Text(
                    listOf(h.course, "${shortDate(h.deadlineDay)} ${fmtTime(h.deadlineMin)} ($whenTxt)", "~${fmtDur(h.estMin)}").filter { it.isNotBlank() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall, color = if (overdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (overdue) TextButton(onClick = { vm.saveHomework(h.copy(deadlineDay = today + 1)) }) { Text("На завтра") }
        }
    }
}

// ---------------------------------------------------------------- Учёт времени

@Composable
private fun TimePage(vm: AppViewModel, sn: Snapshot) {
    val s = sn.settings
    val today = todayEpoch()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(s.studyTimerStart) { while (s.studyTimerStart != 0L) { now = System.currentTimeMillis(); delay(1000) } }
    var subject by remember { mutableStateOf("") }
    var manual by remember { mutableIntStateOf(30) }
    var goalH by remember(s.studyGoalMin) { mutableIntStateOf(s.studyGoalMin) }

    val items = Timeline.build(today, sn, prayers = false, sleep = false)
    val planned = items.filter { it.kind == Kind.EVENT && (it.category == "SELF_STUDY" || it.category == "HOMEWORK") }.sumOf { it.minutes }
    val logged = sn.studyLogs.filter { it.day == today }.sumOf { it.minutes }
    val goal = if (isoDay(today) in s.weekend) s.studyGoalMin / 2 else s.studyGoalMin
    val progress = if (goal == 0) 0f else (logged.toFloat() / goal).coerceIn(0f, 1f)
    val running = s.studyTimerStart != 0L

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(progress, 84, 10, label = "${(progress * 100).toInt()}%")
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("Сегодня: ${fmtDur(logged)} из ${fmtDur(goal)}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text("В плане самоподготовки: ${fmtDur(planned)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (isoDay(today) in s.weekend) Text("Выходной: цель вдвое меньше", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("Таймер", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                if (running) {
                    val sec = ((now - s.studyTimerStart) / 1000).coerceAtLeast(0)
                    Text("%02d:%02d:%02d".format(sec / 3600, sec % 3600 / 60, sec % 60), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                    if (s.studyTimerSubject.isNotBlank()) Text(s.studyTimerSubject, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { vm.stopStudyTimer() }) { Icon(Icons.Rounded.Stop, null); Spacer(Modifier.width(4.dp)); Text("Остановить и записать") }
                } else {
                    OutlinedTextField(subject, { subject = it }, label = { Text("Предмет (необязательно)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    ChipsRow(Modifier.padding(vertical = 4.dp)) { sn.courses.map { it.name }.distinct().forEach { n -> AssistChip(onClick = { subject = n }, label = { Text(n) }) } }
                    Button(onClick = { vm.startStudyTimer(subject.trim()) }) { Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("Начать учёбу") }
                }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("Добавить вручную", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                NumberField("Минут", manual, { manual = it }, Modifier.fillMaxWidth(), "мин")
                ChipsRow(Modifier.padding(vertical = 4.dp)) { listOf(15, 30, 45, 60, 90, 120).forEach { AssistChip(onClick = { manual = it }, label = { Text(fmtDur(it)) }) } }
                Button(onClick = { if (manual > 0) vm.addStudy(manual, subject.trim()) else vm.say("Введите время") }) { Text("Записать") }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("Цель на день (часов в будни)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { goalH = (goalH - 30).coerceAtLeast(0); vm.updateSettings { it.copy(studyGoalMin = goalH) } }) { Icon(Icons.Rounded.Remove, "Меньше") }
                    Text(fmtDur(goalH), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    IconButton(onClick = { goalH = (goalH + 30).coerceAtMost(960); vm.updateSettings { it.copy(studyGoalMin = goalH) } }) { Icon(Icons.Rounded.Add, "Больше") }
                }
            }
        }
        item { SectionTitle("Записи за сегодня") }
        val todays = sn.studyLogs.filter { it.day == today }.sortedByDescending { it.id }
        if (todays.isEmpty()) item { EmptyHint("Пока нет записей") }
        items(todays, key = { it.id }) { l ->
            AppCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(fmtDur(l.minutes), fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp))
                    Text(l.subject.ifBlank { "Без предмета" }, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    IconButton(onClick = { vm.deleteStudy(l.id) }) { Icon(Icons.Rounded.Delete, "Удалить") }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Статистика

@Composable
private fun StudyStatsPage(sn: Snapshot) {
    val today = todayEpoch()
    var month by remember { mutableStateOf(false) }
    val n = if (month) 30 else 7
    val st = remember(sn, today, n) { Stats.days(sn, today - n + 1, today) }
    val goal = sn.settings.studyGoalMin
    val total = st.sumOf { it.studyMin }
    val bySubject = remember(sn, n) {
        sn.studyLogs.filter { it.day > today - n }.groupBy { it.subject.ifBlank { "Без предмета" } }.mapValues { e -> e.value.sumOf { it.minutes } }.toList().sortedByDescending { it.second }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ChoiceChips(listOf(false to "Неделя", true to "Месяц"), month) { month = it } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Всего", fmtDur(total), Modifier.weight(1f))
                StatTile("В среднем в день", fmtDur(total / n), Modifier.weight(1f))
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("Время учёбы по дням (мин)", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                BarChart(
                    st.map { it.studyMin.toFloat() },
                    st.map { if (month) "${com.deenlife.util.shortDate(it.day).substringBefore(' ')}" else RU_DAYS_SHORT[isoDay(it.day) - 1] },
                    target = goal.toFloat()
                )
                Text("Линия — дневная цель", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (bySubject.isNotEmpty()) {
            item { SectionTitle("По предметам") }
            items(bySubject, key = { it.first }) { (name, min) ->
                AppCard(Modifier.fillMaxWidth()) {
                    Row { Text(name, Modifier.weight(1f)); Text(fmtDur(min), fontWeight = FontWeight.SemiBold) }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { min.toFloat() / (bySubject.first().second.coerceAtLeast(1)) }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}
