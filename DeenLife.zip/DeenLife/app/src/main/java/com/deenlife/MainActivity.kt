package com.deenlife

import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.deenlife.ui.AppRoot
import com.deenlife.ui.AppViewModel
import com.deenlife.ui.theme.DeenLifeTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val snap by vm.snapshot.collectAsState()
            val mode = snap?.settings?.theme ?: 0
            DeenLifeTheme(mode) {
                val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
                val bg = MaterialTheme.colorScheme.background
                val view = LocalView.current
                SideEffect {
                    window.setBackgroundDrawable(ColorDrawable(bg.toArgb()))
                    val c = WindowCompat.getInsetsController(window, view)
                    c.isAppearanceLightStatusBars = !dark
                    c.isAppearanceLightNavigationBars = !dark
                }
                Surface(Modifier.fillMaxSize(), color = bg) {
                    val s = snap
                    if (s == null) Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                    else AppRoot(vm, s)
                }
            }
        }
    }
}
