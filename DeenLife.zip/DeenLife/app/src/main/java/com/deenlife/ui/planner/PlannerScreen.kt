package com.deenlife.ui.planner

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.deenlife.data.EventEntity
import com.deenlife.domain.*
import com.deenlife.ui.AppViewModel
import com.deenlife.ui.common.*
import com.deenlife.ui.home.SuggestionCard
import com.deenlife.util.*

@Composable
fun PlannerScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val clock by vm.clock.collectAsState()
    val today = clock.toLocalDate().toEpochDay()
    val nowMin = clock.hour * 60 + clock.minute
    val suggestions = remember(sn, today, nowMin / 5) { Planner.analyze(sn, today, nowMin) }

    var scope by rememberSaveable { mutableIntStateOf(0) }     // 0 сегодня, 1 завтра, 2 неделя
    var plan by remember { mutableStateOf<List<EventEntity>?>(null) }
    var selected by remember { mutableStateOf<Set<Int>>(emptySet()) }

    fun generate() {
        val (start, days) = when (scope) { 0 -> today to 1; 1 -> today + 1 to 1; else -> today to 7 }
        val p = Planner.generate(start, days, sn, nowMin, isToday = start == today)
        plan = p
        selected = p.indices.toSet()
        if (p.isEmpty()) vm.say("Свободного времени для новых дел не нашлось — расписание уже плотное")
    }

    ScreenScaffold("Помощник", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(8.dp))
                        Text("Составить расписание", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    }
                    Text(
                        "Помощник учтёт пары, намазы, сон, цель по учёбе, дедлайны и тренировки, и предложит свободные окна. Ничего не добавится, пока вы не подтвердите.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    ChoiceChips(listOf(0 to "На сегодня", 1 to "На завтра", 2 to "На неделю"), scope) { scope = it; plan = null }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { generate() }) { Text("Составить план") }
                }
            }
            plan?.let { p ->
                if (p.isNotEmpty()) {
                    item { SectionTitle("Предлагаемый план") }
                    items(p.indices.toList(), key = { it }) { i ->
                        val e = p[i]
                        AppCard(Modifier.fillMaxWidth(), onClick = { selected = if (i in selected) selected - i else selected + i }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(i in selected, { selected = if (it) selected + i else selected - i })
                                Column(Modifier.weight(1f)) {
                                    Text(e.title, style = MaterialTheme.typography.titleSmall)
                                    Text("${shortDate(e.startDay)} · ${fmtTime(e.startMin)}–${fmtTime(e.endMin)} · ${sn.catName(e.category)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    item {
                        Button(onClick = { vm.applyEvents(selected.sorted().map { p[it] }); plan = null }, enabled = selected.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                            Text("Добавить в расписание (${selected.size})")
                        }
                    }
                }
            }
            item { SectionTitle("Анализ расписания") }
            if (suggestions.isEmpty()) item { EmptyHint("Всё хорошо: пересечений и пропусков не найдено.") }
            items(suggestions, key = { it.id }) { SuggestionCard(vm, it) }
        }
    }
}
