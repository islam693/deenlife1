package com.deenlife.ui.sleep

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.deenlife.data.SleepLogEntity
import com.deenlife.domain.*
import com.deenlife.ui.AppViewModel
import com.deenlife.ui.common.*
import com.deenlife.util.*

private fun nightMinutes(bed: Int, wake: Int) = if (bed >= wake) 1440 - bed + wake else wake - bed

@Composable
fun SleepScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val s = sn.settings
    val today = todayEpoch()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var dayEdit by remember { mutableStateOf<Int?>(null) }
    var logDlg by remember { mutableStateOf(false) }
    var month by remember { mutableStateOf(false) }

    ScreenScaffold("Сон и режим", onBack) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                listOf("График", "Журнал", "Статистика").forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        AppCard(Modifier.fillMaxWidth()) {
                            Text("Желаемая длительность сна", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            ChoiceChips(listOf(360, 420, 450, 480, 510, 540).map { it to fmtDur(it) }, s.sleepGoalMin) { v -> vm.updateSettings { it.copy(sleepGoalMin = v) } }
                            Spacer(Modifier.height(8.dp))
                            Text("Напоминать о подготовке ко сну за", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            ChoiceChips(listOf(15, 30, 45, 60).map { it to "$it мин" }, s.bedPrep) { v -> vm.updateSettings { it.copy(bedPrep = v) } }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Напоминание о подготовке ко сну", Modifier.weight(1f)); Switch(s.nSleep, { v -> vm.updateSettings { it.copy(nSleep = v) } })
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Напоминание о подъёме", Modifier.weight(1f)); Switch(s.nWake, { v -> vm.updateSettings { it.copy(nWake = v) } })
                            }
                        }
                    }
                    item { SectionTitle("График по дням недели") }
                    items((0..6).toList(), key = { it }) { i ->
                        val dur = nightMinutes(s.bed[i], s.wake[i])
                        val ok = dur >= s.sleepGoalMin - 15
                        AppCard(Modifier.fillMaxWidth(), onClick = { dayEdit = i }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(RU_DAYS_FULL[i], Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${fmtTime(s.bed[i])} → ${fmtTime(s.wake[i])}", fontWeight = FontWeight.SemiBold)
                                    Text(fmtDur(dur), style = MaterialTheme.typography.bodySmall, color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                    item { Text("Отбой указывается вечером этого дня недели, подъём — утром следующего.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
                1 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Button(onClick = { logDlg = true }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("Записать ночь") } }
                    val logs = sn.sleepLogs.sortedByDescending { it.day }
                    if (logs.isEmpty()) item { EmptyHint("Записывайте время отбоя и подъёма — приложение посчитает среднее и сравнит с целью.") }
                    items(logs, key = { it.day }) { l ->
                        AppCard(Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Ночь на ${shortDate(l.day + 1)}", style = MaterialTheme.typography.titleSmall)
                                    Text("${fmtTime(l.bedMin)} → ${fmtTime(l.wakeMin)} · ${fmtDur(l.minutes)}", style = MaterialTheme.typography.bodySmall, color = if (l.minutes >= s.sleepGoalMin - 15) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                }
                                IconButton(onClick = { vm.deleteSleep(l.day) }) { Icon(Icons.Rounded.Delete, "Удалить") }
                            }
                        }
                    }
                }
                else -> {
                    val n = if (month) 30 else 7
                    val days = (0 until n).map { today - (n - 1) + it }
                    val vals = days.map { d -> sn.sleepLogs.firstOrNull { it.day == d - 1 }?.minutes?.toFloat() ?: 0f }
                    val logged = vals.filter { it > 0 }
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { ChoiceChips(listOf(false to "Неделя", true to "Месяц"), month) { month = it } }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                StatTile("Среднее", if (logged.isEmpty()) "—" else fmtDur(logged.average().toInt()), Modifier.weight(1f))
                                StatTile("Цель", fmtDur(s.sleepGoalMin), Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
                            }
                        }
                        item {
                            AppCard(Modifier.fillMaxWidth()) {
                                Text("Продолжительность сна (мин)", style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.height(8.dp))
                                BarChart(vals, days.map { if (month) shortDate(it).substringBefore(' ') else RU_DAYS_SHORT[isoDay(it) - 1] }, target = s.sleepGoalMin.toFloat())
                            }
                        }
                        item {
                            val ok = logged.count { it >= s.sleepGoalMin - 15 }
                            Text("Ночей с выполненной целью: $ok из ${logged.size}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }

    dayEdit?.let { i ->
        var bed by remember { mutableIntStateOf(s.bed[i]) }
        var wake by remember { mutableIntStateOf(s.wake[i]) }
        var all by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { dayEdit = null }, title = { Text(RU_DAYS_FULL[i]) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TimeField("Отбой", bed, { bed = it }, Modifier.fillMaxWidth())
                    TimeField("Подъём", wake, { wake = it }, Modifier.fillMaxWidth())
                    Text("Сон: ${fmtDur(nightMinutes(bed, wake))}", style = MaterialTheme.typography.bodyMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(all, { all = it }); Text("Применить ко всем дням") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updateSettings { st ->
                        st.copy(
                            bed = st.bed.mapIndexed { k, v -> if (all || k == i) bed else v },
                            wake = st.wake.mapIndexed { k, v -> if (all || k == i) wake else v }
                        )
                    }
                    dayEdit = null
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { dayEdit = null }) { Text("Отмена") } }
        )
    }
    if (logDlg) {
        var night by remember { mutableLongStateOf(today - 1) }
        var bed by remember { mutableIntStateOf(s.bed[isoDay(today - 1) - 1]) }
        var wake by remember { mutableIntStateOf(s.wake[isoDay(today) - 1]) }
        AlertDialog(
            onDismissRequest = { logDlg = false }, title = { Text("Запись о сне") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateField("Вечер", night, { night = it }, Modifier.fillMaxWidth())
                    TimeField("Лёг", bed, { bed = it }, Modifier.fillMaxWidth())
                    TimeField("Проснулся", wake, { wake = it }, Modifier.fillMaxWidth())
                    Text("Сон: ${fmtDur(nightMinutes(bed, wake))}")
                }
            },
            confirmButton = { TextButton(onClick = { vm.saveSleep(SleepLogEntity(night, bed, wake)); logDlg = false }) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { logDlg = false }) { Text("Отмена") } }
        )
    }
}
