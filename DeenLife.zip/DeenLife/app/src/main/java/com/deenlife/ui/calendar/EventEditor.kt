package com.deenlife.ui.calendar

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.deenlife.data.EventEntity
import com.deenlife.domain.*
import com.deenlife.ui.AppViewModel
import com.deenlife.ui.Route
import com.deenlife.ui.common.*
import com.deenlife.util.*

private val REMINDERS = listOf(-1 to "Нет", 0 to "В момент начала", 5 to "За 5 мин", 10 to "За 10 мин", 15 to "За 15 мин", 30 to "За 30 мин", 60 to "За 1 час", 1440 to "За 1 день")

@Composable
fun EventEditorScreen(vm: AppViewModel, sn: Snapshot, route: Route.EventEdit, onBack: () -> Unit) {
    val existing = remember(route.id) { sn.events.firstOrNull { it.id == route.id } }
    val defCat = route.category ?: existing?.category ?: "PERSONAL"
    var title by rememberSaveable { mutableStateOf(existing?.title ?: "") }
    var cat by rememberSaveable { mutableStateOf(defCat) }
    var color by rememberSaveable { mutableIntStateOf(existing?.color ?: sn.catColor(defCat)) }
    var day by rememberSaveable { mutableLongStateOf(existing?.startDay ?: route.day) }
    var start by rememberSaveable { mutableIntStateOf(existing?.startMin ?: ((nowMinute() + 29) / 30 * 30).coerceAtMost(22 * 60)) }
    var end by rememberSaveable { mutableIntStateOf(existing?.endMin ?: (start + 60)) }
    var repeat by rememberSaveable { mutableIntStateOf(existing?.repeat ?: 0) }
    var days by rememberSaveable { mutableStateOf((existing?.let { maskDays(it.repeatDays) } ?: setOf(isoDay(route.day))).toList()) }
    var rem by rememberSaveable { mutableIntStateOf(existing?.reminderMin ?: 10) }
    var notes by rememberSaveable { mutableStateOf(existing?.notes ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var ignoreConflict by remember { mutableStateOf(false) }

    val duration = end - start

    fun draft() = EventEntity(
        id = existing?.id ?: 0, title = title.trim(), category = cat, color = color, startDay = day, startMin = start, endMin = end,
        repeat = repeat, repeatDays = if (repeat == 3) daysMask(days.toSet()) else 0, reminderMin = rem, notes = notes.trim(),
        source = existing?.source ?: "user"
    )

    ScreenScaffold(
        title = if (existing == null) "Новое событие" else "Событие", onBack = onBack,
        actions = { if (existing != null) IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, "Удалить") } }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(title, { title = it; error = null }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth(), isError = error != null && title.isBlank())

            Text("Категория", style = MaterialTheme.typography.labelLarge)
            ChipsRow {
                sn.categories.forEach { c ->
                    FilterChip(selected = cat == c.id, onClick = { cat = c.id; color = c.color }, label = { Text(c.name) }, leadingIcon = { ColorDot(c.color, 10) })
                }
            }
            Text("Цвет", style = MaterialTheme.typography.labelLarge)
            ColorPickerRow(color) { color = it }

            DateField("Дата", day, { day = it }, Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TimeField("Начало", start, { start = it; if (end <= start) end = minOf(start + 60, 1439) }, Modifier.weight(1f))
                TimeField("Конец", end, { end = it }, Modifier.weight(1f))
            }
            Text(
                if (duration > 0) "Продолжительность: ${fmtDur(duration)}" else "Конец должен быть позже начала (после полуночи — укажите ниже)",
                style = MaterialTheme.typography.bodySmall, color = if (duration > 0) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error
            )
            ChipsRow {
                listOf(15, 30, 45, 60, 90, 120, 180).forEach { m -> AssistChip(onClick = { end = start + m }, label = { Text(fmtDur(m)) }) }
            }
            if (end > 1440) Text("Событие закончится после полуночи — в ${fmtTime(end)}", style = MaterialTheme.typography.bodySmall)

            Text("Повторение", style = MaterialTheme.typography.labelLarge)
            ChoiceChips(listOf(0 to "Нет", 1 to "Ежедневно", 2 to "Еженедельно", 3 to "По дням"), repeat) { repeat = it }
            if (repeat == 3) WeekdayChips(days.toSet()) { days = it.toList() }

            Text("Напоминание", style = MaterialTheme.typography.labelLarge)
            ChoiceChips(REMINDERS, rem) { rem = it }

            OutlinedTextField(notes, { notes = it }, label = { Text("Заметки") }, modifier = Modifier.fillMaxWidth().heightIn(min = 96.dp))

            val conflict = remember(title, cat, day, start, end, repeat, days) { conflictFor(sn, draft(), existing?.id ?: 0) }
            if (conflict != null) Text("⚠ $conflict", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

            Button(
                onClick = {
                    when {
                        title.isBlank() -> error = "Введите название"
                        end <= start -> error = "Время окончания должно быть позже начала"
                        repeat == 3 && days.isEmpty() -> error = "Выберите хотя бы один день недели"
                        conflict != null && !ignoreConflict -> { ignoreConflict = true; error = "Есть пересечение. Нажмите ещё раз, чтобы сохранить всё равно." }
                        else -> { vm.saveEvent(draft()); onBack() }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(if (conflict != null && ignoreConflict) "Сохранить всё равно" else "Сохранить") }
        }
    }
    if (confirmDelete && existing != null) ConfirmDialog(
        "Удалить событие?",
        if (existing.repeat != 0) "Будут удалены все повторения." else "«${existing.title}» будет удалено.",
        onDismiss = { confirmDelete = false }
    ) { vm.deleteEvent(existing.id); onBack() }
}
