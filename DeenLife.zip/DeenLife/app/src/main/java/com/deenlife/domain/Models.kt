package com.deenlife.domain

import com.deenlife.data.CategoryEntity
import com.deenlife.data.EventEntity
import com.deenlife.util.isoDay

fun argb(hex: Long): Int = (0xFF000000L or hex).toInt()

val PALETTE: List<Int> = listOf(
    argb(0x34C38F), argb(0x3AA0E8), argb(0x7C6CF0), argb(0xE0B65A), argb(0xF08A4B), argb(0xE5575F),
    argb(0xE86FB0), argb(0x2EC4C4), argb(0x8BC34A), argb(0x9E9E9E)
)

val DEFAULT_CATEGORIES: List<CategoryEntity> = listOf(
    CategoryEntity("COURSE", "Учебная пара", argb(0x3AA0E8), true, 0),
    CategoryEntity("SELF_STUDY", "Самоподготовка", argb(0x7C6CF0), true, 1),
    CategoryEntity("HOMEWORK", "Домашнее задание", argb(0xF08A4B), true, 2),
    CategoryEntity("WORKOUT", "Тренировка", argb(0xE5575F), true, 3),
    CategoryEntity("MEAL", "Приём пищи", argb(0x8BC34A), true, 4),
    CategoryEntity("SLEEP", "Сон", argb(0x5C6BC0), true, 5),
    CategoryEntity("WAKE", "Подъём", argb(0xE0B65A), true, 6),
    CategoryEntity("REST", "Отдых", argb(0x2EC4C4), true, 7),
    CategoryEntity("PERSONAL", "Личные дела", argb(0xE86FB0), true, 8),
    CategoryEntity("MEETING", "Встреча", argb(0x9E9E9E), true, 9),
    CategoryEntity("RELIGION", "Религиозные обязанности", argb(0x34C38F), true, 10)
)

// ---------------- Повторяющиеся события ----------------

fun EventEntity.occursOn(day: Long): Boolean {
    if (day < startDay) return false
    return when (repeat) {
        0 -> day == startDay
        1 -> true
        2 -> (day - startDay) % 7 == 0L
        3 -> (repeatDays shr (isoDay(day) - 1)) and 1 == 1
        else -> false
    }
}

fun daysMask(days: Set<Int>): Int = days.fold(0) { acc, d -> acc or (1 shl (d - 1)) }
fun maskDays(mask: Int): Set<Int> = (1..7).filter { (mask shr (it - 1)) and 1 == 1 }.toSet()

// ---------------- Метод расчёта намаза ----------------

enum class CalcMethod(val title: String, val fajr: Double, val isha: Double, val ishaMin: Int = 0) {
    RUSSIA("ДУМ / Россия (16° / 15°)", 16.0, 15.0),
    MWL("Всемирная исламская лига (18° / 17°)", 18.0, 17.0),
    ISNA("ISNA, Северная Америка (15° / 15°)", 15.0, 15.0),
    EGYPT("Египетское управление (19.5° / 17.5°)", 19.5, 17.5),
    MAKKAH("Умм аль-Кура, Мекка (18.5° / Иша +90 мин)", 18.5, 0.0, 90),
    KARACHI("Карачи (18° / 18°)", 18.0, 18.0),
    TURKEY("Диянет, Турция (18° / 17°)", 18.0, 17.0),
    KUWAIT("Кувейт (18° / 17.5°)", 18.0, 17.5),
    QATAR("Катар (18° / Иша +90 мин)", 18.0, 0.0, 90),
    SINGAPORE("Сингапур / Малайзия (20° / 18°)", 20.0, 18.0);

    companion object {
        fun of(id: String): CalcMethod = entries.firstOrNull { it.name == id } ?: RUSSIA
    }
}

data class City(val name: String, val lat: Double, val lng: Double, val tz: String)

val CITIES: List<City> = listOf(
    City("Москва", 55.7558, 37.6173, "Europe/Moscow"),
    City("Санкт-Петербург", 59.9343, 30.3351, "Europe/Moscow"),
    City("Казань", 55.7887, 49.1221, "Europe/Moscow"),
    City("Уфа", 54.7388, 55.9721, "Asia/Yekaterinburg"),
    City("Махачкала", 42.9849, 47.5047, "Europe/Moscow"),
    City("Грозный", 43.3178, 45.6949, "Europe/Moscow"),
    City("Назрань", 43.2263, 44.7686, "Europe/Moscow"),
    City("Нальчик", 43.4981, 43.6189, "Europe/Moscow"),
    City("Черкесск", 44.2269, 42.0578, "Europe/Moscow"),
    City("Владикавказ", 43.0241, 44.6813, "Europe/Moscow"),
    City("Ставрополь", 45.0428, 41.9734, "Europe/Moscow"),
    City("Нижний Новгород", 56.2965, 43.9361, "Europe/Moscow"),
    City("Екатеринбург", 56.8389, 60.6057, "Asia/Yekaterinburg"),
    City("Новосибирск", 55.0084, 82.9357, "Asia/Novosibirsk"),
    City("Астрахань", 46.3497, 48.0408, "Europe/Astrakhan"),
    City("Минск", 53.9006, 27.5590, "Europe/Minsk"),
    City("Астана", 51.1694, 71.4491, "Asia/Almaty"),
    City("Алматы", 43.2220, 76.8512, "Asia/Almaty"),
    City("Ташкент", 41.2995, 69.2401, "Asia/Tashkent"),
    City("Бишкек", 42.8746, 74.5698, "Asia/Bishkek"),
    City("Душанбе", 38.5598, 68.7870, "Asia/Dushanbe"),
    City("Ашхабад", 37.9601, 58.3261, "Asia/Ashgabat"),
    City("Баку", 40.4093, 49.8671, "Asia/Baku"),
    City("Тбилиси", 41.7151, 44.8271, "Asia/Tbilisi"),
    City("Стамбул", 41.0082, 28.9784, "Europe/Istanbul"),
    City("Анкара", 39.9334, 32.8597, "Europe/Istanbul"),
    City("Мекка", 21.3891, 39.8579, "Asia/Riyadh"),
    City("Медина", 24.5247, 39.5692, "Asia/Riyadh"),
    City("Эр-Рияд", 24.7136, 46.6753, "Asia/Riyadh"),
    City("Дубай", 25.2048, 55.2708, "Asia/Dubai"),
    City("Доха", 25.2854, 51.5310, "Asia/Qatar"),
    City("Кувейт", 29.3759, 47.9774, "Asia/Kuwait"),
    City("Амман", 31.9454, 35.9284, "Asia/Amman"),
    City("Каир", 30.0444, 31.2357, "Africa/Cairo"),
    City("Касабланка", 33.5731, -7.5898, "Africa/Casablanca"),
    City("Тегеран", 35.6892, 51.3890, "Asia/Tehran"),
    City("Карачи", 24.8607, 67.0011, "Asia/Karachi"),
    City("Дакка", 23.8103, 90.4125, "Asia/Dhaka"),
    City("Джакарта", -6.2088, 106.8456, "Asia/Jakarta"),
    City("Куала-Лумпур", 3.1390, 101.6869, "Asia/Kuala_Lumpur"),
    City("Лондон", 51.5074, -0.1278, "Europe/London"),
    City("Берлин", 52.5200, 13.4050, "Europe/Berlin"),
    City("Париж", 48.8566, 2.3522, "Europe/Paris"),
    City("Нью-Йорк", 40.7128, -74.0060, "America/New_York")
)

// ---------------- Подсказки помощника ----------------

val MUSCLE_GROUPS = listOf("Грудь", "Спина", "Ноги", "Плечи", "Руки", "Пресс", "Кардио", "Всё тело", "Растяжка")

val ZIKR_PHRASES = listOf(
    "Субхана-Ллах", "Аль-хамду ли-Ллях", "Аллаху акбар",
    "Ля иляха илля-Ллах", "Астагфируллах", "Салават"
)

val FAST_TYPES = mapOf(
    "RAMADAN" to "Рамадан",
    "MONDAY" to "Понедельник",
    "THURSDAY" to "Четверг",
    "WHITE" to "Белые дни (13–15)",
    "VOLUNTARY" to "Добровольный",
    "MAKEUP" to "Восполнение (када)"
)

val PRAYER_NAMES = listOf("Фаджр", "Зухр", "Аср", "Магриб", "Иша")
