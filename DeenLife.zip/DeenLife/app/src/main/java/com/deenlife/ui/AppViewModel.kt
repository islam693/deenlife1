package com.deenlife.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.deenlife.DeenLifeApp
import com.deenlife.data.*
import com.deenlife.domain.*
import com.deenlife.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.ZoneId

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as DeenLifeApp
    private val dao = a.db.dao()
    val prefs = a.prefs

    @Suppress("UNCHECKED_CAST")
    val snapshot: StateFlow<Snapshot?> = combine(
        listOf<Flow<Any?>>(
            dao.events(), dao.statuses(), dao.courses(), dao.homework(), dao.studyLogs(), dao.workouts(),
            dao.sleepLogs(), dao.habits(), dao.habitLogs(), dao.ibadah(), dao.fasts(), dao.quran(),
            dao.zikr(), dao.goals(), dao.categories(), prefs.flow
        )
    ) { v ->
        Snapshot(
            v[0] as List<EventEntity>, v[1] as List<ItemStatus>, v[2] as List<CourseEntity>, v[3] as List<HomeworkEntity>,
            v[4] as List<StudyLogEntity>, v[5] as List<WorkoutEntity>, v[6] as List<SleepLogEntity>, v[7] as List<HabitEntity>,
            v[8] as List<HabitLog>, v[9] as List<IbadahLog>, v[10] as List<FastLog>, v[11] as List<QuranLog>,
            v[12] as List<ZikrLog>, v[13] as List<GoalEntity>, v[14] as List<CategoryEntity>, v[15] as Settings
        ) as Snapshot?
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val clock = MutableStateFlow(LocalDateTime.now())
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 16)

    init {
        viewModelScope.launch {
            while (true) {
                clock.value = LocalDateTime.now()
                delay(15_000)
            }
        }
        refreshWeather()
    }

    fun say(s: String) { messages.tryEmit(s) }
    private val sn: Snapshot get() = snapshot.value!!

    private fun io(block: suspend () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try { block() } catch (t: Throwable) { say("Ошибка: ${t.message ?: t.javaClass.simpleName}") }
            a.reschedule()
        }
    }

    // ---------------- Настройки ----------------
    fun updateSettings(f: (Settings) -> Settings) { prefs.update(f); a.reschedule() }

    fun refreshWeather(force: Boolean = false) {
        val s = prefs.value
        if (!force && System.currentTimeMillis() - s.weatherTs < 45 * 60_000L) return
        viewModelScope.launch(Dispatchers.IO) {
            val r = Weather.fetch(s.lat, s.lng) ?: return@launch
            prefs.update { it.copy(weatherTs = System.currentTimeMillis(), weatherTemp = r.first, weatherCode = r.second) }
        }
    }

    fun useDeviceLocation(): Boolean {
        val loc = Weather.lastKnownLocation(getApplication()) ?: return false
        updateSettings { it.copy(lat = loc.first, lng = loc.second, tzId = ZoneId.systemDefault().id, cityName = "Моё местоположение", weatherTs = 0) }
        refreshWeather(true)
        return true
    }

    fun pickCity(c: City) {
        updateSettings { it.copy(lat = c.lat, lng = c.lng, tzId = c.tz, cityName = c.name, weatherTs = 0) }
        refreshWeather(true)
    }

    // ---------------- События ----------------
    fun saveEvent(e: EventEntity, onDone: (Long) -> Unit = {}) = io { val id = dao.upsertEvent(e); onDone(id) }

    fun deleteEvent(id: Long) = io { dao.deleteEvent(id); dao.deleteEventStatus(id) }

    fun applyEvents(list: List<EventEntity>) = io {
        list.forEach { dao.upsertEvent(it.copy(id = 0)) }
        say("Добавлено событий: ${list.size}")
    }

    fun toggle(item: TItem) = io {
        val s = sn
        when (item.kind) {
            Kind.EVENT, Kind.COURSE ->
                if (item.done) dao.clearStatus(item.id) else dao.setStatus(ItemStatus(item.id, 1))
            Kind.WORKOUT -> s.workouts.firstOrNull { it.id == item.refId }?.let { dao.upsertWorkout(it.copy(done = !it.done)) }
            Kind.HOMEWORK -> s.homework.firstOrNull { it.id == item.refId }?.let { dao.upsertHomework(it.copy(done = !it.done)) }
            Kind.PRAYER -> {
                val kind = if (item.id.startsWith("T:")) "TAHAJJUD" else "P${item.refId}"
                toggleIbadahSync(item.day, kind)
            }
            Kind.SLEEP -> {}
        }
    }

    /** Перенос блока перетаскиванием: [dDays] — сдвиг по дням, [dMin] — по минутам. */
    fun moveItem(item: TItem, dDays: Int, dMin: Int) = io {
        val s = sn
        when (item.kind) {
            Kind.EVENT -> {
                val ev = s.events.firstOrNull { it.id == item.refId } ?: return@io
                if (item.carry) return@io
                val dur = ev.endMin - ev.startMin
                val ns = (ev.startMin + dMin).coerceIn(0, 1439)
                val day = if (ev.repeat == 0 || ev.repeat == 2) ev.startDay + dDays else ev.startDay
                dao.upsertEvent(ev.copy(startDay = day, startMin = ns, endMin = ns + dur))
            }
            Kind.COURSE -> {
                val c = s.courses.firstOrNull { it.id == item.refId } ?: return@io
                val dur = c.endMin - c.startMin
                val ns = (c.startMin + dMin).coerceIn(0, 1439)
                val nd = ((c.dayOfWeek - 1 + dDays) % 7 + 7) % 7 + 1
                dao.upsertCourse(c.copy(dayOfWeek = nd, startMin = ns, endMin = minOf(ns + dur, 1440)))
            }
            Kind.WORKOUT -> {
                val w = s.workouts.firstOrNull { it.id == item.refId } ?: return@io
                dao.upsertWorkout(w.copy(day = w.day + dDays, startMin = (w.startMin + dMin).coerceIn(0, 1439)))
            }
            else -> {}
        }
    }

    /** Помощник: переносит задачу в ближайшее свободное окно. */
    fun moveToNextSlot(item: TItem) = io {
        val s = sn
        val now = nowMinute()
        val today = todayEpoch()
        when (item.kind) {
            Kind.HOMEWORK -> {
                val h = s.homework.firstOrNull { it.id == item.refId } ?: return@io
                dao.upsertHomework(h.copy(deadlineDay = maxOf(h.deadlineDay, today) + 1))
                say("Срок «${h.title}» перенесён на завтра")
            }
            Kind.EVENT -> {
                val ev = s.events.firstOrNull { it.id == item.refId } ?: return@io
                val len = maxOf(15, item.e - item.s)
                val base = if (ev.repeat == 0) s.copy(events = s.events.filter { it.id != ev.id }) else s
                val slot = Planner.findSlot(base, today, now + 5, len) ?: run { say("Нет свободного времени в ближайшие дни"); return@io }
                if (ev.repeat == 0) {
                    dao.upsertEvent(ev.copy(startDay = slot.first, startMin = slot.second, endMin = slot.second + len))
                } else {
                    dao.upsertEvent(ev.copy(id = 0, startDay = slot.first, startMin = slot.second, endMin = slot.second + len, repeat = 0, repeatDays = 0, source = "moved"))
                    dao.setStatus(ItemStatus(item.id, 2))
                }
                say("«${ev.title}» перенесено на ${if (slot.first == today) "сегодня" else shortDate(slot.first)} в ${fmtTime(slot.second)}")
            }
            Kind.WORKOUT -> {
                val w = s.workouts.firstOrNull { it.id == item.refId } ?: return@io
                val base = s.copy(workouts = s.workouts.filter { it.id != w.id })
                val slot = Planner.findSlot(base, today, now + 5, w.durationMin) ?: run { say("Нет свободного времени в ближайшие дни"); return@io }
                dao.upsertWorkout(w.copy(day = slot.first, startMin = slot.second))
                say("Тренировка перенесена на ${if (slot.first == today) "сегодня" else shortDate(slot.first)} в ${fmtTime(slot.second)}")
            }
            else -> {}
        }
    }

    // ---------------- Учёба ----------------
    fun saveCourse(c: CourseEntity) = io { dao.upsertCourse(c) }
    fun deleteCourse(id: Long) = io { dao.deleteCourse(id); dao.deleteCourseStatus(id) }
    fun saveHomework(h: HomeworkEntity) = io { dao.upsertHomework(h) }
    fun deleteHomework(id: Long) = io { dao.deleteHomework(id) }
    fun toggleHomework(h: HomeworkEntity) = io { dao.upsertHomework(h.copy(done = !h.done)) }
    fun addStudy(minutes: Int, subject: String, day: Long = todayEpoch()) = io {
        if (minutes > 0) dao.upsertStudy(StudyLogEntity(day = day, minutes = minutes, subject = subject))
    }
    fun deleteStudy(id: Long) = io { dao.deleteStudy(id) }

    fun startStudyTimer(subject: String) = updateSettings { it.copy(studyTimerStart = System.currentTimeMillis(), studyTimerSubject = subject) }
    fun stopStudyTimer() {
        val s = prefs.value
        if (s.studyTimerStart == 0L) return
        val min = ((System.currentTimeMillis() - s.studyTimerStart) / 60_000L).toInt()
        updateSettings { it.copy(studyTimerStart = 0, studyTimerSubject = "") }
        if (min >= 1) { addStudy(min, s.studyTimerSubject); say("Записано: ${fmtDur(min)}") } else say("Меньше минуты — не записано")
    }

    fun importCourses(uri: Uri) = io {
        val (list, skipped) = Backup.parseCourses(Backup.readText(getApplication(), uri))
        list.forEach { dao.upsertCourse(it) }
        say("Импортировано занятий: ${list.size}" + if (skipped > 0) ", пропущено строк: $skipped" else "")
    }

    // ---------------- Спорт ----------------
    fun saveWorkout(w: WorkoutEntity, repeatWeeks: Int = 0) = io {
        dao.upsertWorkout(w)
        for (i in 1..repeatWeeks) dao.upsertWorkout(w.copy(id = 0, day = w.day + 7L * i, done = false))
    }
    fun deleteWorkout(id: Long) = io { dao.deleteWorkout(id) }
    fun toggleWorkout(w: WorkoutEntity) = io { dao.upsertWorkout(w.copy(done = !w.done)) }

    // ---------------- Сон ----------------
    fun saveSleep(l: SleepLogEntity) = io { dao.upsertSleep(l) }
    fun deleteSleep(day: Long) = io { dao.deleteSleep(day) }

    // ---------------- Привычки ----------------
    fun saveHabit(h: HabitEntity) = io { dao.upsertHabit(h) }
    fun deleteHabit(id: Long) = io { dao.deleteHabit(id); dao.deleteHabitLogs(id) }
    fun toggleHabit(id: Long, day: Long) = io {
        if (sn.habitKeys.contains("$id:$day")) dao.deleteHabitLog(id, day) else dao.insertHabitLog(HabitLog(id, day))
    }

    // ---------------- Ислам ----------------
    private suspend fun toggleIbadahSync(day: Long, kind: String) {
        if (sn.ibadahKeys.contains("$day:$kind")) dao.deleteIbadah(day, kind) else dao.insertIbadah(IbadahLog(day, kind))
    }
    fun toggleIbadah(day: Long, kind: String) = io { toggleIbadahSync(day, kind) }

    fun setFast(day: Long, type: String?) = io { if (type == null) dao.deleteFast(day) else dao.upsertFast(FastLog(day, type)) }
    fun setQuranPages(day: Long, pages: Int) = io { if (pages <= 0) dao.deleteQuran(day) else dao.upsertQuran(QuranLog(day, pages)) }
    fun setZikr(day: Long, phrase: String, count: Int) = io { dao.upsertZikr(ZikrLog(day, phrase, maxOf(0, count))) }

    fun saveGoal(g: GoalEntity) = io { dao.upsertGoal(g) }
    fun deleteGoal(id: Long) = io { dao.deleteGoal(id) }

    // ---------------- Категории ----------------
    fun saveCategory(c: CategoryEntity) = io { dao.upsertCategory(c) }
    fun deleteCategory(id: String) = io {
        sn.events.filter { it.category == id }.forEach { dao.upsertEvent(it.copy(category = "PERSONAL")) }
        dao.deleteCategory(id)
    }

    // ---------------- Резервные копии и обмен ----------------
    fun exportBackup(uri: Uri) = io { Backup.export(getApplication(), uri); say("Резервная копия сохранена") }
    fun restoreBackup(uri: Uri, onDone: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try { Backup.restore(getApplication(), uri); launch(Dispatchers.Main) { onDone() } }
            catch (t: Throwable) { say("Не удалось восстановить: ${t.message}") }
        }
    }
    fun exportIcs(uri: Uri) = io { Backup.writeText(getApplication(), uri, Backup.buildIcs(sn)); say("Расписание экспортировано (.ics)") }
}
