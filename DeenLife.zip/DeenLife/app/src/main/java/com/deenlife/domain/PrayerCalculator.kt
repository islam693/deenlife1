package com.deenlife.domain

import com.deenlife.data.Settings
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** Астрономический расчёт времён намаза (алгоритм PrayTimes). Результаты — часы местного времени (Double). */
object PrayerCalculator {
    data class Raw(
        val fajr: Double, val sunrise: Double, val dhuhr: Double,
        val asr: Double, val maghrib: Double, val isha: Double
    )

    private fun rad(d: Double) = Math.toRadians(d)
    private fun deg(r: Double) = Math.toDegrees(r)
    private fun fixAngle(a: Double): Double { var x = a % 360.0; if (x < 0) x += 360.0; return x }
    private fun fixHour(h: Double): Double { var x = h % 24.0; if (x < 0) x += 24.0; return x }

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year; var m = month
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    /** declination, equation of time */
    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0)
        val eqt = q / 15.0 - ra
        val decl = deg(asin(sin(rad(e)) * sin(rad(l))))
        return decl to eqt
    }

    private fun midDay(jd: Double, t: Double) = fixHour(12 - sunPosition(jd + t).second)

    private fun angleTime(jd: Double, lat: Double, angle: Double, t: Double, ccw: Boolean): Double {
        val decl = sunPosition(jd + t).first
        val noon = midDay(jd, t)
        val v = (-sin(rad(angle)) - sin(rad(decl)) * sin(rad(lat))) / (cos(rad(decl)) * cos(rad(lat)))
        val tt = deg(acos(v)) / 15.0 // NaN, если солнце не достигает угла (высокие широты)
        return noon + if (ccw) -tt else tt
    }

    private fun asrTime(jd: Double, lat: Double, factor: Int, t: Double): Double {
        val decl = sunPosition(jd + t).first
        val angle = -deg(atan(1.0 / (factor + tan(rad(abs(lat - decl))))))
        return angleTime(jd, lat, angle, t, false)
    }

    private fun diff(a: Double, b: Double) = fixHour(b - a)

    fun compute(date: LocalDate, lat: Double, lng: Double, tzHours: Double, m: CalcMethod, asrFactor: Int): Raw {
        val jd = julian(date.year, date.monthValue, date.dayOfMonth) - lng / (15.0 * 24.0)
        var fajr = angleTime(jd, lat, m.fajr, 5.0 / 24, true)
        var sunrise = angleTime(jd, lat, 0.833, 6.0 / 24, true)
        var dhuhr = midDay(jd, 12.0 / 24)
        var asr = asrTime(jd, lat, asrFactor, 13.0 / 24)
        var sunset = angleTime(jd, lat, 0.833, 18.0 / 24, false)
        var isha = if (m.ishaMin > 0) Double.NaN else angleTime(jd, lat, m.isha, 18.0 / 24, false)

        val adj = tzHours - lng / 15.0
        fajr += adj; sunrise += adj; dhuhr += adj; asr += adj; sunset += adj
        if (!isha.isNaN()) isha += adj
        var maghrib = sunset
        if (m.ishaMin > 0) isha = maghrib + m.ishaMin / 60.0

        // высокие широты: ограничение долей ночи (метод «угол/60»)
        val night = diff(sunset, sunrise)
        if (!night.isNaN()) {
            val fp = m.fajr / 60.0 * night
            if (fajr.isNaN() || diff(fajr, sunrise) > fp) fajr = sunrise - fp
            if (m.ishaMin == 0) {
                val ip = m.isha / 60.0 * night
                if (isha.isNaN() || diff(sunset, isha) > ip) isha = sunset + ip
            }
        }
        if (fajr.isNaN()) fajr = sunrise - 1.5
        if (isha.isNaN()) isha = sunset + 1.5
        if (asr.isNaN()) asr = dhuhr + 3.0
        return Raw(fajr, sunrise, dhuhr, asr, maghrib, isha)
    }
}

/** Времена на день в минутах от полуночи ЛОКАЛЬНОГО (системного) дня [date]. */
data class DayPrayers(
    val date: LocalDate,
    val fajr: Int, val sunrise: Int, val dhuhr: Int, val asr: Int, val maghrib: Int, val isha: Int,
    val tahajjudStart: Int,   // может быть > 1440 (ночь переходит на следующие сутки)
    val tahajjudEnd: Int      // фаджр следующего дня (от полуночи date)
) {
    /** пять обязательных намазов в порядке P0..P4 */
    val five: List<Int> get() = listOf(fajr, dhuhr, asr, maghrib, isha)
}

object PrayerService {
    private val cache = HashMap<String, DayPrayers>()

    fun forDate(s: Settings, date: LocalDate): DayPrayers {
        val key = "${s.lat}|${s.lng}|${s.tzId}|${s.method}|${s.asrFactor}|$date"
        synchronized(cache) {
            cache[key]?.let { return it }
            if (cache.size > 800) cache.clear()
        }
        val r = calc(s, date)
        synchronized(cache) { cache[key] = r }
        return r
    }

    private fun calc(s: Settings, date: LocalDate): DayPrayers {
        val city = try { ZoneId.of(s.tzId) } catch (_: Exception) { ZoneId.systemDefault() }
        val local = ZoneId.systemDefault()
        val method = CalcMethod.of(s.method)

        fun raw(d: LocalDate): PrayerCalculator.Raw {
            val off = city.rules.getOffset(LocalDateTime.of(d, LocalTime.NOON)).totalSeconds / 3600.0
            return PrayerCalculator.compute(d, s.lat, s.lng, off, method, s.asrFactor)
        }

        // часы города -> минуты от полуночи локального дня date
        fun toLocalMin(d: LocalDate, hours: Double): Int {
            val minCity = Math.round(hours * 60.0).toInt()
            val inst = LocalDateTime.of(d, LocalTime.MIDNIGHT).plusMinutes(minCity.toLong()).atZone(city).toInstant()
            val ldt = inst.atZone(local).toLocalDateTime()
            val base = LocalDateTime.of(date, LocalTime.MIDNIGHT)
            return java.time.Duration.between(base, ldt).toMinutes().toInt()
        }

        val t = raw(date)
        val n = raw(date.plusDays(1))
        val maghribMin = toLocalMin(date, t.maghrib)
        val fajrNext = toLocalMin(date.plusDays(1), n.fajr)
        val night = fajrNext - maghribMin
        val third = maghribMin + (night * 2) / 3
        return DayPrayers(
            date,
            toLocalMin(date, t.fajr), toLocalMin(date, t.sunrise), toLocalMin(date, t.dhuhr),
            toLocalMin(date, t.asr), maghribMin, toLocalMin(date, t.isha),
            third, fajrNext
        )
    }

    /** Следующий намаз после момента (день, минута): имя и время (минуты от полуночи [day]); может быть завтрашний фаджр (>1440). */
    fun next(s: Settings, day: Long, nowMin: Int): Pair<Int, Int> {
        val today = forDate(s, LocalDate.ofEpochDay(day))
        today.five.forEachIndexed { i, m -> if (m > nowMin) return i to m }
        val tomorrow = forDate(s, LocalDate.ofEpochDay(day + 1))
        return 0 to (tomorrow.fajr + 1440)
    }
}
