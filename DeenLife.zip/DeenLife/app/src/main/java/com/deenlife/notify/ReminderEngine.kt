package com.deenlife.notify

import com.deenlife.data.AppDao
import com.deenlife.data.Prefs
import com.deenlife.domain.*
import com.deenlife.util.*
import java.time.Instant
import java.time.ZoneId
import java.time.LocalDate

data class Reminder(val time: Long, val channel: String, val title: String, val text: String, val id: Int)

/** Строит список напоминаний из расписания на заданное окно времени. Состояние не хранит — всё вычисляется по данным. */
class ReminderEngine(private val dao: AppDao, private val prefs: Prefs) {

    suspend fun build(fromMs: Long, toMs: Long): List<Reminder> {
        val s = prefs.value
        val sn = loadSnapshot(dao, s)
        val zone = ZoneId.systemDefault()
        val firstDay = Instant.ofEpochMilli(fromMs).atZone(zone).toLocalDate().toEpochDay() - 1
        val lastDay = Instant.ofEpochMilli(toMs).atZone(zone).toLocalDate().toEpochDay() + 2
        val out = ArrayList<Reminder>()
        val today = todayEpoch()

        fun add(t: Long, ch: String, title: String, text: String, key: String) {
            if (t < fromMs || t > toMs || !s.notifOn(ch)) return
            out += Reminder(t, ch, title, text, (key + t).hashCode() and 0x7fffffff)
        }

        for (day in firstDay..lastDay) {
            val items = Timeline.build(day, sn)
            for (it in items) {
                if (it.carry || it.done || it.moved) continue
                val base = millisOf(day, it.s)
                when (it.kind) {
                    Kind.PRAYER -> if (it.id.startsWith("T:")) {
                        add(base, "tahajjud", "Время Тахаджуда", "Началась последняя треть ночи (${fmtTime(it.s)}). Лучшее время для ночной молитвы и дуа.", it.id)
                    } else {
                        if (s.prayerLead > 0) add(base - s.prayerLead * 60_000L, "prayer", "Скоро ${it.title}", "Через ${s.prayerLead} мин — ${it.title} в ${fmtTime(it.s)} (${s.cityName})", it.id + "L")
                        add(base, "prayer", "Время намаза: ${it.title}", "${fmtTime(it.s)} · ${s.cityName}", it.id)
                        if (it.id.endsWith(":1") && isoDay(day) == 5 && s.jumuah) {
                            add(base - 60 * 60_000L, "prayer", "Сегодня пятница — Джума", "Подготовьтесь к пятничному намазу: гусль, чистая одежда, сура «Аль-Кахф». Зухр в ${fmtTime(it.s)}.", "J" + it.id)
                        }
                    }
                    Kind.HOMEWORK -> {
                        add(base - 24 * 60 * 60_000L, "homework", "Завтра дедлайн", "«${it.title.removePrefix("Сдать: ")}» — срок завтра в ${fmtTime(it.s)}", it.id + "D")
                        add(base - 60 * 60_000L, "homework", "Дедлайн через час", "«${it.title.removePrefix("Сдать: ")}» — срок в ${fmtTime(it.s)}", it.id + "H")
                    }
                    Kind.SLEEP -> if (it.id.startsWith("S:bed")) {
                        val wakeNext = sn.settings.wake[isoDay(day + 1) - 1]
                        add(base - s.bedPrep * 60_000L, "sleep", "Пора готовиться ко сну", "Отбой в ${fmtTime(it.s)}. Подъём завтра в ${fmtTime(wakeNext)}.", it.id)
                    } else {
                        add(base, "wake", "Время вставать", "Доброе утро! Подъём в ${fmtTime(it.s)}.", it.id)
                    }
                    else -> if (it.rem >= 0) {
                        val lead = it.rem
                        val head = when (it.kind) {
                            Kind.COURSE -> "Пара"
                            Kind.WORKOUT -> "Тренировка"
                            else -> if (it.category == "WORKOUT") "Тренировка" else if (it.category == "COURSE") "Пара" else "Событие"
                        }
                        val title = if (lead == 0) "$head начинается: ${it.title}" else "$head через ${fmtDur(lead)}: ${it.title}"
                        val text = listOf("Начало в ${fmtTime(it.s)}", it.sub.takeIf { x -> x.isNotBlank() && it.kind != Kind.EVENT }).filterNotNull().joinToString(" · ")
                        add(base - lead * 60_000L, it.channel, title, text, it.id)
                    }
                }
            }
            // привычки
            for (h in sn.habits) {
                if (h.archived || h.reminderMin < 0) continue
                if (sn.habitKeys.contains("${h.id}:$day") && day <= today) continue
                add(millisOf(day, h.reminderMin), "habits", "Привычка: ${h.title}", "Самое время выполнить сегодня.", "HB${h.id}:$day")
            }
        }
        return out.sortedBy { it.time }
    }
}
