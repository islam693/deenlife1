package com.deenlife.ui.islam

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.deenlife.domain.*
import com.deenlife.ui.*
import com.deenlife.ui.common.*
import com.deenlife.util.*
import java.time.LocalDate

@Composable
fun IslamScreen(vm: AppViewModel, sn: Snapshot, nav: Nav) {
    val clock by vm.clock.collectAsState()
    val s = sn.settings
    val today = clock.toLocalDate().toEpochDay()
    val nowMin = clock.hour * 60 + clock.minute
    val dp = remember(s, today) { PrayerService.forDate(s, LocalDate.ofEpochDay(today)) }
    val (nextIdx, nextMin) = remember(s, today, nowMin) { PrayerService.next(s, today, nowMin) }
    val hijri = Hijri.of(LocalDate.ofEpochDay(today), s.hijriAdjust)
    val doneCount = (0..4).count { sn.ibadahKeys.contains("$today:P$it") }
    val isFriday = isoDay(today) == 5
    val tahajjudDone = sn.ibadahKeys.contains("$today:TAHAJJUD")
    val tahStart = dp.tahajjudStart
    val tahEnd = dp.tahajjudEnd
    val quranToday = sn.quran.firstOrNull { it.day == today }?.pages ?: 0

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Ислам", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(hijri.toString(), color = MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.bodyMedium)
                    Hijri.note(hijri)?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
                }
                IconButton(onClick = { nav.push(Route.PrayerSettings) }) { Icon(Icons.Rounded.Tune, "Настройки намаза") }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth(), container = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)) {
                Text("Следующий намаз", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(PRAYER_NAMES[nextIdx], style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                    Text(fmtTime(nextMin), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                }
                Text("через ${fmtDur(nextMin - nowMin)} · ${s.cityName} · ${CalcMethod.of(s.method).title.substringBefore(" (")}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Намазы сегодня", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("$doneCount / 5", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
                Text("Восход: ${fmtTime(dp.sunrise)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                dp.five.forEachIndexed { i, m ->
                    val done = sn.ibadahKeys.contains("$today:P$i")
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (i == 1 && isFriday) "Зухр / Джума" else PRAYER_NAMES[i], Modifier.weight(1f), fontWeight = if (i == nextIdx && m + 0 >= nowMin) FontWeight.Bold else FontWeight.Normal)
                        Text(fmtTime(m), style = MaterialTheme.typography.titleSmall)
                        CheckCircle(done, { vm.toggleIbadah(today, "P$i") })
                    }
                }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.Bedtime, MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Тахаджуд", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text("Последняя треть ночи: ${fmtTime(tahStart)} – ${fmtTime(tahEnd)}", style = MaterialTheme.typography.bodyMedium)
                        Text("Рекомендуемо проснуться в ${fmtTime(tahStart)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                val fromPrev = PrayerService.forDate(s, LocalDate.ofEpochDay(today - 1))
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Отметка за эту ночь (до фаджра ${fmtTime(dp.fajr)}) — ${fmtTime(fromPrev.tahajjudStart - 1440)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    CheckCircle(tahajjudDone, { vm.toggleIbadah(today, "TAHAJJUD") })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Напоминать о Тахаджуде", Modifier.weight(1f))
                    Switch(s.nTahajjud, { v -> vm.updateSettings { it.copy(nTahajjud = v) } })
                }
            }
        }
        if (isFriday) item {
            AppCard(Modifier.fillMaxWidth(), container = MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f)) {
                Text("Сегодня пятница — Джума", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text("Гусль, чистая одежда, сура «Аль-Кахф», как можно больше салаватов. Джума вместо Зухра — в ${fmtTime(dp.dhuhr)}.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth(), onClick = { nav.push(Route.Quran) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.MenuBook, MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Чтение Корана", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text("Сегодня $quranToday из ${s.quranGoal} стр.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    ProgressRing(if (s.quranGoal == 0) 0f else quranToday.toFloat() / s.quranGoal, 44, 6, label = "")
                }
            }
        }
        item {
            val rows = listOf(
                Triple("Зикр", Icons.Rounded.TouchApp, Route.Zikr),
                Triple("Пост", Icons.Rounded.WbTwilight, Route.Fasting),
                Triple("Календарь Хиджры", Icons.Rounded.CalendarMonth, Route.HijriCal),
                Triple("Религиозные цели", Icons.Rounded.Flag, Route.Goals),
                Triple("Настройки намаза", Icons.Rounded.Tune, Route.PrayerSettings)
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                rows.forEach { (t, i, r) ->
                    AppCard(Modifier.fillMaxWidth(), onClick = { nav.push(r) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconBadge(i, MaterialTheme.colorScheme.primary, 36)
                            Spacer(Modifier.width(12.dp))
                            Text(t, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                            Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item {
            val week = (0..6).map { today - 6 + it }
            AppCard(Modifier.fillMaxWidth()) {
                Text("Выполнено намазов за 7 дней", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(8.dp))
                BarChart(
                    week.map { d -> (0..4).count { sn.ibadahKeys.contains("$d:P$it") }.toFloat() },
                    week.map { RU_DAYS_SHORT[isoDay(it) - 1] }, maxValue = 5f
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Настройки намаза

@Composable
fun PrayerSettingsScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val s = sn.settings
    var cityQuery by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val perm = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { if (!vm.useDeviceLocation()) vm.say("Местоположение пока недоступно — выберите город вручную") } else vm.say("Нет разрешения на геолокацию — выберите город вручную")
    }
    ScreenScaffold("Настройки намаза", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Местоположение", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("${s.cityName} (${"%.2f".format(s.lat)}, ${"%.2f".format(s.lng)}), часовой пояс ${s.tzId}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        val granted = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        if (granted) { if (!vm.useDeviceLocation()) vm.say("Местоположение пока недоступно — выберите город вручную") else vm.say("Местоположение определено") }
                        else perm.launch(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                    }) { Icon(Icons.Rounded.MyLocation, null); Spacer(Modifier.width(6.dp)); Text("Определить автоматически") }
                    TextButton(onClick = { manual = !manual }) { Text(if (manual) "Скрыть список городов" else "Выбрать город вручную") }
                }
            }
            if (manual) {
                item { OutlinedTextField(cityQuery, { cityQuery = it }, label = { Text("Поиск города") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                items(CITIES.filter { it.name.contains(cityQuery.trim(), true) }, key = { it.name }) { c ->
                    AppCard(Modifier.fillMaxWidth(), onClick = { vm.pickCity(c); manual = false; cityQuery = "" }) {
                        Row { Text(c.name, Modifier.weight(1f)); if (c.name == s.cityName) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary) }
                    }
                }
                item {
                    var lat by remember { mutableStateOf("") }
                    var lng by remember { mutableStateOf("") }
                    AppCard(Modifier.fillMaxWidth()) {
                        Text("Своя точка (широта/долгота)", style = MaterialTheme.typography.titleSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(lat, { lat = it }, label = { Text("Широта") }, singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(lng, { lng = it }, label = { Text("Долгота") }, singleLine = true, modifier = Modifier.weight(1f))
                        }
                        TextButton(onClick = {
                            val a = lat.replace(',', '.').toDoubleOrNull(); val b = lng.replace(',', '.').toDoubleOrNull()
                            if (a == null || b == null || a !in -66.0..66.0 || b !in -180.0..180.0) vm.say("Неверные координаты (широта до ±66°)")
                            else { vm.pickCity(City("Своя точка", a, b, java.time.ZoneId.systemDefault().id)); manual = false }
                        }) { Text("Применить") }
                    }
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Метод расчёта", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    CalcMethod.entries.forEach { m ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(s.method == m.name, { vm.updateSettings { it.copy(method = m.name) } })
                            Text(m.title, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Мазхаб для Аср", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(s.asrFactor == 1, { vm.updateSettings { it.copy(asrFactor = 1) } })
                        Text("Шафиитский, маликитский, ханбалитский (тень = предмет)")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(s.asrFactor == 2, { vm.updateSettings { it.copy(asrFactor = 2) } })
                        Text("Ханафитский (тень = 2 предмета)")
                    }
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Уведомления", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Уведомления о намазе", Modifier.weight(1f)); Switch(s.nPrayer, { v -> vm.updateSettings { it.copy(nPrayer = v) } })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Напоминание о Джуме", Modifier.weight(1f)); Switch(s.jumuah, { v -> vm.updateSettings { it.copy(jumuah = v) } })
                    }
                    Text("Предупреждать за:", style = MaterialTheme.typography.bodyMedium)
                    ChoiceChips(listOf(0 to "Нет", 5 to "5 мин", 10 to "10 мин", 15 to "15 мин", 30 to "30 мин"), s.prayerLead) { v -> vm.updateSettings { it.copy(prayerLead = v) } }
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Поправка хиджры", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("Начало месяца зависит от видимости луны в вашей стране", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ChoiceChips(listOf(-2 to "−2", -1 to "−1", 0 to "0", 1 to "+1", 2 to "+2"), s.hijriAdjust) { v -> vm.updateSettings { it.copy(hijriAdjust = v) } }
                }
            }
            item { Text("Расчёт ведётся офлайн по астрономической формуле; сверяйте время с местным муфтиятом.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
