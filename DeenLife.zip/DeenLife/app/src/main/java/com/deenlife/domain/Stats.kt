package com.deenlife.domain

import com.deenlife.data.HabitEntity
import com.deenlife.util.weekStart

data class DayStat(
    val day: Long,
    val tasksTotal: Int,
    val tasksDone: Int,
    val studyMin: Int,
    val workoutMin: Int,
    val sleepMin: Int?,
    val habitPct: Float?
) {
    val productivity: Float get() = if (tasksTotal == 0) 0f else tasksDone.toFloat() / tasksTotal
}

object Stats {
    fun days(sn: Snapshot, from: Long, to: Long): List<DayStat> {
        val dailyHabits = sn.habits.filter { !it.archived && !it.weekly }
        return (from..to).map { d ->
            val items = Timeline.build(d, sn, prayers = false, sleep = false)
            val tasks = Timeline.tasks(items)
            val study = sn.studyLogs.filter { it.day == d }.sumOf { it.minutes } +
                items.filter { it.done && it.kind == Kind.EVENT && (it.category == "SELF_STUDY" || it.category == "HOMEWORK") }.sumOf { it.minutes } +
                items.filter { it.done && it.kind == Kind.COURSE }.sumOf { it.minutes }
            val workout = items.filter { it.done && (it.kind == Kind.WORKOUT || it.category == "WORKOUT") }.sumOf { it.minutes }
            val sleep = sn.sleepLogs.firstOrNull { it.day == d - 1 }?.minutes
            val hp = if (dailyHabits.isEmpty()) null
            else dailyHabits.count { sn.habitKeys.contains("${it.id}:$d") }.toFloat() / dailyHabits.size
            DayStat(d, tasks.size, tasks.count { it.done }, study, workout, sleep, hp)
        }
    }

    fun habitDays(sn: Snapshot, h: HabitEntity): Set<Long> =
        sn.habitLogs.filter { it.habitId == h.id }.map { it.day }.toHashSet()

    fun weekCount(days: Set<Long>, today: Long): Int {
        val ws = weekStart(today)
        return days.count { it in ws..ws + 6 }
    }

    fun streak(h: HabitEntity, days: Set<Long>, today: Long): Int {
        if (!h.weekly) {
            var d = if (days.contains(today)) today else today - 1
            var n = 0
            while (days.contains(d)) { n++; d-- }
            return n
        }
        var ws = weekStart(today)
        fun met(w: Long) = days.count { it in w..w + 6 } >= h.target
        if (!met(ws)) ws -= 7
        var n = 0
        while (met(ws)) { n++; ws -= 7 }
        return n
    }

    /** Доля выполнения привычки за последние [n] дней, 0..1. */
    fun rate(h: HabitEntity, days: Set<Long>, today: Long, n: Int): Float {
        if (!h.weekly) return (0 until n).count { days.contains(today - it) }.toFloat() / n
        val weeks = maxOf(1, n / 7)
        var sum = 0f
        for (i in 0 until weeks) {
            val ws = weekStart(today) - 7L * i
            sum += minOf(1f, days.count { it in ws..ws + 6 }.toFloat() / h.target)
        }
        return sum / weeks
    }
}
