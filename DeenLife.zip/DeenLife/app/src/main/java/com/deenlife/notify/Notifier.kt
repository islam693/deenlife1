package com.deenlife.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.deenlife.MainActivity
import com.deenlife.R

object Notifier {
    val CHANNELS = listOf(
        Triple("classes", "Пары", "Напоминания о начале занятий"),
        Triple("homework", "Домашние задания", "Дедлайны и домашние задания"),
        Triple("workout", "Тренировки", "Напоминания о тренировках"),
        Triple("prayer", "Время намаза", "Уведомления о намазе и пятнице"),
        Triple("tahajjud", "Тахаджуд", "Последняя треть ночи"),
        Triple("sleep", "Подготовка ко сну", "Пора ложиться спать"),
        Triple("wake", "Подъём", "Напоминание о пробуждении"),
        Triple("habits", "Привычки", "Напоминания о привычках"),
        Triple("events", "События", "Приближающиеся события")
    )

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        for ((id, name, desc) in CHANNELS) {
            val ch = NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH)
            ch.description = desc
            nm.createNotificationChannel(ch)
        }
    }

    fun show(ctx: Context, r: Reminder) {
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, r.channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(r.title)
            .setContentText(r.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(r.text))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(r.id, n)
        } catch (_: SecurityException) {
            // нет разрешения на уведомления — пользователь увидит подсказку в настройках
        }
    }
}
