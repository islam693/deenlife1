package com.deenlife.ui.profile

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.deenlife.DeenLifeApp
import com.deenlife.data.CategoryEntity
import com.deenlife.domain.*
import com.deenlife.notify.ReminderScheduler
import com.deenlife.ui.*
import com.deenlife.ui.common.*
import com.deenlife.util.*
import java.time.LocalDate

@Composable
fun ProfileScreen(vm: AppViewModel, sn: Snapshot, nav: Nav) {
    val s = sn.settings
    val ctx = LocalContext.current
    var name by remember(s.userName) { mutableStateOf(s.userName) }
    var restore by remember { mutableStateOf<Uri?>(null) }

    val exportBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { u -> u?.let { vm.exportBackup(it) } }
    val importBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> restore = u }
    val exportIcs = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/calendar")) { u -> u?.let { vm.exportIcs(it) } }

    val exact = remember { mutableStateOf(ReminderScheduler.canScheduleExact(ctx)) }
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val o = androidx.lifecycle.LifecycleEventObserver { _, e -> if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) { exact.value = ReminderScheduler.canScheduleExact(ctx); (ctx.applicationContext as DeenLifeApp).reschedule() } }
        lifecycle.addObserver(o); onDispose { lifecycle.removeObserver(o) }
    }
    val notifOk = androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Профиль и настройки", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                OutlinedTextField(name, { name = it; vm.updateSettings { st -> st.copy(userName = it.trim()) } }, label = { Text("Ваше имя") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("Тема", style = MaterialTheme.typography.labelMedium)
                ChoiceChips(listOf(0 to "Системная", 1 to "Светлая", 2 to "Тёмная"), s.theme) { v -> vm.updateSettings { it.copy(theme = v) } }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("Выходные дни", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                WeekdayChips(s.weekend) { v -> vm.updateSettings { it.copy(weekend = v) } }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("Уведомления", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                if (!notifOk) {
                    Text("⚠ Уведомления отключены в системе.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)) }) { Text("Открыть настройки уведомлений") }
                }
                if (!exact.value) {
                    Text("⚠ Для точных напоминаний (намаз!) разрешите «Будильники и напоминания».", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = {
                        try { ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))) } catch (_: Throwable) {}
                    }) { Text("Разрешить") }
                }
                NotifRow("Пары", s.nClasses) { v -> vm.updateSettings { it.copy(nClasses = v) } }
                NotifRow("Домашние задания и дедлайны", s.nHomework) { v -> vm.updateSettings { it.copy(nHomework = v) } }
                NotifRow("Тренировки", s.nWorkout) { v -> vm.updateSettings { it.copy(nWorkout = v) } }
                NotifRow("Время намаза", s.nPrayer) { v -> vm.updateSettings { it.copy(nPrayer = v) } }
                NotifRow("Тахаджуд", s.nTahajjud) { v -> vm.updateSettings { it.copy(nTahajjud = v) } }
                NotifRow("Подготовка ко сну", s.nSleep) { v -> vm.updateSettings { it.copy(nSleep = v) } }
                NotifRow("Подъём", s.nWake) { v -> vm.updateSettings { it.copy(nWake = v) } }
                NotifRow("Привычки", s.nHabits) { v -> vm.updateSettings { it.copy(nHabits = v) } }
                NotifRow("Другие события", s.nEvents) { v -> vm.updateSettings { it.copy(nEvents = v) } }
            }
        }
        item {
            val rows = listOf(
                Triple("Категории и цвета", Icons.Rounded.Palette, Route.Categories),
                Triple("Привычки и цели", Icons.Rounded.Checklist, Route.Habits),
                Triple("Спорт", Icons.Rounded.FitnessCenter, Route.Sport),
                Triple("Сон и режим дня", Icons.Rounded.Bedtime, Route.Sleep),
                Triple("Статистика", Icons.Rounded.BarChart, Route.Stats),
                Triple("Помощник планирования", Icons.Rounded.AutoAwesome, Route.Planner),
                Triple("Поиск", Icons.Rounded.Search, Route.Search)
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                rows.forEach { (t, i, r) ->
                    AppCard(Modifier.fillMaxWidth(), onClick = { nav.push(r) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconBadge(i, MaterialTheme.colorScheme.primary, 36); Spacer(Modifier.width(12.dp))
                            Text(t, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                            Icon(Icons.Rounded.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Text("Данные", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text("Резервная копия и перенос между устройствами: сохраните файл (например, в облако) и откройте его на другом телефоне.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { exportBackup.launch("deenlife-backup-${LocalDate.now()}.zip") }) { Text("Сохранить копию") }
                    OutlinedButton(onClick = { importBackup.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) { Text("Восстановить") }
                }
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = { exportIcs.launch("deenlife-${LocalDate.now()}.ics") }) { Text("Экспорт расписания (.ics)") }
            }
        }
        item { Text("DeenLife 1.0 · все данные хранятся на устройстве", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }

    restore?.let { u ->
        AlertDialog(
            onDismissRequest = { restore = null }, title = { Text("Восстановить из копии?") },
            text = { Text("Все текущие данные будут заменены данными из файла. Приложение закроется — откройте его снова.") },
            confirmButton = {
                TextButton(onClick = {
                    restore = null
                    vm.restoreBackup(u) {
                        (ctx.applicationContext as DeenLifeApp).prefs.reload()
                        android.os.Process.killProcess(android.os.Process.myPid())
                    }
                }) { Text("Заменить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { restore = null }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun NotifRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(on, onChange)
    }
}

@Composable
fun CategoriesScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    var edit by remember { mutableStateOf<CategoryEntity?>(null) }
    ScreenScaffold("Категории", onBack, floating = {
        FloatingActionButton(onClick = { edit = CategoryEntity("U" + System.currentTimeMillis(), "", PALETTE[4], false, sn.categories.size) }) { Icon(Icons.Rounded.Add, "Добавить") }
    }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(sn.categories, key = { it.id }) { c ->
                AppCard(Modifier.fillMaxWidth(), onClick = { edit = c }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ColorDot(c.color, 16); Spacer(Modifier.width(12.dp))
                        Text(c.name, Modifier.weight(1f))
                        if (c.builtIn) Text("встроенная", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
    edit?.let { c ->
        var v by remember(c) { mutableStateOf(c) }
        val isNew = sn.categories.none { it.id == c.id }
        AlertDialog(
            onDismissRequest = { edit = null }, title = { Text(if (isNew) "Новая категория" else "Категория") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(v.name, { v = v.copy(name = it) }, label = { Text("Название") }, singleLine = true)
                    ColorPickerRow(v.color) { v = v.copy(color = it) }
                    Text("Цвет применится к новым событиям этой категории.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { if (v.name.isBlank()) vm.say("Введите название") else { vm.saveCategory(v.copy(name = v.name.trim())); edit = null } }) { Text("Сохранить") } },
            dismissButton = {
                Row {
                    if (!isNew && !c.builtIn) TextButton(onClick = { vm.deleteCategory(c.id); edit = null }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                    TextButton(onClick = { edit = null }) { Text("Отмена") }
                }
            }
        )
    }
}
