package com.deenlife.ui.sport

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.deenlife.data.WorkoutEntity
import com.deenlife.domain.*
import com.deenlife.ui.AppViewModel
import com.deenlife.ui.common.*
import com.deenlife.util.*

@Composable
fun SportScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val s = sn.settings
    val today = todayEpoch()
    val ws = weekStart(today)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf<WorkoutEntity?>(null) }

    ScreenScaffold("Спорт", onBack, floating = {
        FloatingActionButton(onClick = {
            edit = WorkoutEntity(title = "", muscle = MUSCLE_GROUPS[0], day = today, startMin = 18 * 60, durationMin = 60)
        }) { Icon(Icons.Rounded.Add, "Добавить тренировку") }
    }) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                listOf("План", "История", "Регулярность").forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            when (tab) {
                0 -> {
                    val upcoming = sn.workouts.filter { !it.done || it.day >= today }.filter { it.day >= today - 1 || !it.done }.sortedWith(compareBy({ it.day }, { it.startMin }))
                    val weekDone = sn.workouts.count { it.done && it.day in ws..ws + 6 }
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            AppCard(Modifier.fillMaxWidth()) {
                                Text("Неделя: $weekDone из ${s.workoutPerWeek}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                LinearProgressIndicator(progress = { if (s.workoutPerWeek == 0) 0f else (weekDone.toFloat() / s.workoutPerWeek).coerceIn(0f, 1f) }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                                Text("Цель тренировок в неделю", style = MaterialTheme.typography.labelMedium)
                                ChoiceChips((1..7).map { it to "$it" }, s.workoutPerWeek) { v -> vm.updateSettings { it.copy(workoutPerWeek = v) } }
                                Spacer(Modifier.height(8.dp))
                                Text("Дни отдыха", style = MaterialTheme.typography.labelMedium)
                                WeekdayChips(s.restDays) { v -> vm.updateSettings { it.copy(restDays = v) } }
                            }
                        }
                        if (upcoming.isEmpty()) item { EmptyHint("Нет запланированных тренировок. Нажмите «+», чтобы добавить.") }
                        items(upcoming, key = { it.id }) { w -> WorkoutCard(vm, w, s.restDays) { edit = w } }
                    }
                }
                1 -> {
                    val hist = sn.workouts.filter { it.done }.sortedByDescending { it.day * 1440 + it.startMin }
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { Text("Всего выполнено: ${hist.size} · ${fmtDur(hist.sumOf { it.durationMin })}", style = MaterialTheme.typography.titleSmall) }
                        if (hist.isEmpty()) item { EmptyHint("История пока пуста — отметьте выполненные тренировки.") }
                        items(hist, key = { it.id }) { w -> WorkoutCard(vm, w, s.restDays) { edit = w } }
                    }
                }
                else -> {
                    val weeks = (0..7).map { ws - 7L * (7 - it) }
                    val counts = weeks.map { w -> sn.workouts.count { it.done && it.day in w..w + 6 }.toFloat() }
                    val last30 = sn.workouts.filter { it.done && it.day > today - 30 }
                    val byGroup = sn.workouts.filter { it.done }.groupBy { it.muscle }.mapValues { it.value.size }.toList().sortedByDescending { it.second }
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                StatTile("За 30 дней", "${last30.size}", Modifier.weight(1f))
                                StatTile("Время", fmtDur(last30.sumOf { it.durationMin }), Modifier.weight(1f))
                            }
                        }
                        item {
                            AppCard(Modifier.fillMaxWidth()) {
                                Text("Тренировок по неделям", style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.height(8.dp))
                                BarChart(counts, weeks.map { shortDate(it).substringBefore(' ') }, target = s.workoutPerWeek.toFloat())
                                Text("Линия — недельная цель", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        if (byGroup.isNotEmpty()) {
                            item { SectionTitle("По группам мышц") }
                            items(byGroup, key = { it.first }) { (g, n) ->
                                AppCard(Modifier.fillMaxWidth()) {
                                    Row { Text(g, Modifier.weight(1f)); Text("$n", fontWeight = FontWeight.SemiBold) }
                                    LinearProgressIndicator(progress = { n.toFloat() / byGroup.first().second }, Modifier.fillMaxWidth().padding(top = 6.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    edit?.let { WorkoutDialog(it, sn, onDismiss = { edit = null }, onSave = { w, rep -> vm.saveWorkout(w, rep); edit = null }, onDelete = { vm.deleteWorkout(it); edit = null }) }
}

@Composable
private fun WorkoutCard(vm: AppViewModel, w: WorkoutEntity, rest: Set<Int>, onEdit: () -> Unit) {
    AppCard(Modifier.fillMaxWidth(), onClick = onEdit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CheckCircle(w.done, { vm.toggleWorkout(w) })
            Column(Modifier.weight(1f)) {
                Text(w.title.ifBlank { w.muscle }, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text("${shortDate(w.day)} · ${fmtTime(w.startMin)} · ${fmtDur(w.durationMin)} · ${w.muscle}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (w.exercises.isNotBlank()) Text(w.exercises.lines().take(2).joinToString(", "), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                if (isoDay(w.day) in rest && !w.done) Text("⚠ день отдыха", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun WorkoutDialog(
    initial: WorkoutEntity, sn: Snapshot, onDismiss: () -> Unit, onSave: (WorkoutEntity, Int) -> Unit, onDelete: (Long) -> Unit
) {
    var w by remember { mutableStateOf(initial) }
    var repeatWeeks by remember { mutableIntStateOf(0) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.id == 0L) "Новая тренировка" else "Тренировка") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(w.title, { w = w.copy(title = it) }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Группа мышц", style = MaterialTheme.typography.labelMedium)
                ChipsRow { MUSCLE_GROUPS.forEach { g -> FilterChip(selected = w.muscle == g, onClick = { w = w.copy(muscle = g) }, label = { Text(g) }) } }
                OutlinedTextField(w.exercises, { w = w.copy(exercises = it) }, label = { Text("Упражнения (по одному в строке)") }, modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp))
                DateField("Дата", w.day, { w = w.copy(day = it) }, Modifier.fillMaxWidth())
                TimeField("Начало", w.startMin, { w = w.copy(startMin = it) }, Modifier.fillMaxWidth())
                NumberField("Длительность", w.durationMin, { w = w.copy(durationMin = it) }, Modifier.fillMaxWidth(), "мин")
                Text("Напоминание", style = MaterialTheme.typography.labelMedium)
                ChoiceChips(listOf(-1 to "Нет", 0 to "В начале", 15 to "15 мин", 30 to "30 мин", 60 to "1 час"), w.reminderMin) { w = w.copy(reminderMin = it) }
                if (initial.id == 0L) {
                    Text("Повторять еженедельно", style = MaterialTheme.typography.labelMedium)
                    ChoiceChips(listOf(0 to "Нет", 3 to "3 нед.", 7 to "7 нед.", 11 to "12 нед."), repeatWeeks) { repeatWeeks = it }
                }
                val c = remember(w) {
                    Timeline.build(w.day, sn, prayers = false, sleep = false).firstOrNull { x ->
                        (x.kind == Kind.EVENT || x.kind == Kind.COURSE || (x.kind == Kind.WORKOUT && x.refId != w.id)) &&
                            x.e > x.s && !x.moved && x.category != "WAKE" && w.startMin < x.e && x.s < w.startMin + w.durationMin
                    }
                }
                if (c != null) Text("⚠ Пересекается с «${c.title}» (${fmtTime(c.s)}–${fmtTime(c.e)})", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    w.title.isBlank() && w.muscle.isBlank() -> err = "Введите название"
                    w.durationMin <= 0 -> err = "Укажите длительность"
                    w.startMin + w.durationMin > 1440 -> err = "Тренировка должна закончиться до полуночи"
                    else -> onSave(w.copy(title = w.title.trim().ifBlank { w.muscle }), repeatWeeks)
                }
            }) { Text("Сохранить") }
        },
        dismissButton = {
            Row {
                if (initial.id != 0L) TextButton(onClick = { onDelete(initial.id) }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                TextButton(onClick = onDismiss) { Text("Отмена") }
            }
        }
    )
}
