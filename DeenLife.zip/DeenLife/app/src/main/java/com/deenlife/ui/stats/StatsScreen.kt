package com.deenlife.ui.stats

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.deenlife.domain.*
import com.deenlife.ui.AppViewModel
import com.deenlife.ui.common.*
import com.deenlife.util.*

@Composable
fun StatsScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val today = todayEpoch()
    var month by rememberSaveable { mutableStateOf(false) }
    val n = if (month) 30 else 7
    val st = remember(sn, today, n) { Stats.days(sn, today - n + 1, today) }
    val labels = st.map { if (month) shortDate(it.day).substringBefore(' ') else RU_DAYS_SHORT[isoDay(it.day) - 1] }
    val t = st.last()
    val withTasks = st.filter { it.tasksTotal > 0 }
    val productivity = if (withTasks.isEmpty()) 0f else withTasks.sumOf { it.tasksDone }.toFloat() / withTasks.sumOf { it.tasksTotal }
    val sleeps = st.mapNotNull { it.sleepMin }
    val habitPct = st.mapNotNull { it.habitPct }
    // регулярность: доля дней, где выполнено >= 70% задач (из дней, где были задачи)
    val regular = if (withTasks.isEmpty()) 0f else withTasks.count { it.productivity >= 0.7f }.toFloat() / withTasks.size

    ScreenScaffold("Статистика", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { ChoiceChips(listOf(false to "Неделя", true to "Месяц"), month) { month = it } }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Сегодня", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        ProgressRing(t.productivity, 80, 9, label = "${(t.productivity * 100).toInt()}%")
                        Column {
                            Text("Выполнено задач: ${t.tasksDone} из ${t.tasksTotal}")
                            Text("Учёба: ${fmtDur(t.studyMin)}")
                            Text("Тренировка: ${fmtDur(t.workoutMin)}")
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatTile("Продуктивность", "${(productivity * 100).toInt()}%", Modifier.weight(1f))
                    StatTile("Регулярность", "${(regular * 100).toInt()}%", Modifier.weight(1f), MaterialTheme.colorScheme.secondary)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatTile("Средний сон", if (sleeps.isEmpty()) "—" else fmtDur(sleeps.average().toInt()), Modifier.weight(1f))
                    StatTile("Привычки", if (habitPct.isEmpty()) "—" else "${(habitPct.average() * 100).toInt()}%", Modifier.weight(1f), MaterialTheme.colorScheme.tertiary)
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Выполнено задач", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    BarChart(st.map { it.tasksDone.toFloat() }, labels)
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Продуктивность по дням (%)", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    BarChart(st.map { it.productivity * 100 }, labels, color = MaterialTheme.colorScheme.secondary, maxValue = 100f, target = 70f)
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Время учёбы (мин)", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    BarChart(st.map { it.studyMin.toFloat() }, labels, color = MaterialTheme.colorScheme.tertiary, target = sn.settings.studyGoalMin.toFloat())
                    Text("Всего: ${fmtDur(st.sumOf { it.studyMin })}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Тренировки (мин)", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    BarChart(st.map { it.workoutMin.toFloat() }, labels, color = MaterialTheme.colorScheme.error)
                    Text("Всего: ${fmtDur(st.sumOf { it.workoutMin })}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Сон (мин)", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    BarChart(st.map { (it.sleepMin ?: 0).toFloat() }, labels, color = MaterialTheme.colorScheme.primary, target = sn.settings.sleepGoalMin.toFloat())
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Привычки (%)", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    BarChart(st.map { (it.habitPct ?: 0f) * 100 }, labels, maxValue = 100f)
                }
            }
            item { Text("Продуктивность = выполненные задачи (события, тренировки, дедлайны) / все задачи периода. Регулярность — доля дней, где выполнено не менее 70% задач.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}
