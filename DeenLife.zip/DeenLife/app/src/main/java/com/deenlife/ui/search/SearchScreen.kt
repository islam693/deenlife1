package com.deenlife.ui.search

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import com.deenlife.domain.Snapshot
import com.deenlife.ui.AppViewModel
import com.deenlife.ui.Nav
import com.deenlife.ui.Route
import com.deenlife.ui.common.*
import com.deenlife.util.*

private data class Hit(val key: String, val title: String, val sub: String, val color: Int, val open: () -> Unit)

@Composable
fun SearchScreen(vm: AppViewModel, sn: Snapshot, nav: Nav, onBack: () -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Throwable) {} }

    val hits = remember(q, sn) {
        val t = q.trim()
        if (t.length < 1) emptyList() else buildList {
            sn.events.filter { it.title.contains(t, true) || it.notes.contains(t, true) }.forEach { e ->
                add(Hit("e${e.id}", e.title, "${sn.catName(e.category)} · ${shortDate(e.startDay)} ${fmtTime(e.startMin)}", e.color) { nav.pop(); nav.editEvent(e.id, e.startDay) })
            }
            sn.courses.filter { it.name.contains(t, true) || it.teacher.contains(t, true) || it.room.contains(t, true) }.forEach { c ->
                add(Hit("c${c.id}", c.name, "Занятие · ${RU_DAYS_SHORT[c.dayOfWeek - 1]} ${fmtTime(c.startMin)} ${c.teacher}", c.color) { nav.pop(); nav.studyPage = 0; nav.tab = 2 })
            }
            sn.homework.filter { it.title.contains(t, true) || it.course.contains(t, true) || it.notes.contains(t, true) }.forEach { h ->
                add(Hit("h${h.id}", h.title, "Задание · до ${shortDate(h.deadlineDay)}${if (h.done) " · выполнено" else ""}", sn.catColor("HOMEWORK")) { nav.pop(); nav.studyPage = 1; nav.tab = 2 })
            }
            sn.workouts.filter { it.title.contains(t, true) || it.muscle.contains(t, true) || it.exercises.contains(t, true) }.forEach { w ->
                add(Hit("w${w.id}", w.title, "Тренировка · ${shortDate(w.day)}", sn.catColor("WORKOUT")) { nav.pop(); nav.push(Route.Sport) })
            }
            sn.habits.filter { it.title.contains(t, true) }.forEach { h ->
                add(Hit("hb${h.id}", h.title, "Привычка", h.color) { nav.pop(); nav.push(Route.Habits) })
            }
            sn.goals.filter { it.title.contains(t, true) || it.notes.contains(t, true) }.forEach { g ->
                add(Hit("g${g.id}", g.title, "Религиозная цель", sn.catColor("RELIGION")) { nav.pop(); nav.push(Route.Goals) })
            }
        }
    }

    ScreenScaffold("Поиск", onBack) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            OutlinedTextField(
                q, { q = it }, Modifier.fillMaxWidth().focusRequester(focus), singleLine = true,
                leadingIcon = { androidx.compose.material3.Icon(Icons.Rounded.Search, null) },
                placeholder = { Text("События, занятия, задания, привычки…") }
            )
            Spacer(Modifier.height(8.dp))
            if (q.isBlank()) EmptyHint("Начните вводить запрос")
            else if (hits.isEmpty()) EmptyHint("Ничего не найдено")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(hits.sortedBy { it.title.lowercase() }, key = { it.key }) { h ->
                    AppCard(Modifier.fillMaxWidth(), onClick = h.open) {
                        androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            ColorDot(h.color, 12)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(h.title, style = MaterialTheme.typography.titleSmall)
                                Text(h.sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
