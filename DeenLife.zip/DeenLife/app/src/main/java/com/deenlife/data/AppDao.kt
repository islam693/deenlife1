package com.deenlife.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // ---- события
    @Query("SELECT * FROM events") fun events(): Flow<List<EventEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertEvent(e: EventEntity): Long
    @Query("DELETE FROM events WHERE id=:id") suspend fun deleteEvent(id: Long)
    @Query("DELETE FROM item_status WHERE id LIKE 'E:' || :id || ':%'") suspend fun deleteEventStatus(id: Long)

    @Query("SELECT * FROM item_status") fun statuses(): Flow<List<ItemStatus>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun setStatus(s: ItemStatus)
    @Query("DELETE FROM item_status WHERE id=:id") suspend fun clearStatus(id: String)

    // ---- учёба
    @Query("SELECT * FROM courses") fun courses(): Flow<List<CourseEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertCourse(c: CourseEntity): Long
    @Query("DELETE FROM courses WHERE id=:id") suspend fun deleteCourse(id: Long)
    @Query("DELETE FROM item_status WHERE id LIKE 'C:' || :id || ':%'") suspend fun deleteCourseStatus(id: Long)

    @Query("SELECT * FROM homework") fun homework(): Flow<List<HomeworkEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertHomework(h: HomeworkEntity): Long
    @Query("DELETE FROM homework WHERE id=:id") suspend fun deleteHomework(id: Long)

    @Query("SELECT * FROM study_log") fun studyLogs(): Flow<List<StudyLogEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertStudy(s: StudyLogEntity): Long
    @Query("DELETE FROM study_log WHERE id=:id") suspend fun deleteStudy(id: Long)

    // ---- спорт
    @Query("SELECT * FROM workouts") fun workouts(): Flow<List<WorkoutEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertWorkout(w: WorkoutEntity): Long
    @Query("DELETE FROM workouts WHERE id=:id") suspend fun deleteWorkout(id: Long)

    // ---- сон
    @Query("SELECT * FROM sleep_log") fun sleepLogs(): Flow<List<SleepLogEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertSleep(s: SleepLogEntity)
    @Query("DELETE FROM sleep_log WHERE day=:day") suspend fun deleteSleep(day: Long)

    // ---- привычки
    @Query("SELECT * FROM habits") fun habits(): Flow<List<HabitEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertHabit(h: HabitEntity): Long
    @Query("DELETE FROM habits WHERE id=:id") suspend fun deleteHabit(id: Long)
    @Query("SELECT * FROM habit_log") fun habitLogs(): Flow<List<HabitLog>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertHabitLog(l: HabitLog)
    @Query("DELETE FROM habit_log WHERE habitId=:id AND day=:day") suspend fun deleteHabitLog(id: Long, day: Long)
    @Query("DELETE FROM habit_log WHERE habitId=:id") suspend fun deleteHabitLogs(id: Long)

    // ---- ислам
    @Query("SELECT * FROM ibadah_log") fun ibadah(): Flow<List<IbadahLog>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertIbadah(l: IbadahLog)
    @Query("DELETE FROM ibadah_log WHERE day=:day AND kind=:kind") suspend fun deleteIbadah(day: Long, kind: String)

    @Query("SELECT * FROM fast_log") fun fasts(): Flow<List<FastLog>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertFast(f: FastLog)
    @Query("DELETE FROM fast_log WHERE day=:day") suspend fun deleteFast(day: Long)

    @Query("SELECT * FROM quran_log") fun quran(): Flow<List<QuranLog>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertQuran(q: QuranLog)
    @Query("DELETE FROM quran_log WHERE day=:day") suspend fun deleteQuran(day: Long)

    @Query("SELECT * FROM zikr_log") fun zikr(): Flow<List<ZikrLog>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertZikr(z: ZikrLog)

    @Query("SELECT * FROM goals") fun goals(): Flow<List<GoalEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertGoal(g: GoalEntity): Long
    @Query("DELETE FROM goals WHERE id=:id") suspend fun deleteGoal(id: Long)

    // ---- категории
    @Query("SELECT * FROM categories ORDER BY sort") fun categories(): Flow<List<CategoryEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertCategory(c: CategoryEntity)
    @Query("DELETE FROM categories WHERE id=:id AND builtIn=0") suspend fun deleteCategory(id: String)
}
