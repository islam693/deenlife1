package com.deenlife.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

val Emerald = Color(0xFF34C38F)
val Gold = Color(0xFFE0B65A)

private val Dark = darkColorScheme(
    primary = Emerald, onPrimary = Color(0xFF06231A),
    secondary = Gold, onSecondary = Color(0xFF2A2006),
    tertiary = Color(0xFF7C6CF0),
    background = Color(0xFF121316), onBackground = Color(0xFFECEDEF),
    surface = Color(0xFF1B1C21), onSurface = Color(0xFFECEDEF),
    surfaceVariant = Color(0xFF26272D), onSurfaceVariant = Color(0xFFA6A9B2),
    surfaceContainer = Color(0xFF1F2026), surfaceContainerHigh = Color(0xFF26272D),
    outline = Color(0xFF3A3C44), outlineVariant = Color(0xFF2C2E35),
    error = Color(0xFFE5575F)
)

private val Light = lightColorScheme(
    primary = Color(0xFF0E9F6E), onPrimary = Color.White,
    secondary = Color(0xFFB8892B), onSecondary = Color.White,
    tertiary = Color(0xFF6554D6),
    background = Color(0xFFF5F6F8), onBackground = Color(0xFF17181C),
    surface = Color.White, onSurface = Color(0xFF17181C),
    surfaceVariant = Color(0xFFECEEF2), onSurfaceVariant = Color(0xFF5D616B),
    surfaceContainer = Color(0xFFF0F2F5), surfaceContainerHigh = Color(0xFFE8EAEE),
    outline = Color(0xFFCDD0D8), outlineVariant = Color(0xFFE1E3E9),
    error = Color(0xFFD13C45)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun DeenLifeTheme(themeMode: Int, content: @Composable () -> Unit) {
    val dark = when (themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light, shapes = AppShapes, content = content)
}
