package com.deenlife.ui.common

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.deenlife.domain.PALETTE
import com.deenlife.util.*
import java.time.LocalDate

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    container: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = MaterialTheme.shapes.large
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    if (onClick != null) {
        Surface(onClick = onClick, modifier = modifier, shape = shape, color = container, border = border) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Surface(modifier = modifier, shape = shape, color = container, border = border) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, trailing: @Composable (() -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenScaffold(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
    floating: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад") }
                },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = floating,
        content = content
    )
}

@Composable
fun ProgressRing(progress: Float, size: Int = 72, stroke: Int = 9, color: Color = MaterialTheme.colorScheme.primary, label: String) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(Modifier.size(size.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = stroke.dp.toPx()
            val inset = s / 2
            drawArc(track, 0f, 360f, false, topLeft = Offset(inset, inset), size = Size(this.size.width - s, this.size.height - s), style = Stroke(s))
            drawArc(
                color, -90f, 360f * progress.coerceIn(0f, 1f), false,
                topLeft = Offset(inset, inset), size = Size(this.size.width - s, this.size.height - s),
                style = Stroke(s, cap = StrokeCap.Round)
            )
        }
        Text(label, fontWeight = FontWeight.Bold, fontSize = (size / 4.6).sp)
    }
}

/** Столбчатая диаграмма. [target] — необязательная целевая линия. */
@Composable
fun BarChart(
    values: List<Float>,
    labels: List<String>,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    target: Float? = null,
    maxValue: Float? = null,
    valueLabel: (Float) -> String = { it.toInt().toString() }
) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val line = MaterialTheme.colorScheme.secondary
    val max = maxOf(maxValue ?: 0f, values.maxOrNull() ?: 0f, target ?: 0f, 1f)
    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val n = values.size.coerceAtLeast(1)
            val gap = if (n > 14) 2.dp.toPx() else 8.dp.toPx()
            val w = (size.width - gap * (n - 1)) / n
            values.forEachIndexed { i, v ->
                val x = i * (w + gap)
                drawRoundRect(track, Offset(x, 0f), Size(w, size.height), androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
                val h = size.height * (v / max).coerceIn(0f, 1f)
                if (h > 0f) drawRoundRect(color, Offset(x, size.height - h), Size(w, h), androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
            }
            if (target != null) {
                val y = size.height * (1 - target / max)
                drawLine(line, Offset(0f, y), Offset(size.width, y), 2.dp.toPx())
            }
        }
        Spacer(Modifier.height(4.dp))
        if (labels.size <= 14) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                labels.forEach { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f), textAlign = TextAlign.Center) }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(labels.first(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(labels.last(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun StatTile(title: String, value: String, modifier: Modifier = Modifier, accent: Color = MaterialTheme.colorScheme.primary) {
    AppCard(modifier) {
        Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = accent)
    }
}

@Composable
fun ColorDot(color: Int, size: Int = 12) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Color(color)))
}

@Composable
fun ColorPickerRow(selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PALETTE.forEach { c ->
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Color(c)).clickable { onSelect(c) },
                contentAlignment = Alignment.Center
            ) { if (c == selected) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
fun EmptyHint(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
fun CheckCircle(done: Boolean, onClick: () -> Unit, size: Int = 28) {
    IconButton(onClick = onClick, modifier = Modifier.size(size.dp + 12.dp)) {
        Icon(
            if (done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null,
            tint = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
            modifier = Modifier.size(size.dp)
        )
    }
}

@Composable
fun ChipsRow(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
fun <T> ChoiceChips(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    ChipsRow {
        options.forEach { (v, label) ->
            FilterChip(selected = v == selected, onClick = { onSelect(v) }, label = { Text(label) })
        }
    }
}

@Composable
fun NumberField(
    label: String, value: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier, suffix: String? = null
) {
    OutlinedTextField(
        value = if (value == 0) "" else value.toString(),
        onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(5).toIntOrNull() ?: 0) },
        label = { Text(label) }, singleLine = true, suffix = suffix?.let { { Text(it) } },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = modifier
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String = "Удалить", onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(text) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirm, color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerDialog(initial: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    val m = ((initial % 1440) + 1440) % 1440
    val state = rememberTimePickerState(initialHour = m / 60, initialMinute = m % 60, is24Hour = true)
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onConfirm(state.hour * 60 + state.minute); onDismiss() }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
        text = { Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { TimePicker(state = state) } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerDlg(initialDay: Long, onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initialDay * 86_400_000L)
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { state.selectedDateMillis?.let { onPick(Math.floorDiv(it, 86_400_000L)) }; onDismiss() }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    ) { DatePicker(state = state) }
}

/** Кнопка-поле выбора времени. */
@Composable
fun TimeField(label: String, minutes: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = true }, modifier = modifier) {
        Text("$label  ${fmtTime(minutes)}")
    }
    if (open) TimePickerDialog(minutes, { open = false }, onChange)
}

/** Кнопка-поле выбора даты. */
@Composable
fun DateField(label: String, day: Long, onChange: (Long) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { open = true }, modifier = modifier) {
        val d = LocalDate.ofEpochDay(day)
        Text("$label  ${d.dayOfMonth} ${RU_MONTHS_GEN[d.monthValue - 1]} ${d.year}")
    }
    if (open) DatePickerDlg(day, { open = false }, onChange)
}

@Composable
fun WeekdayChips(selected: Set<Int>, onChange: (Set<Int>) -> Unit) {
    ChipsRow {
        RU_DAYS_SHORT.forEachIndexed { i, n ->
            val d = i + 1
            FilterChip(selected = d in selected, onClick = { onChange(if (d in selected) selected - d else selected + d) }, label = { Text(n) })
        }
    }
}

@Composable
fun IconBadge(icon: ImageVector, color: Color, size: Int = 40) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = color, modifier = Modifier.size((size * 0.55).dp))
    }
}

fun iconFor(category: String): ImageVector = when (category) {
    "COURSE" -> Icons.Rounded.School
    "SELF_STUDY" -> Icons.Rounded.Book
    "HOMEWORK" -> Icons.Rounded.Assignment
    "WORKOUT" -> Icons.Rounded.FitnessCenter
    "MEAL" -> Icons.Rounded.Restaurant
    "SLEEP" -> Icons.Rounded.Bedtime
    "WAKE" -> Icons.Rounded.WbSunny
    "REST" -> Icons.Rounded.Spa
    "MEETING" -> Icons.Rounded.Groups
    "RELIGION" -> Icons.Rounded.NightsStay
    else -> Icons.Rounded.Event
}
