package com.deenlife.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private val receiverScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

private fun BroadcastReceiver.runAsync(ctx: Context, block: suspend () -> Unit) {
    val pending = goAsync()
    receiverScope.launch {
        try { block() } catch (t: Throwable) { Log.e("DeenLife", "receiver failed", t) } finally { pending.finish() }
    }
}

/** Срабатывание будильника: показать напоминания и поставить следующий. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        runAsync(context) { ReminderScheduler.fireDue(context.applicationContext) }
    }
}

/** Перезагрузка устройства, смена времени/часового пояса, обновление приложения. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.createChannels(context)
        runAsync(context) { ReminderScheduler.fireDue(context.applicationContext) }
    }
}

/** Периодическая подстраховка: если система убила будильник, этот воркер восстановит расписание. */
class SafetyWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        return try {
            ReminderScheduler.fireDue(applicationContext)
            Result.success()
        } catch (t: Throwable) {
            Result.retry()
        }
    }
}
