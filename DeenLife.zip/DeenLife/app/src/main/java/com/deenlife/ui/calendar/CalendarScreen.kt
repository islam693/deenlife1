package com.deenlife.ui.calendar

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.zIndex
import com.deenlife.domain.*
import com.deenlife.ui.*
import com.deenlife.ui.common.*
import com.deenlife.ui.home.openItem
import com.deenlife.util.*
import java.time.LocalDate
import kotlin.math.roundToInt

private const val HOUR_DP = 56

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(vm: AppViewModel, sn: Snapshot, nav: Nav) {
    var mode by rememberSaveable { mutableIntStateOf(0) }       // 0 день, 1 неделя, 2 месяц
    var day by rememberSaveable { mutableLongStateOf(todayEpoch()) }
    var quick by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf(false) }
    val d = LocalDate.ofEpochDay(day)

    val title = when (mode) {
        0 -> dayLabel(day)
        1 -> "${shortDate(weekStart(day))} – ${shortDate(weekStart(day) + 6)}"
        else -> "${RU_MONTHS_NOM[d.monthValue - 1]} ${d.year}"
    }
    fun shift(dir: Int) {
        day = when (mode) {
            0 -> day + dir
            1 -> day + 7 * dir
            else -> d.plusMonths(dir.toLong()).withDayOfMonth(1).toEpochDay()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            FloatingActionButton(onClick = { quick = true }, containerColor = MaterialTheme.colorScheme.primary) { Icon(Icons.Rounded.Add, "Добавить") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { shift(-1) }) { Icon(Icons.Rounded.ChevronLeft, "Назад") }
                Text(title, Modifier.weight(1f).clickable { pick = true }, textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                IconButton(onClick = { shift(1) }) { Icon(Icons.Rounded.ChevronRight, "Вперёд") }
                IconButton(onClick = { day = todayEpoch() }) { Icon(Icons.Rounded.Today, "Сегодня") }
                IconButton(onClick = { nav.push(Route.Search) }) { Icon(Icons.Rounded.Search, "Поиск") }
            }
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                listOf("День", "Неделя", "Месяц").forEachIndexed { i, t ->
                    SegmentedButton(selected = mode == i, onClick = { mode = i }, shape = SegmentedButtonDefaults.itemShape(i, 3)) { Text(t) }
                }
            }
            Spacer(Modifier.height(8.dp))
            when (mode) {
                0 -> DayView(vm, sn, nav, day, Modifier.weight(1f)) { day += it }
                1 -> WeekView(sn, nav, day, Modifier.weight(1f)) { day = it; mode = 0 }
                else -> MonthView(sn, day, Modifier.weight(1f)) { day = it; mode = 0 }
            }
        }
    }
    if (quick) com.deenlife.ui.home.QuickAddSheet(vm, sn, day, { quick = false }) { nav.push(it) }
    if (pick) DatePickerDlg(day, { pick = false }) { day = it }
}

@Composable
private fun DayView(vm: AppViewModel, sn: Snapshot, nav: Nav, day: Long, modifier: Modifier, shiftDay: (Int) -> Unit) {
    val items = remember(sn, day) { Timeline.build(day, sn) }
    val conflicts = remember(items) { Timeline.conflicts(items) }
    val conflictIds = remember(conflicts) { conflicts.flatMap { listOf(it.first.id, it.second.id) }.toSet() }
    val scroll = rememberScrollState()
    val density = LocalDensity.current
    val hourPx = with(density) { HOUR_DP.dp.toPx() }
    val clock by vm.clock.collectAsState()

    LaunchedEffect(day) {
        val target = (clock.hour - 1).coerceAtLeast(0)
        scroll.scrollTo((target * hourPx).toInt())
    }

    Column(modifier) {
        if (conflicts.isNotEmpty()) {
            Text(
                "⚠ Пересечений: ${conflicts.size}. Перетащите карточку (долгое нажатие) или откройте её для редактирования.",
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }
        Box(Modifier.fillMaxSize().verticalScroll(scroll)) {
            Box(Modifier.fillMaxWidth().height((HOUR_DP * 24).dp)) {
                for (h in 0..23) {
                    Row(Modifier.offset(y = (h * HOUR_DP).dp).fillMaxWidth(), verticalAlignment = Alignment.Top) {
                        Text("%02d:00".format(h), Modifier.width(52.dp).padding(start = 12.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        HorizontalDivider(Modifier.padding(top = 7.dp, end = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
                if (day == todayEpoch()) {
                    val y = (clock.hour * 60 + clock.minute) / 60f * HOUR_DP
                    Box(Modifier.offset(y = y.dp + 7.dp, x = 52.dp).fillMaxWidth().height(2.dp).background(MaterialTheme.colorScheme.error))
                }
                // раскладка пересекающихся блоков по колонкам
                val timed = items.filter { it.e > it.s }
                val cols = remember(timed) { layoutColumns(timed) }
                BoxWithConstraintsCompat(Modifier.fillMaxSize().padding(start = 56.dp, end = 12.dp)) { widthDp ->
                    timed.forEach { it ->
                        val (col, total) = cols[it.id] ?: (0 to 1)
                        EventBlock(vm, it, widthDp / total, col, hourPx, it.id in conflictIds, nav, day, shiftDay)
                    }
                    items.filter { it.e <= it.s && it.kind != Kind.SLEEP }.forEach { p ->
                        PointMarker(p, vm, nav)
                    }
                }
            }
        }
    }
}

@Composable
private fun BoxWithConstraintsCompat(modifier: Modifier, content: @Composable BoxScope.(Float) -> Unit) {
    BoxWithConstraints(modifier) { content(maxWidth.value) }
}

private fun layoutColumns(list: List<TItem>): Map<String, Pair<Int, Int>> {
    val res = HashMap<String, Pair<Int, Int>>()
    val sorted = list.sortedBy { it.s }
    var group = mutableListOf<TItem>()
    var groupEnd = -1
    fun flush() {
        if (group.isEmpty()) return
        val colEnds = mutableListOf<Int>()
        val assign = HashMap<String, Int>()
        for (it in group) {
            var c = colEnds.indexOfFirst { e -> e <= it.s }
            if (c < 0) { colEnds += it.e; c = colEnds.size - 1 } else colEnds[c] = it.e
            assign[it.id] = c
        }
        group.forEach { res[it.id] = assign[it.id]!! to colEnds.size }
        group = mutableListOf()
    }
    for (it in sorted) {
        if (group.isNotEmpty() && it.s >= groupEnd) { flush(); groupEnd = -1 }
        group += it
        groupEnd = maxOf(groupEnd, it.e)
    }
    flush()
    return res
}

@Composable
private fun PointMarker(p: TItem, vm: AppViewModel, nav: Nav) {
    val y = p.s / 60f * HOUR_DP
    Row(
        Modifier.offset(y = y.dp + 1.dp).clip(RoundedCornerShape(8.dp)).background(Color(p.color).copy(alpha = 0.18f))
            .clickable { openItem(nav, p) }.padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(iconFor(p.category), null, tint = Color(p.color), modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(4.dp))
        Text("${fmtTime(p.s)} ${p.title}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun EventBlock(
    vm: AppViewModel, it: TItem, colWidth: Float, col: Int, hourPx: Float, conflict: Boolean,
    nav: Nav, day: Long, shiftDay: (Int) -> Unit
) {
    val density = LocalDensity.current
    var dragY by remember(it.id, it.s) { mutableFloatStateOf(0f) }
    var dragX by remember(it.id, it.s) { mutableFloatStateOf(0f) }
    var dragging by remember(it.id, it.s) { mutableStateOf(false) }
    val top = it.s / 60f * HOUR_DP
    val height = ((it.e - it.s) / 60f * HOUR_DP).coerceAtLeast(30f)
    val color = Color(it.color)
    val movable = !it.carry && (it.kind == Kind.EVENT || it.kind == Kind.COURSE || it.kind == Kind.WORKOUT)

    Box(
        Modifier
            .offset(x = (colWidth * col).dp, y = top.dp)
            .offset { IntOffset(dragX.roundToInt(), dragY.roundToInt()) }
            .width(colWidth.dp - 3.dp).height(height.dp - 2.dp)
            .zIndex(if (dragging) 5f else 1f)
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = if (dragging) 0.55f else 0.28f))
            .then(if (conflict) Modifier.background(Color.Transparent) else Modifier)
            .clickable { openItem(nav, it) }
            .pointerInput(it.id, it.s, day) {
                if (!movable) return@pointerInput
                detectDragGesturesAfterLongPress(
                    onDragStart = { dragging = true },
                    onDragEnd = {
                        val dMin = ((dragY / hourPx * 60f) / 15f).roundToInt() * 15
                        val colW = with(density) { 90.dp.toPx() }
                        val dDays = (dragX / (colW * 2.2f)).roundToInt()
                        dragging = false; dragY = 0f; dragX = 0f
                        if (dMin != 0 || dDays != 0) vm.moveItem(it, dDays, dMin)
                    },
                    onDragCancel = { dragging = false; dragY = 0f; dragX = 0f },
                    onDrag = { change, amount -> change.consume(); dragY += amount.y; dragX += amount.x }
                )
            }
            .padding(start = 0.dp)
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(if (conflict) MaterialTheme.colorScheme.error else color))
        Column(Modifier.padding(start = 10.dp, end = 6.dp, top = 4.dp)) {
            Text(
                it.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                textDecoration = if (it.done || it.moved) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
            )
            if (height >= 44) Text("${fmtTime(it.s)}–${fmtTime(it.e)}${if (conflict) " ⚠" else ""}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
private fun WeekView(sn: Snapshot, nav: Nav, day: Long, modifier: Modifier, openDay: (Long) -> Unit) {
    val ws = weekStart(day)
    val today = todayEpoch()
    LazyColumn(modifier, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items((0..6).map { ws + it }, key = { it }) { d ->
            val its = remember(sn, d) { Timeline.build(d, sn, prayers = false, sleep = false).filter { !it.carry } }
            AppCard(Modifier.fillMaxWidth(), onClick = { openDay(d) }, container = if (d == today) MaterialTheme.colorScheme.primary.copy(alpha = 0.10f) else MaterialTheme.colorScheme.surface) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(dayLabel(d), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    if (isoDay(d) in sn.settings.weekend) Text("выходной", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                }
                if (its.isEmpty()) Text("Свободно", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                its.take(6).forEach {
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        ColorDot(it.color, 8)
                        Spacer(Modifier.width(8.dp))
                        Text(fmtTime(it.s), style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(44.dp))
                        Text(it.title, style = MaterialTheme.typography.bodyMedium, maxLines = 1, modifier = Modifier.weight(1f),
                            textDecoration = if (it.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null)
                    }
                }
                if (its.size > 6) Text("и ещё ${its.size - 6}…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
private fun MonthView(sn: Snapshot, day: Long, modifier: Modifier, openDay: (Long) -> Unit) {
    val first = LocalDate.ofEpochDay(day).withDayOfMonth(1)
    val lead = first.dayOfWeek.value - 1
    val len = first.lengthOfMonth()
    val rows = (lead + len + 6) / 7
    val today = todayEpoch()
    Column(modifier.padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth()) {
            RU_DAYS_SHORT.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Spacer(Modifier.height(4.dp))
        for (r in 0 until rows) {
            Row(Modifier.fillMaxWidth().weight(1f, fill = false).height(64.dp)) {
                for (c in 0..6) {
                    val n = r * 7 + c - lead + 1
                    if (n < 1 || n > len) { Spacer(Modifier.weight(1f)); continue }
                    val d = first.plusDays((n - 1).toLong()).toEpochDay()
                    val its = remember(sn, d) { Timeline.build(d, sn, prayers = false, sleep = false).filter { !it.carry } }
                    val isToday = d == today
                    val weekend = isoDay(d) in sn.settings.weekend
                    Column(
                        Modifier.weight(1f).padding(2.dp).fillMaxHeight().clip(RoundedCornerShape(12.dp))
                            .background(if (isToday) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface)
                            .clickable { openDay(d) }.padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("$n", fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                            color = if (isToday) MaterialTheme.colorScheme.primary else if (weekend) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            its.map { it.color }.distinct().take(3).forEach { ColorDot(it, 6) }
                        }
                        if (its.size > 3) Text("+${its.size - 3}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Text("Нажмите на день, чтобы открыть его. Выходные выделены цветом.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
    }
}
