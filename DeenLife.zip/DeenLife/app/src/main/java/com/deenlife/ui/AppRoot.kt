package com.deenlife.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.deenlife.domain.Snapshot
import com.deenlife.ui.calendar.CalendarScreen
import com.deenlife.ui.calendar.EventEditorScreen
import com.deenlife.ui.habits.HabitsScreen
import com.deenlife.ui.home.HomeScreen
import com.deenlife.ui.islam.*
import com.deenlife.ui.planner.PlannerScreen
import com.deenlife.ui.profile.CategoriesScreen
import com.deenlife.ui.profile.ProfileScreen
import com.deenlife.ui.search.SearchScreen
import com.deenlife.ui.sleep.SleepScreen
import com.deenlife.ui.sport.SportScreen
import com.deenlife.ui.stats.StatsScreen
import com.deenlife.ui.study.StudyScreen

@Composable
fun AppRoot(vm: AppViewModel, sn: Snapshot) {
    val nav = remember { Nav() }
    val snackbar = remember { SnackbarHostState() }

    // разрешение на уведомления (Android 13+)
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    BackHandler(enabled = nav.stack.isNotEmpty() || nav.tab != 0) {
        if (nav.stack.isNotEmpty()) nav.pop() else nav.tab = 0
    }

    val route = nav.stack.lastOrNull()
    Box(Modifier.fillMaxSize()) {
        if (route == null) {
            MainTabs(vm, sn, nav)
        } else {
            val back = { nav.pop() }
            when (route) {
                is Route.EventEdit -> EventEditorScreen(vm, sn, route, back)
                Route.Stats -> StatsScreen(vm, sn, back)
                Route.Planner -> PlannerScreen(vm, sn, back)
                Route.Search -> SearchScreen(vm, sn, nav, back)
                Route.Sleep -> SleepScreen(vm, sn, back)
                Route.Sport -> SportScreen(vm, sn, back)
                Route.Habits -> HabitsScreen(vm, sn, back)
                Route.Quran -> QuranScreen(vm, sn, back)
                Route.Zikr -> ZikrScreen(vm, sn, back)
                Route.Fasting -> FastingScreen(vm, sn, back)
                Route.HijriCal -> HijriScreen(vm, sn, back)
                Route.Goals -> GoalsScreen(vm, sn, back)
                Route.PrayerSettings -> PrayerSettingsScreen(vm, sn, back)
                Route.Categories -> CategoriesScreen(vm, sn, back)
            }
        }
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(bottom = if (route == null) 84.dp else 16.dp))
    }
}

private data class TabItem(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
private fun MainTabs(vm: AppViewModel, sn: Snapshot, nav: Nav) {
    val tabs = listOf(
        TabItem("Главная", Icons.Rounded.Home),
        TabItem("Календарь", Icons.Rounded.CalendarMonth),
        TabItem("Учёба", Icons.Rounded.School),
        TabItem("Ислам", Icons.Rounded.NightsStay),
        TabItem("Профиль", Icons.Rounded.Person)
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = nav.tab == i, onClick = { nav.tab = i },
                        icon = { Icon(t.icon, t.title) }, label = { Text(t.title, maxLines = 1) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            Crossfade(targetState = nav.tab, label = "tabs") { tab ->
                when (tab) {
                    0 -> HomeScreen(vm, sn, nav)
                    1 -> CalendarScreen(vm, sn, nav)
                    2 -> StudyScreen(vm, sn, nav)
                    3 -> IslamScreen(vm, sn, nav)
                    else -> ProfileScreen(vm, sn, nav)
                }
            }
        }
    }
}
