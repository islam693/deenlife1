package com.deenlife.domain

import com.deenlife.data.EventEntity
import com.deenlife.util.*

data class Slot(val s: Int, val e: Int) { val len: Int get() = e - s }

sealed interface SuggestionAction {
    data class AddEvents(val label: String, val events: List<EventEntity>) : SuggestionAction
    data class Move(val item: TItem) : SuggestionAction
}

data class Suggestion(val id: String, val text: String, val warn: Boolean, val action: SuggestionAction? = null)

/** Офлайн-помощник: анализирует расписание по правилам и составляет план дня/недели. */
object Planner {

    private fun round15(m: Int) = (m + 14) / 15 * 15

    fun mergeSlots(xs: List<Slot>): List<Slot> {
        val sorted = xs.filter { it.e > it.s }.sortedBy { it.s }
        val out = mutableListOf<Slot>()
        for (x in sorted) {
            if (out.isNotEmpty() && x.s <= out.last().e) out[out.size - 1] = Slot(out.last().s, maxOf(out.last().e, x.e))
            else out += x
        }
        return out
    }

    fun freeSlots(busy: List<Slot>, from: Int, to: Int, minLen: Int): List<Slot> {
        val res = mutableListOf<Slot>()
        var cur = from
        for (b in mergeSlots(busy)) {
            if (b.e <= cur) continue
            if (b.s >= to) break
            if (b.s - cur >= minLen) res += Slot(cur, b.s)
            cur = maxOf(cur, b.e)
        }
        if (to - cur >= minLen) res += Slot(cur, to)
        return res
    }

    fun busyFor(day: Long, sn: Snapshot): List<Slot> {
        val items = Timeline.build(day, sn, prayers = true, sleep = false)
        val busy = mutableListOf<Slot>()
        for (it in items) {
            if (it.moved) continue
            when (it.kind) {
                Kind.EVENT, Kind.COURSE, Kind.WORKOUT -> if (it.e > it.s) busy += Slot(it.s, it.e)
                Kind.PRAYER -> if (it.id.startsWith("P:")) busy += Slot(it.s, it.s + 20)
                else -> {}
            }
        }
        return busy
    }

    private fun window(day: Long, sn: Snapshot, fromMin: Int): Pair<Int, Int> {
        val s = sn.settings
        val iso = isoDay(day)
        val wake = s.wake[iso - 1]
        var bed = s.bed[iso - 1]
        if (bed < 360) bed += 1440
        return maxOf(wake + 30, round15(fromMin)) to minOf(bed - 45, 1440)
    }

    /** Ищет свободное окно длиной [len] минут начиная с (день, минута). */
    fun findSlot(sn: Snapshot, fromDay: Long, fromMin: Int, len: Int, searchDays: Int = 4): Pair<Long, Int>? {
        for (off in 0 until searchDays) {
            val d = fromDay + off
            val (a, b) = window(d, sn, if (off == 0) fromMin else 0)
            val slot = freeSlots(busyFor(d, sn), a, b, len).firstOrNull() ?: continue
            return d to round15(slot.s)
        }
        return null
    }

    private fun ev(title: String, cat: String, sn: Snapshot, day: Long, s: Int, e: Int, rem: Int, notes: String = "", id: Long = 0) =
        EventEntity(id = id, title = title, category = cat, color = sn.catColor(cat), startDay = day, startMin = s, endMin = e, reminderMin = rem, notes = notes, source = "planner")

    /** План на один день. [sn] должен включать уже предложенные события, чтобы не было пересечений. */
    fun generateDay(day: Long, sn: Snapshot, fromMin: Int, tempId: Long): List<EventEntity> {
        val s = sn.settings
        val iso = isoDay(day)
        val weekend = iso in s.weekend
        val (start, end) = window(day, sn, fromMin)
        if (end - start < 30) return emptyList()
        val items = Timeline.build(day, sn, prayers = false, sleep = false)
        val busy = busyFor(day, sn).toMutableList()
        val out = mutableListOf<EventEntity>()
        var tid = tempId
        fun fits(a: Int, b: Int) = a >= start && b <= end && busy.none { a < it.e && it.s < b }
        fun add(e: EventEntity) { out += e; busy += Slot(e.startMin, e.endMin) }

        // приёмы пищи
        val meals = items.count { it.category == "MEAL" }
        if (meals < 1) {
            var t = 12 * 60 + 30
            while (t <= 14 * 60) { if (fits(t, t + 30)) { add(ev("Обед", "MEAL", sn, day, t, t + 30, -1, id = tid--)); break }; t += 15 }
        }
        if (meals < 2) {
            var t = 18 * 60 + 30
            while (t <= 20 * 60 + 30) { if (fits(t, t + 40)) { add(ev("Ужин", "MEAL", sn, day, t, t + 40, -1, id = tid--)); break }; t += 15 }
        }

        // самоподготовка
        val goal = if (weekend) s.studyGoalMin / 2 else s.studyGoalMin
        val planned = items.filter { it.category == "SELF_STUDY" || it.category == "HOMEWORK" && it.kind == Kind.EVENT }.sumOf { it.minutes } +
            sn.studyLogs.filter { it.day == day }.sumOf { it.minutes }
        var need = goal - planned
        val hw = sn.homework.filter { !it.done }.sortedBy { it.deadlineDay * 1440 + it.deadlineMin }
        val remaining = hw.associate { it.id to it.estMin }.toMutableMap()
        var guard = 0
        while (need >= 30 && guard++ < 6) {
            val minLen = minOf(45, need)
            val slot = freeSlots(busy, start, end, minLen).firstOrNull() ?: break
            val len = minOf(90, need, slot.len) / 15 * 15
            if (len < 30) break
            val target = hw.firstOrNull { (remaining[it.id] ?: 0) > 0 }
            val title: String
            val cat: String
            if (target != null) {
                title = "Домашка: ${target.title}"; cat = "HOMEWORK"
                remaining[target.id] = (remaining[target.id] ?: 0) - len
            } else { title = "Самостоятельная подготовка"; cat = "SELF_STUDY" }
            val a = round15(slot.s)
            add(ev(title, cat, sn, day, a, a + len, 10, id = tid--))
            busy += Slot(a + len, a + len + 10) // перерыв
            need -= len
        }

        // тренировка
        if (iso !in s.restDays) {
            val ws = weekStart(day)
            var cnt = 0
            for (d in ws until ws + 7) cnt += Timeline.build(d, sn, false, false).count { it.kind == Kind.WORKOUT || it.category == "WORKOUT" }
            val today = items.any { it.kind == Kind.WORKOUT || it.category == "WORKOUT" } || out.any { it.category == "WORKOUT" }
            if (cnt < s.workoutPerWeek && !today) {
                val slots = freeSlots(busy, start, end, 60)
                val slot = slots.firstOrNull { it.e - maxOf(it.s, 16 * 60) >= 60 } ?: slots.firstOrNull()
                if (slot != null) {
                    val a = round15(maxOf(slot.s, if (slot.e - 16 * 60 >= 60) 16 * 60 else slot.s))
                    add(ev("Тренировка", "WORKOUT", sn, day, a, a + 60, 30, id = tid--))
                }
            }
        }

        // отдых вечером
        val rest = freeSlots(busy, maxOf(start, 20 * 60), end, 45).firstOrNull()
        if (rest != null && items.none { it.category == "REST" }) {
            val a = round15(rest.s)
            add(ev("Отдых", "REST", sn, day, a, a + 30, -1, id = tid--))
        }
        return out.sortedBy { it.startMin }
    }

    /** План на [days] дней начиная с [startDay]. Для сегодняшнего дня планирование идёт от текущего времени. */
    fun generate(startDay: Long, days: Int, sn: Snapshot, nowMin: Int, isToday: Boolean): List<EventEntity> {
        var cur = sn
        val all = mutableListOf<EventEntity>()
        var tid = -1L
        for (i in 0 until days) {
            val d = startDay + i
            val from = if (isToday && i == 0) nowMin + 15 else 0
            val part = generateDay(d, cur, from, tid)
            tid -= 100
            all += part
            cur = cur.copy(events = cur.events + part)
        }
        return all.map { it.copy(id = 0) }
    }

    // ---------------- Подсказки ----------------

    fun analyze(sn: Snapshot, today: Long, nowMin: Int): List<Suggestion> {
        val s = sn.settings
        val out = mutableListOf<Suggestion>()
        val items = Timeline.build(today, sn)
        val tomorrow = today + 1
        val items2 = Timeline.build(tomorrow, sn)
        val isoT = isoDay(today)

        // 1. пересечения
        for ((d, list) in listOf(today to items, tomorrow to items2)) {
            Timeline.conflicts(list).forEach { (a, b) ->
                out += Suggestion(
                    "conf:${a.id}:${b.id}",
                    "${if (d == today) "Сегодня" else "Завтра"} пересекаются «${a.title}» и «${b.title}» (${fmtTime(maxOf(a.s, b.s))}–${fmtTime(minOf(a.e, b.e))}).",
                    true,
                    if (b.kind == Kind.EVENT || b.kind == Kind.WORKOUT) SuggestionAction.Move(b) else null
                )
            }
        }

        // 2. не выполнено
        items.filter {
            (it.kind == Kind.EVENT || it.kind == Kind.WORKOUT) && !it.done && !it.moved && !it.carry &&
                it.category != "SLEEP" && it.category != "WAKE" && maxOf(it.e, it.s) < nowMin
        }.take(3).forEach {
            out += Suggestion("over:${it.id}", "Не выполнено: «${it.title}» (было в ${fmtTime(it.s)}). Перенести на ближайшее свободное время?", true, SuggestionAction.Move(it))
        }
        sn.homework.filter { !it.done && (it.deadlineDay < today || (it.deadlineDay == today && it.deadlineMin < nowMin)) }.take(2).forEach {
            out += Suggestion("hwover:${it.id}", "Просрочено задание «${it.title}». Перенести срок на завтра?", true, SuggestionAction.Move(
                TItem("H:${it.id}", Kind.HOMEWORK, it.id, it.deadlineDay, it.title, it.course, it.deadlineMin, it.deadlineMin, 0, "HOMEWORK", false)
            ))
        }

        // 3. самоподготовка после пар
        val goal = if (isoT in s.weekend) s.studyGoalMin / 2 else s.studyGoalMin
        val studied = items.filter { it.category == "SELF_STUDY" && it.kind == Kind.EVENT || it.category == "HOMEWORK" && it.kind == Kind.EVENT }.sumOf { it.minutes } +
            sn.studyLogs.filter { it.day == today }.sumOf { it.minutes }
        val courses = items.filter { it.kind == Kind.COURSE }
        if (goal > 0 && studied < goal) {
            val lastEnd = courses.maxOfOrNull { it.e }
            val from = maxOf((lastEnd ?: 0) + 30, nowMin)
            val len = minOf(90, goal - studied).let { it / 15 * 15 }.coerceAtLeast(30)
            val slot = findSlot(sn, today, from, len, 1)
            if (slot != null) {
                val e = ev("Самостоятельная подготовка", "SELF_STUDY", sn, slot.first, slot.second, slot.second + len, 10)
                val intro = if (lastEnd != null) "Пары заканчиваются в ${fmtTime(lastEnd)}. " else ""
                out += Suggestion("study", "${intro}Предлагаю самоподготовку ${fmtTime(slot.second)}–${fmtTime(slot.second + len)} (до цели осталось ${fmtDur(goal - studied)}).", false,
                    SuggestionAction.AddEvents("Добавить", listOf(e)))
            }
        }

        // 4. ранний подъём завтра
        val isoN = isoDay(tomorrow)
        val first = items2.filter { (it.kind == Kind.EVENT || it.kind == Kind.COURSE || it.kind == Kind.WORKOUT) && !it.carry && !it.moved && it.category != "SLEEP" && it.category != "WAKE" }.minByOrNull { it.s }
        var wakeTomorrow = s.wake[isoN - 1]
        if (first != null && first.s - 90 < wakeTomorrow) wakeTomorrow = maxOf(first.s - 90, 0)
        if (wakeTomorrow <= 8 * 60) {
            var bedtime = wakeTomorrow - s.sleepGoalMin
            if (bedtime < 0) bedtime += 1440
            val prep = bedtime - s.bedPrep
            val inWindow = nowMin >= prep && nowMin <= bedtime + 90
            out += Suggestion(
                "sleep",
                if (inWindow) "Пора готовиться ко сну: завтра подъём в ${fmtTime(wakeTomorrow)}. Отбой не позже ${fmtTime(bedtime)}, чтобы выспаться (${fmtDur(s.sleepGoalMin)})."
                else "Завтра рано вставать (${fmtTime(wakeTomorrow)}). Чтобы выспаться, ложитесь не позже ${fmtTime(bedtime)}.",
                inWindow
            )
        }

        // 5. тренировки
        if (isoT !in s.restDays) {
            val ws = weekStart(today)
            var cnt = 0
            for (d in ws until ws + 7) cnt += Timeline.build(d, sn, false, false).count { it.kind == Kind.WORKOUT || it.category == "WORKOUT" }
            val hasToday = items.any { it.kind == Kind.WORKOUT || it.category == "WORKOUT" }
            if (cnt < s.workoutPerWeek && !hasToday) {
                val slot = findSlot(sn, today, maxOf(nowMin, 16 * 60), 60, 3)
                if (slot != null) {
                    val e = ev("Тренировка", "WORKOUT", sn, slot.first, slot.second, slot.second + 60, 30)
                    val whenTxt = if (slot.first == today) "сегодня" else if (slot.first == tomorrow) "завтра" else shortDate(slot.first)
                    out += Suggestion("workout", "На этой неделе тренировок: $cnt из ${s.workoutPerWeek}. Свободное время — $whenTxt в ${fmtTime(slot.second)}.", false,
                        SuggestionAction.AddEvents("Добавить", listOf(e)))
                }
            }
        }

        // 6. перегрузка
        val tasks = Timeline.tasks(items)
        val planned = items.filter { (it.kind == Kind.EVENT || it.kind == Kind.COURSE || it.kind == Kind.WORKOUT) && !it.moved && it.category != "SLEEP" }.sumOf { it.minutes }
        if (tasks.size > 8 || planned > 12 * 60) {
            val victim = tasks.filter { !it.done && it.kind != Kind.HOMEWORK && it.s > nowMin }.lastOrNull()
            out += Suggestion("overload", "Сегодня слишком много задач (${tasks.size}, запланировано ${fmtDur(planned)}). Предлагаю перенести менее важное.", true,
                victim?.let { SuggestionAction.Move(it) })
        }

        // 7. дедлайны
        sn.homework.filter { !it.done && it.deadlineDay in today..today + 2 && !(it.deadlineDay == today && it.deadlineMin < nowMin) }.take(2).forEach {
            val whenTxt = when (it.deadlineDay) { today -> "сегодня"; tomorrow -> "завтра"; else -> "послезавтра" }
            out += Suggestion("hw:${it.id}", "Скоро дедлайн: «${it.title}» — $whenTxt в ${fmtTime(it.deadlineMin)}.", false)
        }
        return out.sortedByDescending { it.warn }
    }
}

/** Проверка пересечения нового/изменённого события с расписанием на ближайшие 14 дней. Возвращает описание или null. */
fun conflictFor(sn: Snapshot, ev: EventEntity, ignoreId: Long): String? {
    if (ev.category == "WAKE" || ev.endMin <= ev.startMin) return null
    val s = ev.startMin
    val e = minOf(ev.endMin, 1440)
    for (d in ev.startDay..ev.startDay + 13) {
        if (!ev.occursOn(d)) continue
        val hit = Timeline.build(d, sn, prayers = false, sleep = false).firstOrNull {
            (it.kind == Kind.EVENT || it.kind == Kind.COURSE || it.kind == Kind.WORKOUT) && !it.moved && it.e > it.s &&
                it.category != "WAKE" && !(it.kind == Kind.EVENT && it.refId == ignoreId) && s < it.e && it.s < e
        }
        if (hit != null) return "${shortDate(d)}: пересекается с «${hit.title}» (${fmtTime(hit.s)}–${fmtTime(hit.e)})"
    }
    return null
}
