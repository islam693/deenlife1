package com.deenlife.ui.islam

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.deenlife.data.GoalEntity
import com.deenlife.domain.*
import com.deenlife.ui.AppViewModel
import com.deenlife.ui.common.*
import com.deenlife.util.*
import java.time.LocalDate

// ---------------------------------------------------------------- Коран

@Composable
fun QuranScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val today = todayEpoch()
    val s = sn.settings
    val pagesToday = sn.quran.firstOrNull { it.day == today }?.pages ?: 0
    val total = sn.quran.sumOf { it.pages }
    val week = (0..6).map { today - 6 + it }
    val goal = s.quranGoal
    var streak = 0
    run {
        var d = if (pagesAt(sn, today) >= goal && goal > 0) today else today - 1
        while (goal > 0 && pagesAt(sn, d) >= goal) { streak++; d-- }
    }
    ScreenScaffold("Чтение Корана", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ProgressRing(if (goal == 0) 0f else pagesToday.toFloat() / goal, 88, 10, label = "$pagesToday/$goal")
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("Сегодня прочитано страниц", style = MaterialTheme.typography.titleSmall)
                            Text("Серия дней с выполненной целью: $streak", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Всего: $total стр. (${"%.1f".format(total / 604f * 100)}% Корана при 604 стр.)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalIconButton(onClick = { vm.setQuranPages(today, pagesToday - 1) }) { Icon(Icons.Rounded.Remove, "−1 страница") }
                        FilledTonalButton(onClick = { vm.setQuranPages(today, pagesToday + 1) }) { Text("+1 страница") }
                        FilledTonalButton(onClick = { vm.setQuranPages(today, pagesToday + 5) }) { Text("+5") }
                    }
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Дневная цель (страниц)", style = MaterialTheme.typography.titleSmall)
                    ChoiceChips(listOf(1, 2, 3, 5, 10, 20).map { it to "$it" }, goal) { v -> vm.updateSettings { it.copy(quranGoal = v) } }
                    Text("20 страниц в день — один хатм за месяц; 2 страницы — примерно за 10 месяцев.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("За 7 дней", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    BarChart(week.map { pagesAt(sn, it).toFloat() }, week.map { RU_DAYS_SHORT[isoDay(it) - 1] }, target = goal.toFloat())
                }
            }
        }
    }
}

private fun pagesAt(sn: Snapshot, day: Long) = sn.quran.firstOrNull { it.day == day }?.pages ?: 0

// ---------------------------------------------------------------- Зикр

@Composable
fun ZikrScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val today = todayEpoch()
    var phrase by rememberSaveable { mutableStateOf(ZIKR_PHRASES[0]) }
    var session by rememberSaveable { mutableIntStateOf(0) }
    val haptic = LocalHapticFeedback.current
    val target = sn.settings.zikrTarget
    val total = sn.zikr.firstOrNull { it.day == today && it.phrase == phrase }?.count ?: 0
    val allToday = sn.zikr.filter { it.day == today }.sumOf { it.count }

    ScreenScaffold("Зикр", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { ChipsRow { ZIKR_PHRASES.forEach { p -> FilterChip(selected = phrase == p, onClick = { phrase = p; session = 0 }, label = { Text(p) }) } } }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(phrase, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.height(8.dp))
                        Text("${session % maxOf(target, 1)}", fontSize = 72.sp, fontWeight = FontWeight.Bold)
                        Text("круг ${session / maxOf(target, 1) + 1} из ${target} · за сессию $session", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(12.dp))
                        FilledIconButton(
                            onClick = {
                                session++
                                vm.setZikr(today, phrase, total + 1)
                                if (target > 0 && session % target == 0) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            },
                            modifier = Modifier.size(140.dp)
                        ) { Icon(Icons.Rounded.TouchApp, "Счёт +1", Modifier.size(64.dp)) }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { if (session > 0) { session--; vm.setZikr(today, phrase, total - 1) } }) { Text("−1") }
                            OutlinedButton(onClick = { session = 0 }) { Text("Сбросить сессию") }
                        }
                    }
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Круг (количество в одном подходе)", style = MaterialTheme.typography.titleSmall)
                    ChoiceChips(listOf(33, 34, 99, 100, 1000).map { it to "$it" }, target) { v -> vm.updateSettings { it.copy(zikrTarget = v) } }
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Сегодня всего: $allToday", style = MaterialTheme.typography.titleSmall)
                    sn.zikr.filter { it.day == today && it.count > 0 }.forEach { Text("${it.phrase}: ${it.count}", style = MaterialTheme.typography.bodyMedium) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Пост

@Composable
fun FastingScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val today = todayEpoch()
    val adj = sn.settings.hijriAdjust
    val h = Hijri.of(LocalDate.ofEpochDay(today), adj)
    val fasts = sn.fasts.associateBy { it.day }
    val tomorrow = today + 1
    var pick by remember { mutableStateOf<Long?>(null) }

    val suggestions = remember(today, adj) {
        (0..13).map { today + it }.mapNotNull { d ->
            val hd = Hijri.of(LocalDate.ofEpochDay(d), adj)
            val iso = isoDay(d)
            val txt = when {
                hd.month == 9 -> "Рамадан"
                hd.month == 1 && hd.day in 9..10 -> "Ашура"
                hd.month == 12 && hd.day == 9 -> "День Арафат"
                Hijri.isWhiteDay(hd) -> "Белые дни"
                iso == 1 -> "Понедельник (сунна)"
                iso == 4 -> "Четверг (сунна)"
                else -> null
            }
            txt?.let { d to it }
        }.take(6)
    }

    ScreenScaffold("Пост", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Text("Сегодня: ${h}", style = MaterialTheme.typography.titleSmall)
                    val f = fasts[today]
                    Text(if (f != null) "Постится: ${FAST_TYPES[f.type] ?: f.type}" else "Пост не отмечен", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { pick = today }) { Text(if (f == null) "Отметить пост" else "Изменить") }
                        if (f != null) OutlinedButton(onClick = { vm.setFast(today, null) }) { Text("Снять") }
                    }
                }
            }
            item { AppCard(Modifier.fillMaxWidth()) {
                Text("Дней поста: ${sn.fasts.size}", style = MaterialTheme.typography.titleSmall)
                FAST_TYPES.forEach { (k, v) -> val n = sn.fasts.count { it.type == k }; if (n > 0) Text("$v: $n", style = MaterialTheme.typography.bodySmall) }
                val ramadan = sn.fasts.count { it.type == "RAMADAN" && Hijri.of(LocalDate.ofEpochDay(it.day), adj).year == h.year }
                if (ramadan > 0) Text("Рамадан ${h.year} г.х.: $ramadan из 29–30", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            } }
            item { SectionTitle("Ближайшие дни для поста") }
            items(suggestions, key = { it.first }) { (d, t) ->
                AppCard(Modifier.fillMaxWidth(), onClick = { pick = d }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(dayLabel(d), style = MaterialTheme.typography.titleSmall)
                            Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (fasts.containsKey(d)) Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            item { SectionTitle("История") }
            if (sn.fasts.isEmpty()) item { EmptyHint("Пока нет записей") }
            items(sn.fasts.sortedByDescending { it.day }.take(30), key = { "f${it.day}" }) { f ->
                AppCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${dayLabel(f.day)} · ${FAST_TYPES[f.type] ?: f.type}", Modifier.weight(1f))
                        IconButton(onClick = { vm.setFast(f.day, null) }) { Icon(Icons.Rounded.Delete, "Удалить") }
                    }
                }
            }
        }
    }
    pick?.let { d ->
        AlertDialog(
            onDismissRequest = { pick = null }, title = { Text("Пост: ${shortDate(d)}") },
            text = { Column { FAST_TYPES.forEach { (k, v) -> TextButton(onClick = { vm.setFast(d, k); pick = null }) { Text(v) } } } },
            confirmButton = {}, dismissButton = { TextButton(onClick = { pick = null }) { Text("Отмена") } }
        )
    }
}

// ---------------------------------------------------------------- Календарь Хиджры

@Composable
fun HijriScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val adj = sn.settings.hijriAdjust
    val today = LocalDate.now()
    var month by rememberSaveable { mutableIntStateOf(0) }
    val first = today.withDayOfMonth(1).plusMonths(month.toLong())
    val len = first.lengthOfMonth()
    val lead = first.dayOfWeek.value - 1
    val upcoming = remember(adj) { Hijri.upcoming(today, adj) }
    ScreenScaffold("Календарь Хиджры", onBack) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { month-- }) { Icon(Icons.Rounded.ChevronLeft, "Назад") }
                    val a = Hijri.of(first, adj); val b = Hijri.of(first.plusDays((len - 1).toLong()), adj)
                    Text("${RU_MONTHS_NOM[first.monthValue - 1]} ${first.year}\n${a.monthName} ${a.year}" + if (a.month != b.month) " – ${b.monthName}" else "", Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = { month++ }) { Icon(Icons.Rounded.ChevronRight, "Вперёд") }
                }
            }
            item {
                Column {
                    Row(Modifier.fillMaxWidth()) { RU_DAYS_SHORT.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
                    val rows = (lead + len + 6) / 7
                    for (r in 0 until rows) Row(Modifier.fillMaxWidth()) {
                        for (c in 0..6) {
                            val n = r * 7 + c - lead + 1
                            if (n < 1 || n > len) { Spacer(Modifier.weight(1f)); continue }
                            val d = first.plusDays((n - 1).toLong())
                            val hd = Hijri.of(d, adj)
                            val special = Hijri.note(hd) != null
                            val isToday = d == today
                            Column(
                                Modifier.weight(1f).padding(2.dp).height(52.dp),
                                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                            ) {
                                Surface(
                                    shape = MaterialTheme.shapes.small,
                                    color = if (isToday) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else if (special) MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                        Text("$n", fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal)
                                        Text("${hd.day}", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                                    }
                                }
                            }
                        }
                    }
                    Text("Мелкие цифры — день месяца по Хиджре", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                }
            }
            item { SectionTitle("Ближайшие даты") }
            items(upcoming.take(10), key = { it.first.toEpochDay() }) { (d, t) ->
                AppCard(Modifier.fillMaxWidth()) {
                    Text(t, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("${shortDate(d.toEpochDay())} · ${Hijri.of(d, adj)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Цели

@Composable
fun GoalsScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    var edit by remember { mutableStateOf<GoalEntity?>(null) }
    val goals = sn.goals.sortedWith(compareBy({ it.done }, { it.id }))
    ScreenScaffold("Религиозные цели", onBack, floating = {
        FloatingActionButton(onClick = { edit = GoalEntity(title = "") }) { Icon(Icons.Rounded.Add, "Добавить") }
    }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (goals.isEmpty()) item { EmptyHint("Поставьте личную цель: выучить суру, закончить хатм, прочитать книгу сиры…") }
            items(goals, key = { it.id }) { g ->
                AppCard(Modifier.fillMaxWidth(), onClick = { edit = g }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CheckCircle(g.done, { vm.saveGoal(g.copy(done = !g.done)) })
                        Column(Modifier.weight(1f)) {
                            Text(g.title, style = MaterialTheme.typography.titleSmall, textDecoration = if (g.done) TextDecoration.LineThrough else null)
                            val sub = listOf(if (g.dueDay > 0) "до ${shortDate(g.dueDay)}" else "", g.notes).filter { it.isNotBlank() }.joinToString(" · ")
                            if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
    edit?.let { g ->
        var v by remember(g) { mutableStateOf(g) }
        AlertDialog(
            onDismissRequest = { edit = null }, title = { Text(if (g.id == 0L) "Новая цель" else "Цель") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(v.title, { v = v.copy(title = it) }, label = { Text("Цель") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(v.notes, { v = v.copy(notes = it) }, label = { Text("Заметки") }, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (v.dueDay > 0) DateField("Срок", v.dueDay, { v = v.copy(dueDay = it) }, Modifier.weight(1f))
                        else OutlinedButton(onClick = { v = v.copy(dueDay = todayEpoch() + 30) }) { Text("Добавить срок") }
                        if (v.dueDay > 0) IconButton(onClick = { v = v.copy(dueDay = 0) }) { Icon(Icons.Rounded.Close, "Без срока") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { if (v.title.isNotBlank()) { vm.saveGoal(v.copy(title = v.title.trim())); edit = null } else vm.say("Введите цель") }) { Text("Сохранить") } },
            dismissButton = {
                Row {
                    if (g.id != 0L) TextButton(onClick = { vm.deleteGoal(g.id); edit = null }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                    TextButton(onClick = { edit = null }) { Text("Отмена") }
                }
            }
        )
    }
}
