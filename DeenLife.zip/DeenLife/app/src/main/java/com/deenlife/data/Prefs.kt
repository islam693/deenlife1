package com.deenlife.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

data class Settings(
    val userName: String = "",
    val theme: Int = 0,                      // 0 системная, 1 светлая, 2 тёмная
    // место и расчёт намаза
    val cityName: String = "Москва",
    val lat: Double = 55.7558,
    val lng: Double = 37.6173,
    val tzId: String = "Europe/Moscow",
    val method: String = "RUSSIA",
    val asrFactor: Int = 1,                  // 1 — шафиитский/маликитский/ханбалитский, 2 — ханафитский
    val hijriAdjust: Int = 0,
    // уведомления
    val nClasses: Boolean = true,
    val nHomework: Boolean = true,
    val nWorkout: Boolean = true,
    val nPrayer: Boolean = true,
    val nTahajjud: Boolean = true,
    val nSleep: Boolean = true,
    val nWake: Boolean = true,
    val nHabits: Boolean = true,
    val nEvents: Boolean = true,
    val prayerLead: Int = 10,
    val jumuah: Boolean = true,
    // режим дня
    val weekend: Set<Int> = setOf(6, 7),
    val studyGoalMin: Int = 240,
    val bed: List<Int> = List(7) { 23 * 60 },   // отбой по дням недели (пн..вс)
    val wake: List<Int> = List(7) { 7 * 60 },   // подъём по дням недели
    val sleepGoalMin: Int = 8 * 60,
    val bedPrep: Int = 30,
    val restDays: Set<Int> = setOf(7),
    val workoutPerWeek: Int = 3,
    // ислам
    val quranGoal: Int = 2,
    val zikrTarget: Int = 33,
    // служебное
    val studyTimerStart: Long = 0,
    val studyTimerSubject: String = "",
    val weatherTs: Long = 0,
    val weatherTemp: Double = 0.0,
    val weatherCode: Int = -1
) {
    fun notifOn(channel: String): Boolean = when (channel) {
        "classes" -> nClasses
        "homework" -> nHomework
        "workout" -> nWorkout
        "prayer" -> nPrayer
        "tahajjud" -> nTahajjud
        "sleep" -> nSleep
        "wake" -> nWake
        "habits" -> nHabits
        else -> nEvents
    }
}

private val LONG_KEYS = setOf("lastFired", "studyTimerStart", "weatherTs")

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("deenlife", Context.MODE_PRIVATE)
    val flow = MutableStateFlow(load())
    val value: Settings get() = flow.value

    fun update(f: (Settings) -> Settings) {
        val n = f(flow.value)
        save(n)
        flow.value = n
    }

    var lastFired: Long
        get() = sp.getLong("lastFired", 0L)
        set(v) { sp.edit().putLong("lastFired", v).apply() }

    fun reload() { flow.value = load() }

    fun dumpJson(): String {
        val o = org.json.JSONObject()
        for ((k, v) in sp.all) o.put(k, v)
        return o.toString()
    }

    fun restoreJson(text: String) {
        val o = org.json.JSONObject(text)
        val e = sp.edit().clear()
        for (k in o.keys()) {
            when (val v = o.get(k)) {
                is Boolean -> e.putBoolean(k, v)
                is Int -> if (k in LONG_KEYS) e.putLong(k, v.toLong()) else e.putInt(k, v)
                is Long -> e.putLong(k, v)
                is Double -> e.putString(k, v.toString()) // числа с плавающей точкой хранятся строкой
                is String -> e.putString(k, v)
            }
        }
        e.commit()
        reload()
    }

    private fun d(k: String, def: Double) = sp.getString(k, null)?.toDoubleOrNull() ?: def
    private fun ints(k: String, def: List<Int>): List<Int> =
        sp.getString(k, null)?.split(",")?.mapNotNull { it.toIntOrNull() }?.takeIf { it.size == 7 } ?: def
    private fun set(k: String, def: Set<Int>): Set<Int> =
        sp.getString(k, null)?.split(",")?.mapNotNull { it.toIntOrNull() }?.toSet() ?: def

    private fun load(): Settings {
        val x = Settings()
        return Settings(
            userName = sp.getString("userName", x.userName)!!,
            theme = sp.getInt("theme", x.theme),
            cityName = sp.getString("cityName", x.cityName)!!,
            lat = d("lat", x.lat), lng = d("lng", x.lng),
            tzId = sp.getString("tzId", x.tzId)!!,
            method = sp.getString("method", x.method)!!,
            asrFactor = sp.getInt("asrFactor", x.asrFactor),
            hijriAdjust = sp.getInt("hijriAdjust", x.hijriAdjust),
            nClasses = sp.getBoolean("nClasses", true), nHomework = sp.getBoolean("nHomework", true),
            nWorkout = sp.getBoolean("nWorkout", true), nPrayer = sp.getBoolean("nPrayer", true),
            nTahajjud = sp.getBoolean("nTahajjud", true), nSleep = sp.getBoolean("nSleep", true),
            nWake = sp.getBoolean("nWake", true), nHabits = sp.getBoolean("nHabits", true),
            nEvents = sp.getBoolean("nEvents", true),
            prayerLead = sp.getInt("prayerLead", x.prayerLead),
            jumuah = sp.getBoolean("jumuah", true),
            weekend = set("weekend", x.weekend),
            studyGoalMin = sp.getInt("studyGoalMin", x.studyGoalMin),
            bed = ints("bed", x.bed), wake = ints("wake", x.wake),
            sleepGoalMin = sp.getInt("sleepGoalMin", x.sleepGoalMin),
            bedPrep = sp.getInt("bedPrep", x.bedPrep),
            restDays = set("restDays", x.restDays),
            workoutPerWeek = sp.getInt("workoutPerWeek", x.workoutPerWeek),
            quranGoal = sp.getInt("quranGoal", x.quranGoal),
            zikrTarget = sp.getInt("zikrTarget", x.zikrTarget),
            studyTimerStart = sp.getLong("studyTimerStart", 0L),
            studyTimerSubject = sp.getString("studyTimerSubject", "")!!,
            weatherTs = sp.getLong("weatherTs", 0L),
            weatherTemp = d("weatherTemp", 0.0),
            weatherCode = sp.getInt("weatherCode", -1)
        )
    }

    private fun save(s: Settings) {
        sp.edit()
            .putString("userName", s.userName).putInt("theme", s.theme)
            .putString("cityName", s.cityName).putString("lat", s.lat.toString()).putString("lng", s.lng.toString())
            .putString("tzId", s.tzId).putString("method", s.method).putInt("asrFactor", s.asrFactor)
            .putInt("hijriAdjust", s.hijriAdjust)
            .putBoolean("nClasses", s.nClasses).putBoolean("nHomework", s.nHomework)
            .putBoolean("nWorkout", s.nWorkout).putBoolean("nPrayer", s.nPrayer)
            .putBoolean("nTahajjud", s.nTahajjud).putBoolean("nSleep", s.nSleep)
            .putBoolean("nWake", s.nWake).putBoolean("nHabits", s.nHabits).putBoolean("nEvents", s.nEvents)
            .putInt("prayerLead", s.prayerLead).putBoolean("jumuah", s.jumuah)
            .putString("weekend", s.weekend.joinToString(","))
            .putInt("studyGoalMin", s.studyGoalMin)
            .putString("bed", s.bed.joinToString(",")).putString("wake", s.wake.joinToString(","))
            .putInt("sleepGoalMin", s.sleepGoalMin).putInt("bedPrep", s.bedPrep)
            .putString("restDays", s.restDays.joinToString(","))
            .putInt("workoutPerWeek", s.workoutPerWeek)
            .putInt("quranGoal", s.quranGoal).putInt("zikrTarget", s.zikrTarget)
            .putLong("studyTimerStart", s.studyTimerStart).putString("studyTimerSubject", s.studyTimerSubject)
            .putLong("weatherTs", s.weatherTs).putString("weatherTemp", s.weatherTemp.toString())
            .putInt("weatherCode", s.weatherCode)
            .apply()
    }
}
