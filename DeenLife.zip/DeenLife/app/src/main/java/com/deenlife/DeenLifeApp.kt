package com.deenlife

import android.app.Application
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.deenlife.data.AppDatabase
import com.deenlife.data.Prefs
import com.deenlife.notify.Notifier
import com.deenlife.notify.ReminderEngine
import com.deenlife.notify.ReminderScheduler
import com.deenlife.notify.SafetyWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class DeenLifeApp : Application() {
    lateinit var prefs: Prefs
    lateinit var engine: ReminderEngine
    val db: AppDatabase get() = AppDatabase.get(this)
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        engine = ReminderEngine(db.dao(), prefs)
        Notifier.createChannels(this)
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "deenlife-safety",
            ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<SafetyWorker>(3, TimeUnit.HOURS).build()
        )
        reschedule()
    }

    /** Вызывается после любого изменения данных/настроек, влияющих на напоминания. */
    fun reschedule() {
        scope.launch {
            try { ReminderScheduler.rescheduleNext(this@DeenLifeApp) } catch (_: Throwable) {}
        }
    }
}
