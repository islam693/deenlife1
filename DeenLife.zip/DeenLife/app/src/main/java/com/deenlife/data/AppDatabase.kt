package com.deenlife.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.deenlife.domain.DEFAULT_CATEGORIES

@Database(
    entities = [
        EventEntity::class, ItemStatus::class, CourseEntity::class, HomeworkEntity::class,
        StudyLogEntity::class, WorkoutEntity::class, SleepLogEntity::class, HabitEntity::class,
        HabitLog::class, IbadahLog::class, FastLog::class, QuranLog::class, ZikrLog::class,
        GoalEntity::class, CategoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        const val NAME = "deenlife.db"
        @Volatile private var inst: AppDatabase? = null

        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, NAME)
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        DEFAULT_CATEGORIES.forEachIndexed { i, c ->
                            db.execSQL(
                                "INSERT OR IGNORE INTO categories(id,name,color,builtIn,sort) VALUES(?,?,?,1,?)",
                                arrayOf<Any>(c.id, c.name, c.color, i)
                            )
                        }
                    }
                })
                .build().also { inst = it }
        }

        /** Полностью записывает WAL в основной файл и закрывает базу (перед резервным копированием/восстановлением). */
        fun checkpointAndClose() {
            inst?.let {
                try {
                    it.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
                } catch (_: Throwable) {}
                it.close()
            }
            inst = null
        }
    }
}
