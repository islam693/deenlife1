package com.deenlife.util

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

val RU_DAYS_FULL = listOf("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье")
val RU_DAYS_SHORT = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
val RU_MONTHS_GEN = listOf(
    "января", "февраля", "марта", "апреля", "мая", "июня",
    "июля", "августа", "сентября", "октября", "ноября", "декабря"
)
val RU_MONTHS_NOM = listOf(
    "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
)

fun todayEpoch(): Long = LocalDate.now().toEpochDay()
fun nowMinute(): Int = LocalTime.now().let { it.hour * 60 + it.minute }
fun isoDay(epochDay: Long): Int = LocalDate.ofEpochDay(epochDay).dayOfWeek.value

fun fmtTime(min: Int): String {
    val m = ((min % 1440) + 1440) % 1440
    return "%02d:%02d".format(m / 60, m % 60)
}

fun fmtDur(min: Int): String {
    val m = if (min < 0) 0 else min
    val h = m / 60
    val r = m % 60
    return when {
        h > 0 && r > 0 -> "$h ч $r мин"
        h > 0 -> "$h ч"
        else -> "$r мин"
    }
}

fun dayLabel(epochDay: Long): String {
    val d = LocalDate.ofEpochDay(epochDay)
    return "${RU_DAYS_FULL[d.dayOfWeek.value - 1]}, ${d.dayOfMonth} ${RU_MONTHS_GEN[d.monthValue - 1]}"
}

fun shortDate(epochDay: Long): String {
    val d = LocalDate.ofEpochDay(epochDay)
    return "${d.dayOfMonth} ${RU_MONTHS_GEN[d.monthValue - 1]}"
}

/** Момент (мс) для дня [day] и минуты [min] от полуночи в зоне [zone] (с учётом перехода на летнее/зимнее время). */
fun millisOf(day: Long, min: Int, zone: ZoneId = ZoneId.systemDefault()): Long =
    LocalDateTime.of(LocalDate.ofEpochDay(day), LocalTime.MIDNIGHT).plusMinutes(min.toLong())
        .atZone(zone).toInstant().toEpochMilli()

fun weekStart(day: Long): Long = day - (isoDay(day) - 1)

fun parseHm(s: String): Int? {
    val m = Regex("^(\\d{1,2})[:.](\\d{2})$").find(s.trim()) ?: return null
    val h = m.groupValues[1].toInt()
    val mi = m.groupValues[2].toInt()
    return if (h in 0..23 && mi in 0..59) h * 60 + mi else null
}
