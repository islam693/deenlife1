package com.deenlife.notify

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.deenlife.DeenLifeApp
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Схема: хранится ОДИН точный будильник на ближайшее напоминание. Когда он срабатывает, показываются все
 * напоминания, наступившие с прошлого запуска (lastFired), и ставится следующий будильник.
 * Перезагрузка, смена часового пояса/времени и обновление приложения вызывают тот же путь (BootReceiver),
 * а WorkManager раз в несколько часов подстраховывает на случай, если система убила будильник.
 */
object ReminderScheduler {
    private val lock = Mutex()
    private const val WINDOW_MS = 8L * 24 * 3600 * 1000
    private const val STALE_MS = 15L * 60 * 1000      // не показываем напоминания старше 15 минут (после долгого отключения)

    private fun alarmIntent(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 1, Intent(ctx, AlarmReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    suspend fun rescheduleNext(ctx: Context) = lock.withLock { scheduleLocked(ctx) }

    /** Показывает наступившие напоминания и ставит следующий будильник. */
    suspend fun fireDue(ctx: Context) = lock.withLock {
        val app = ctx.applicationContext as DeenLifeApp
        val now = System.currentTimeMillis() + 2_000
        var last = app.prefs.lastFired
        if (last == 0L || last > now) last = now - 60_000          // первый запуск или откат часов
        val from = maxOf(last, now - STALE_MS)
        val due = app.engine.build(from, now).filter { it.time > from }
        due.forEach { Notifier.show(ctx, it) }
        app.prefs.lastFired = now
        scheduleLocked(ctx)
    }

    private suspend fun scheduleLocked(ctx: Context) {
        val app = ctx.applicationContext as DeenLifeApp
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val next = app.engine.build(maxOf(now, app.prefs.lastFired) + 1, now + WINDOW_MS).firstOrNull()
        val pi = alarmIntent(ctx)
        if (next == null) { am.cancel(pi); return }
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
        try {
            if (canExact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.time, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.time, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.time, pi)
        }
    }

    fun canScheduleExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
    }
}
