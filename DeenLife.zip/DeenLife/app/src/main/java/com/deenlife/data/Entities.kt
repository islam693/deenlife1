package com.deenlife.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** repeat: 0 нет, 1 ежедневно, 2 еженедельно, 3 по выбранным дням (repeatDays — битовая маска ISO-дней, бит = isoDay-1). */
@Entity(tableName = "events", indices = [Index("startDay")])
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val color: Int,
    val startDay: Long,          // epochDay
    val startMin: Int,           // минуты от полуночи
    val endMin: Int,             // может быть > 1440 (событие переходит через полночь)
    val repeat: Int = 0,
    val repeatDays: Int = 0,
    val reminderMin: Int = -1,   // -1 нет, 0 в момент начала, N — за N минут
    val notes: String = "",
    val source: String = "user"
)

/** id: "E:<eventId>:<day>" или "C:<courseId>:<day>"; state: 1 выполнено, 2 перенесено/пропущено */
@Entity(tableName = "item_status")
data class ItemStatus(@PrimaryKey val id: String, val state: Int)

@Entity(tableName = "courses")
data class CourseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val teacher: String = "",
    val room: String = "",
    val dayOfWeek: Int,          // 1..7 (пн..вс)
    val startMin: Int,
    val endMin: Int,
    val color: Int,
    val reminderMin: Int = 15
)

@Entity(tableName = "homework")
data class HomeworkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val course: String = "",
    val deadlineDay: Long,
    val deadlineMin: Int = 23 * 60,
    val done: Boolean = false,
    val notes: String = "",
    val estMin: Int = 60
)

@Entity(tableName = "study_log")
data class StudyLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: Long,
    val minutes: Int,
    val subject: String = "",
    val note: String = ""
)

@Entity(tableName = "workouts")
data class WorkoutEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val muscle: String,
    val exercises: String = "",
    val day: Long,
    val startMin: Int,
    val durationMin: Int,
    val done: Boolean = false,
    val reminderMin: Int = 30
)

/** Ночь, начавшаяся вечером дня [day]: отбой bedMin (вечер дня day), подъём wakeMin (утро следующего дня). */
@Entity(tableName = "sleep_log")
data class SleepLogEntity(@PrimaryKey val day: Long, val bedMin: Int, val wakeMin: Int) {
    val minutes: Int
        get() = if (bedMin >= wakeMin) (1440 - bedMin) + wakeMin else wakeMin - bedMin
}

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val color: Int,
    val weekly: Boolean = false,
    val target: Int = 7,         // для weekly: раз в неделю
    val reminderMin: Int = -1,
    val archived: Boolean = false
)

@Entity(tableName = "habit_log", primaryKeys = ["habitId", "day"])
data class HabitLog(val habitId: Long, val day: Long)

/** kind: P0..P4 (фаджр..иша), TAHAJJUD */
@Entity(tableName = "ibadah_log", primaryKeys = ["day", "kind"])
data class IbadahLog(val day: Long, val kind: String)

@Entity(tableName = "fast_log")
data class FastLog(@PrimaryKey val day: Long, val type: String)

@Entity(tableName = "quran_log")
data class QuranLog(@PrimaryKey val day: Long, val pages: Int)

@Entity(tableName = "zikr_log", primaryKeys = ["day", "phrase"])
data class ZikrLog(val day: Long, val phrase: String, val count: Int)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String = "",
    val done: Boolean = false,
    val dueDay: Long = 0          // 0 — без срока
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val color: Int,
    val builtIn: Boolean,
    val sort: Int
)
