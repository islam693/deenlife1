package com.deenlife.domain

import com.deenlife.data.*
import com.deenlife.util.*
import kotlinx.coroutines.flow.first
import java.time.LocalDate

data class Snapshot(
    val events: List<EventEntity>,
    val status: List<ItemStatus>,
    val courses: List<CourseEntity>,
    val homework: List<HomeworkEntity>,
    val studyLogs: List<StudyLogEntity>,
    val workouts: List<WorkoutEntity>,
    val sleepLogs: List<SleepLogEntity>,
    val habits: List<HabitEntity>,
    val habitLogs: List<HabitLog>,
    val ibadah: List<IbadahLog>,
    val fasts: List<FastLog>,
    val quran: List<QuranLog>,
    val zikr: List<ZikrLog>,
    val goals: List<GoalEntity>,
    val categories: List<CategoryEntity>,
    val settings: Settings
) {
    val statusMap: Map<String, Int> by lazy { status.associate { it.id to it.state } }
    val ibadahKeys: Set<String> by lazy { ibadah.map { "${it.day}:${it.kind}" }.toHashSet() }
    val habitKeys: Set<String> by lazy { habitLogs.map { "${it.habitId}:${it.day}" }.toHashSet() }
    val catMap: Map<String, CategoryEntity> by lazy { categories.associateBy { it.id } }
    fun catName(id: String) = catMap[id]?.name ?: id
    fun catColor(id: String) = catMap[id]?.color ?: PALETTE[9]
}

suspend fun loadSnapshot(dao: AppDao, s: Settings) = Snapshot(
    dao.events().first(), dao.statuses().first(), dao.courses().first(), dao.homework().first(),
    dao.studyLogs().first(), dao.workouts().first(), dao.sleepLogs().first(), dao.habits().first(),
    dao.habitLogs().first(), dao.ibadah().first(), dao.fasts().first(), dao.quran().first(),
    dao.zikr().first(), dao.goals().first(), dao.categories().first(), s
)

enum class Kind { EVENT, COURSE, WORKOUT, PRAYER, HOMEWORK, SLEEP }

/** Элемент временной шкалы дня. s/e — минуты от полуночи показываемого дня. */
data class TItem(
    val id: String,
    val kind: Kind,
    val refId: Long,
    val day: Long,           // день, к которому относится запись (для переходящих через полночь — день начала)
    val title: String,
    val sub: String,
    val s: Int,
    val e: Int,
    val color: Int,
    val category: String,
    val done: Boolean,
    val moved: Boolean = false,
    val carry: Boolean = false,   // продолжение события, начавшегося накануне
    val rem: Int = -1             // напоминание за N минут (-1 нет)
) {
    val point: Boolean get() = e <= s
    val minutes: Int get() = if (e > s) e - s else 0
    val channel: String
        get() = when (kind) {
            Kind.COURSE -> "classes"
            Kind.HOMEWORK -> "homework"
            Kind.WORKOUT -> "workout"
            Kind.PRAYER -> if (id.startsWith("T:")) "tahajjud" else "prayer"
            Kind.SLEEP -> if (id.startsWith("S:bed")) "sleep" else "wake"
            Kind.EVENT -> when (category) {
                "COURSE" -> "classes"
                "HOMEWORK" -> "homework"
                "WORKOUT" -> "workout"
                "SLEEP" -> "sleep"
                "WAKE" -> "wake"
                else -> "events"
            }
        }
}

object Timeline {
    fun build(day: Long, sn: Snapshot, prayers: Boolean = true, sleep: Boolean = true): List<TItem> {
        val out = ArrayList<TItem>()
        val iso = isoDay(day)
        val s = sn.settings

        for (off in 0..1) {
            val d = day - off
            for (ev in sn.events) {
                if (!ev.occursOn(d)) continue
                if (off == 1 && ev.endMin <= 1440) continue
                val st = sn.statusMap["E:${ev.id}:$d"] ?: 0
                val a = if (off == 0) ev.startMin else 0
                val b = if (off == 0) minOf(ev.endMin, 1440) else ev.endMin - 1440
                out += TItem(
                    "E:${ev.id}:$d", Kind.EVENT, ev.id, d, ev.title, sn.catName(ev.category),
                    a, b, ev.color, ev.category, st == 1, st == 2, off == 1, ev.reminderMin
                )
            }
        }
        for (c in sn.courses) {
            if (c.dayOfWeek != iso) continue
            val st = sn.statusMap["C:${c.id}:$day"] ?: 0
            val sub = listOf(c.teacher, if (c.room.isNotBlank()) "ауд. ${c.room}" else "").filter { it.isNotBlank() }.joinToString(" · ")
            out += TItem("C:${c.id}:$day", Kind.COURSE, c.id, day, c.name, sub, c.startMin, c.endMin, c.color, "COURSE", st == 1, false, false, c.reminderMin)
        }
        for (w in sn.workouts) {
            if (w.day != day) continue
            out += TItem(
                "W:${w.id}", Kind.WORKOUT, w.id, day, w.title, "${w.muscle} · ${fmtDur(w.durationMin)}",
                w.startMin, minOf(w.startMin + w.durationMin, 1440), sn.catColor("WORKOUT"), "WORKOUT", w.done, false, false, w.reminderMin
            )
        }
        for (h in sn.homework) {
            if (h.deadlineDay != day) continue
            out += TItem(
                "H:${h.id}", Kind.HOMEWORK, h.id, day, "Сдать: ${h.title}", h.course,
                h.deadlineMin, h.deadlineMin, sn.catColor("HOMEWORK"), "HOMEWORK", h.done
            )
        }
        if (prayers) {
            val date = LocalDate.ofEpochDay(day)
            val dp = PrayerService.forDate(s, date)
            dp.five.forEachIndexed { i, m ->
                if (m in 0 until 1440) {
                    out += TItem(
                        "P:$day:$i", Kind.PRAYER, i.toLong(), day, PRAYER_NAMES[i], "Намаз", m, m,
                        sn.catColor("RELIGION"), "RELIGION", sn.ibadahKeys.contains("$day:P$i"), rem = s.prayerLead
                    )
                }
            }
            val prev = PrayerService.forDate(s, date.minusDays(1))
            val t = prev.tahajjudStart - 1440
            if (t in 0 until 1440) {
                out += TItem(
                    "T:$day", Kind.PRAYER, 5, day, "Тахаджуд", "Последняя треть ночи", t, t,
                    PALETTE[3], "RELIGION", sn.ibadahKeys.contains("$day:TAHAJJUD"), rem = 0
                )
            }
        }
        if (sleep) {
            val wake = s.wake[iso - 1]
            val bed = s.bed[iso - 1]
            out += TItem("S:wake:$day", Kind.SLEEP, 0, day, "Подъём", "По графику сна", wake, wake, sn.catColor("WAKE"), "WAKE", false, rem = 0)
            out += TItem("S:bed:$day", Kind.SLEEP, 1, day, "Отбой", "По графику сна", bed % 1440, bed % 1440, sn.catColor("SLEEP"), "SLEEP", false, rem = s.bedPrep)
        }
        return out.sortedWith(compareBy({ it.s }, { it.kind.ordinal }))
    }

    private val TASK_KINDS = setOf(Kind.EVENT, Kind.WORKOUT, Kind.HOMEWORK)

    /** Задачи дня для прогресса: события, тренировки, домашние задания (без сна/подъёма, намазов и пар). */
    fun tasks(items: List<TItem>): List<TItem> = items.filter {
        it.kind in TASK_KINDS && !it.moved && !it.carry && it.category != "WAKE" && it.category != "SLEEP"
    }

    fun conflicts(items: List<TItem>): List<Pair<TItem, TItem>> {
        val xs = items.filter {
            (it.kind == Kind.EVENT || it.kind == Kind.COURSE || it.kind == Kind.WORKOUT) &&
                !it.moved && it.e > it.s && it.category != "WAKE"
        }
        val res = mutableListOf<Pair<TItem, TItem>>()
        for (i in xs.indices) for (j in i + 1 until xs.size) {
            if (xs[i].s < xs[j].e && xs[j].s < xs[i].e) res += xs[i] to xs[j]
        }
        return res
    }
}
