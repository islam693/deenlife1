package com.deenlife.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Weather {
    fun describe(code: Int): String = when (code) {
        0 -> "Ясно"
        1, 2 -> "Малооблачно"
        3 -> "Облачно"
        45, 48 -> "Туман"
        in 51..57 -> "Морось"
        in 61..67 -> "Дождь"
        in 71..77 -> "Снег"
        in 80..82 -> "Ливень"
        85, 86 -> "Снегопад"
        in 95..99 -> "Гроза"
        else -> "—"
    }

    /** Open-Meteo, без ключа. Возвращает (температура °C, код погоды) либо null, если сети нет. */
    fun fetch(lat: Double, lng: Double): Pair<Double, Int>? = try {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lng&current=temperature_2m,weather_code&timezone=auto")
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 4000
        c.readTimeout = 4000
        val text = c.inputStream.bufferedReader().use { it.readText() }
        c.disconnect()
        val cur = JSONObject(text).getJSONObject("current")
        cur.getDouble("temperature_2m") to cur.getInt("weather_code")
    } catch (_: Throwable) { null }

    @SuppressLint("MissingPermission")
    fun lastKnownLocation(ctx: Context): Pair<Double, Double>? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val best = lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (_: Throwable) { null } }
            .maxByOrNull { it.time } ?: return null
        return best.latitude to best.longitude
    }
}
