package com.deenlife.util

import android.content.Context
import android.net.Uri
import com.deenlife.DeenLifeApp
import com.deenlife.data.AppDatabase
import com.deenlife.data.CourseEntity
import com.deenlife.domain.PALETTE
import com.deenlife.domain.Snapshot
import com.deenlife.domain.maskDays
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Backup {
    /** Резервная копия: ZIP с файлом базы данных и настройками. Подходит и для переноса на другое устройство. */
    fun export(ctx: Context, uri: Uri) {
        val app = ctx.applicationContext as DeenLifeApp
        try {
            app.db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").close()
        } catch (_: Throwable) {}
        val dbFile = ctx.getDatabasePath(AppDatabase.NAME)
        val out = ctx.contentResolver.openOutputStream(uri) ?: error("Не удалось открыть файл для записи")
        out.use { os ->
            ZipOutputStream(os).use { z ->
                z.putNextEntry(ZipEntry("deenlife.db"))
                dbFile.inputStream().use { it.copyTo(z) }
                z.closeEntry()
                z.putNextEntry(ZipEntry("prefs.json"))
                z.write(app.prefs.dumpJson().toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
    }

    /** Восстановление. После успешного вызова приложение нужно перезапустить. */
    fun restore(ctx: Context, uri: Uri) {
        val app = ctx.applicationContext as DeenLifeApp
        var db: ByteArray? = null
        var prefs: String? = null
        val input = ctx.contentResolver.openInputStream(uri) ?: error("Не удалось открыть файл")
        input.use { ins ->
            ZipInputStream(ins).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val buf = ByteArrayOutputStream()
                    z.copyTo(buf)
                    when (e.name) {
                        "deenlife.db" -> db = buf.toByteArray()
                        "prefs.json" -> prefs = buf.toString("UTF-8")
                    }
                    e = z.nextEntry
                }
            }
        }
        val bytes = db ?: error("В архиве нет базы данных DeenLife")
        if (bytes.size < 16 || String(bytes, 0, 15, Charsets.US_ASCII) != "SQLite format 3") error("Файл повреждён")
        AppDatabase.checkpointAndClose()
        val f = ctx.getDatabasePath(AppDatabase.NAME)
        File(f.path + "-wal").delete()
        File(f.path + "-shm").delete()
        f.writeBytes(bytes)
        prefs?.let { app.prefs.restoreJson(it) }
    }

    fun readText(ctx: Context, uri: Uri): String =
        ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: error("Не удалось прочитать файл")

    fun writeText(ctx: Context, uri: Uri, text: String) {
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: error("Не удалось записать файл")
    }

    // ---------------- Экспорт расписания (iCalendar) ----------------

    fun buildIcs(sn: Snapshot): String {
        val sb = StringBuilder("BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//DeenLife//RU\r\nCALSCALE:GREGORIAN\r\n")
        val fmt = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss")
        val stamp = LocalDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'"))
        fun dt(day: Long, min: Int) =
            LocalDateTime.of(LocalDate.ofEpochDay(day), LocalTime.MIDNIGHT).plusMinutes(min.toLong()).format(fmt)
        fun esc(s: String) = s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
        val byDay = listOf("MO", "TU", "WE", "TH", "FR", "SA", "SU")

        fun vevent(uid: String, title: String, day: Long, s: Int, e: Int, rrule: String?, rem: Int, desc: String) {
            sb.append("BEGIN:VEVENT\r\nUID:$uid@deenlife\r\nDTSTAMP:$stamp\r\n")
            sb.append("DTSTART:${dt(day, s)}\r\nDTEND:${dt(day, maxOf(e, s + 1))}\r\n")
            sb.append("SUMMARY:${esc(title)}\r\n")
            if (desc.isNotBlank()) sb.append("DESCRIPTION:${esc(desc)}\r\n")
            if (rrule != null) sb.append("RRULE:$rrule\r\n")
            if (rem >= 0) sb.append("BEGIN:VALARM\r\nTRIGGER:-PT${rem}M\r\nACTION:DISPLAY\r\nDESCRIPTION:${esc(title)}\r\nEND:VALARM\r\n")
            sb.append("END:VEVENT\r\n")
        }

        for (ev in sn.events) {
            val rr = when (ev.repeat) {
                1 -> "FREQ=DAILY"
                2 -> "FREQ=WEEKLY"
                3 -> "FREQ=WEEKLY;BYDAY=" + maskDays(ev.repeatDays).sorted().joinToString(",") { byDay[it - 1] }
                else -> null
            }
            vevent("e${ev.id}", ev.title, ev.startDay, ev.startMin, ev.endMin, rr, ev.reminderMin, ev.notes)
        }
        val today = todayEpoch()
        for (c in sn.courses) {
            val first = today + ((c.dayOfWeek - isoDay(today) + 7) % 7)
            vevent("c${c.id}", c.name, first, c.startMin, c.endMin, "FREQ=WEEKLY", c.reminderMin,
                listOf(c.teacher, if (c.room.isNotBlank()) "ауд. ${c.room}" else "").filter { it.isNotBlank() }.joinToString(", "))
        }
        for (w in sn.workouts) vevent("w${w.id}", "Тренировка: ${w.title}", w.day, w.startMin, w.startMin + w.durationMin, null, w.reminderMin, w.muscle + "\n" + w.exercises)
        for (h in sn.homework) if (!h.done) vevent("h${h.id}", "Дедлайн: ${h.title}", h.deadlineDay, h.deadlineMin, h.deadlineMin + 15, null, 60, h.course)
        sb.append("END:VCALENDAR\r\n")
        return sb.toString()
    }

    // ---------------- Импорт расписания занятий (CSV) ----------------

    const val CSV_HELP = "Формат строки: день;начало;конец;предмет;преподаватель;аудитория\n" +
        "Пример: Пн;09:00;10:30;Математика;Иванов И.И.;305\n" +
        "День — Пн…Вс или 1…7. Разделитель — «;», «,» или табуляция. Первая строка-заголовок допускается."

    private fun parseDay(t: String): Int? {
        val s = t.trim().lowercase()
        s.toIntOrNull()?.let { return if (it in 1..7) it else null }
        val keys = listOf("пн", "вт", "ср", "чт", "пт", "сб", "вс")
        val i = keys.indexOfFirst { s.startsWith(it) }
        return if (i >= 0) i + 1 else null
    }

    fun parseCourses(text: String): Pair<List<CourseEntity>, Int> {
        val out = mutableListOf<CourseEntity>()
        var skipped = 0
        var idx = 0
        for (raw in text.lineSequence()) {
            val line = raw.trim().trimStart('\uFEFF')
            if (line.isEmpty()) continue
            val sep = when { line.contains(';') -> ';'; line.contains('\t') -> '\t'; else -> ',' }
            val p = line.split(sep).map { it.trim().trim('"') }
            val day = p.getOrNull(0)?.let { parseDay(it) }
            val st = p.getOrNull(1)?.let { parseHm(it) }
            val en = p.getOrNull(2)?.let { parseHm(it) }
            val name = p.getOrNull(3).orEmpty()
            if (day == null || st == null || en == null || en <= st || name.isBlank()) { skipped++; continue }
            out += CourseEntity(
                name = name, teacher = p.getOrNull(4).orEmpty(), room = p.getOrNull(5).orEmpty(),
                dayOfWeek = day, startMin = st, endMin = en, color = PALETTE[idx++ % PALETTE.size]
            )
        }
        return out to skipped
    }
}
