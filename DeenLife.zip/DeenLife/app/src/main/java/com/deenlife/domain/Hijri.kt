package com.deenlife.domain

import java.time.LocalDate
import java.time.chrono.HijrahDate

object Hijri {
    val MONTHS = listOf(
        "Мухаррам", "Сафар", "Раби аль-авваль", "Раби ас-сани", "Джумада аль-уля", "Джумада ас-сания",
        "Раджаб", "Шаабан", "Рамадан", "Шавваль", "Зуль-када", "Зуль-хиджа"
    )

    data class HDate(val year: Int, val month: Int, val day: Int) {
        val monthName: String get() = MONTHS[month - 1]
        override fun toString() = "$day $monthName $year г. х."
    }

    fun of(date: LocalDate, adjust: Int = 0): HDate {
        val h = HijrahDate.from(date.plusDays(adjust.toLong()))
        return HDate(h.get(java.time.temporal.ChronoField.YEAR), h.get(java.time.temporal.ChronoField.MONTH_OF_YEAR),
            h.get(java.time.temporal.ChronoField.DAY_OF_MONTH))
    }

    fun note(h: HDate): String? = when {
        h.month == 1 && h.day == 1 -> "Исламский Новый год"
        h.month == 1 && h.day == 10 -> "День Ашура"
        h.month == 3 && h.day == 12 -> "Маулид (рождение Пророка ﷺ)"
        h.month == 7 && h.day == 27 -> "Ночь Исра и Мирадж"
        h.month == 8 && h.day == 15 -> "Середина Шаабана"
        h.month == 9 && h.day == 1 -> "Начало Рамадана"
        h.month == 9 && h.day == 27 -> "Предполагаемая Ляйлят аль-Кадр"
        h.month == 10 && h.day == 1 -> "Ид аль-Фитр (Ураза-байрам)"
        h.month == 12 && h.day == 9 -> "День Арафат"
        h.month == 12 && h.day == 10 -> "Ид аль-Адха (Курбан-байрам)"
        else -> null
    }

    fun isWhiteDay(h: HDate) = h.day in 13..15 && h.month != 9 && !(h.month == 12 && h.day == 13)

    /** ближайшие значимые даты: список (дата, название) на [days] дней вперёд. */
    fun upcoming(from: LocalDate, adjust: Int, days: Int = 400): List<Pair<LocalDate, String>> {
        val out = mutableListOf<Pair<LocalDate, String>>()
        for (i in 0 until days) {
            val d = from.plusDays(i.toLong())
            note(of(d, adjust))?.let { out += d to it }
        }
        return out
    }
}
