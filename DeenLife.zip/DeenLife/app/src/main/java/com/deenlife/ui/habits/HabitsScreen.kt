package com.deenlife.ui.habits

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.deenlife.data.HabitEntity
import com.deenlife.domain.*
import com.deenlife.ui.AppViewModel
import com.deenlife.ui.common.*
import com.deenlife.util.*

private val TEMPLATES = listOf(
    "Читать 30 минут", "Учить новый материал", "Тренироваться", "Читать Коран",
    "Совершать все намазы", "Пить достаточно воды", "Ложиться спать вовремя"
)

@Composable
fun HabitsScreen(vm: AppViewModel, sn: Snapshot, onBack: () -> Unit) {
    val today = todayEpoch()
    var edit by remember { mutableStateOf<HabitEntity?>(null) }
    val habits = sn.habits.filter { !it.archived }
    val days = (0..6).map { today - 6 + it }

    ScreenScaffold("Привычки", onBack, floating = {
        FloatingActionButton(onClick = { edit = HabitEntity(title = "", color = PALETTE[0]) }) { Icon(Icons.Rounded.Add, "Новая привычка") }
    }) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (habits.isEmpty()) {
                item { EmptyHint("Создайте первую привычку. Можно начать с готового шаблона:") }
                item {
                    ChipsRow { TEMPLATES.forEach { t -> AssistChip(onClick = { vm.saveHabit(HabitEntity(title = t, color = PALETTE[TEMPLATES.indexOf(t) % PALETTE.size], reminderMin = -1)) }, label = { Text(t) }) } }
                }
            } else {
                val daily = habits.filter { !it.weekly }
                val doneToday = daily.count { sn.habitKeys.contains("${it.id}:$today") }
                item {
                    AppCard(Modifier.fillMaxWidth()) {
                        Text("Сегодня: $doneToday из ${daily.size} ежедневных", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        LinearProgressIndicator(progress = { if (daily.isEmpty()) 0f else doneToday.toFloat() / daily.size }, Modifier.fillMaxWidth().padding(top = 8.dp))
                    }
                }
            }
            items(habits, key = { it.id }) { h ->
                val dset = remember(sn.habitLogs, h) { Stats.habitDays(sn, h) }
                val streak = Stats.streak(h, dset, today)
                val rate = Stats.rate(h, dset, today, 30)
                AppCard(Modifier.fillMaxWidth(), onClick = { edit = h }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ColorDot(h.color, 14)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            val goalTxt = if (h.weekly) "${Stats.weekCount(dset, today)} из ${h.target} на этой неделе" else "ежедневно"
                            Text("$goalTxt · серия: $streak ${if (h.weekly) "нед." else "дн."} · за 30 дней: ${(rate * 100).toInt()}%", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        days.forEach { d ->
                            val done = dset.contains(d)
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(RU_DAYS_SHORT[isoDay(d) - 1], style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Box(
                                    Modifier.padding(top = 4.dp).size(34.dp).clip(CircleShape)
                                        .background(if (done) Color(h.color) else MaterialTheme.colorScheme.surfaceVariant)
                                        .clickable { vm.toggleHabit(h.id, d) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (done) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                    else if (d == today) Box(Modifier.size(6.dp).clip(CircleShape).background(MaterialTheme.colorScheme.outline))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    edit?.let { h ->
        var v by remember(h) { mutableStateOf(h) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { edit = null }, title = { Text(if (h.id == 0L) "Новая привычка" else "Привычка") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(v.title, { v = v.copy(title = it) }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    ChoiceChips(listOf(false to "Ежедневная", true to "Еженедельная"), v.weekly) { v = v.copy(weekly = it, target = if (it) 3 else 7) }
                    if (v.weekly) {
                        Text("Раз в неделю:", style = MaterialTheme.typography.labelMedium)
                        ChoiceChips((1..6).map { it to "$it" }, v.target) { v = v.copy(target = it) }
                    }
                    Text("Напоминание", style = MaterialTheme.typography.labelMedium)
                    var timeOpen by remember { mutableStateOf(false) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(v.reminderMin >= 0, { on -> v = v.copy(reminderMin = if (on) 20 * 60 else -1) })
                        Spacer(Modifier.width(8.dp))
                        if (v.reminderMin >= 0) TimeField("Время", v.reminderMin, { v = v.copy(reminderMin = it) })
                        else Text("выключено")
                    }
                    ColorPickerRow(v.color) { v = v.copy(color = it) }
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = { TextButton(onClick = { if (v.title.isBlank()) err = "Введите название" else { vm.saveHabit(v.copy(title = v.title.trim())); edit = null } }) { Text("Сохранить") } },
            dismissButton = {
                Row {
                    if (h.id != 0L) TextButton(onClick = { vm.deleteHabit(h.id); edit = null }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                    TextButton(onClick = { edit = null }) { Text("Отмена") }
                }
            }
        )
    }
}
